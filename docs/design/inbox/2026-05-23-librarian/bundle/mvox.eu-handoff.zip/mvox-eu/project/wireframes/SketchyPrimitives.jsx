// Sketchy wireframe primitives — hand-drawn pencil feel on Polyphony tokens.
// All components are intentionally low-fi: wobbly strokes, grey palette,
// a single muted accent (indigo for the Registry side). No finished styling.

// ─── One-time CSS injection ──────────────────────────────────────────
if (typeof document !== 'undefined' && !document.getElementById('sk-styles')) {
  const s = document.createElement('style');
  s.id = 'sk-styles';
  s.textContent = `
    .sk {
      --ink: #2a2620;
      --ink2: #4b443a;
      --ink3: #7a7166;
      --ink4: #a89f91;
      --ink5: #d8cfbf;
      --paper: #faf7f0;
      --paper2: #f2ede0;
      --accent: #4f46e5;       /* indigo-600 — Registry primary */
      --accent-soft: #e0e7ff;
      --highlight: #fff2a6;    /* highlighter yellow */
      --red: #c84b3a;
      color: var(--ink);
      background: var(--paper);
      font-family: 'Caveat', 'Shadows Into Light', 'Patrick Hand', 'Comic Sans MS', cursive, sans-serif;
      font-size: 17px;
      line-height: 1.3;
    }
    .sk .mono {
      font-family: 'JetBrains Mono', ui-monospace, Menlo, monospace;
      font-size: 12px;
      letter-spacing: -0.01em;
    }
    .sk .sans {
      font-family: 'Inter', system-ui, sans-serif;
    }

    /* Sketchy box: dashed outer, jiggle via slight rotation */
    .sk-box {
      border: 1.5px solid var(--ink);
      border-radius: 3px;
      background: var(--paper);
      position: relative;
    }
    .sk-box.dashed { border-style: dashed; border-color: var(--ink3); }
    .sk-box.soft   { border-color: var(--ink4); background: var(--paper2); }
    .sk-box.filled { background: var(--paper2); }
    .sk-box.accent { border-color: var(--accent); border-width: 2px; }

    /* Hatching fill used for "image here" placeholders */
    .sk-hatch {
      background-image: repeating-linear-gradient(
        -45deg,
        var(--ink4) 0 1px,
        transparent 1px 7px
      );
      background-color: var(--paper2);
    }
    .sk-hatch-light {
      background-image: repeating-linear-gradient(
        -45deg,
        var(--ink5) 0 1px,
        transparent 1px 8px
      );
      background-color: var(--paper);
    }

    /* Underline — slight wobble via gradient */
    .sk-underline {
      background-image: linear-gradient(var(--ink), var(--ink));
      background-position: 0 100%;
      background-repeat: no-repeat;
      background-size: 100% 2px;
      padding-bottom: 1px;
    }
    .sk-highlight {
      background: linear-gradient(transparent 55%, var(--highlight) 55% 92%, transparent 92%);
      padding: 0 3px;
    }

    /* Lorem lines — fake body text without real words */
    .sk-line {
      display: block;
      height: 6px;
      background: var(--ink5);
      border-radius: 3px;
      margin: 7px 0;
    }
    .sk-line.short { width: 55%; }
    .sk-line.med { width: 82%; }
    .sk-line.long { width: 97%; }
    .sk-line.dark { background: var(--ink4); }

    /* Chip — rounded pill, sketchy */
    .sk-chip {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 2px 9px;
      border: 1.25px solid var(--ink3);
      border-radius: 999px;
      font-size: 13px;
      color: var(--ink2);
      background: var(--paper);
      line-height: 1.1;
    }
    .sk-chip.accent { border-color: var(--accent); color: var(--accent); background: var(--accent-soft); }
    .sk-chip.filled { background: var(--paper2); }

    /* Button */
    .sk-btn {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 5px 14px;
      border: 1.5px solid var(--ink);
      border-radius: 4px;
      background: var(--paper);
      color: var(--ink);
      font-family: inherit;
      font-size: 15px;
      cursor: pointer;
      box-shadow: 2px 2px 0 0 var(--ink3);
    }
    .sk-btn.primary {
      background: var(--accent);
      color: #fff;
      border-color: var(--accent);
      box-shadow: 2px 2px 0 0 var(--ink);
    }
    .sk-btn.ghost { border-style: dashed; box-shadow: none; color: var(--ink2); }

    /* Annotations — margin notes */
    .sk-annot {
      font-family: 'Caveat', cursive;
      color: var(--red);
      font-size: 15px;
      line-height: 1.15;
      transform: rotate(-2deg);
      display: inline-block;
    }
    .sk-annot-arrow::before {
      content: '↳ ';
      color: var(--red);
    }

    /* Section heading: eyebrow label */
    .sk-eyebrow {
      font-family: 'Inter', system-ui, sans-serif;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.14em;
      text-transform: uppercase;
      color: var(--ink3);
    }

    /* Divider — hand-drawn */
    .sk-hr {
      border: none;
      border-top: 1.5px solid var(--ink4);
      margin: 14px 0;
    }
    .sk-hr.dashed { border-top-style: dashed; border-color: var(--ink3); }

    /* Tiny icon box */
    .sk-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 22px; height: 22px;
      border: 1.25px solid var(--ink3);
      border-radius: 4px;
      color: var(--ink3);
      font-size: 12px;
      background: var(--paper);
      flex-shrink: 0;
    }

    /* Browser chrome stub */
    .sk-browser {
      background: var(--paper2);
      border: 1.5px solid var(--ink);
      border-radius: 8px 8px 3px 3px;
      overflow: hidden;
      height: 100%;
      display: flex;
      flex-direction: column;
    }
    .sk-browser-bar {
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 7px 10px;
      border-bottom: 1.5px solid var(--ink3);
      background: var(--paper2);
      flex-shrink: 0;
    }
    .sk-browser-dot {
      width: 9px; height: 9px;
      border-radius: 50%;
      border: 1px solid var(--ink3);
    }
    .sk-browser-url {
      flex: 1;
      background: var(--paper);
      border: 1px solid var(--ink4);
      border-radius: 3px;
      padding: 2px 9px;
      font-size: 12px;
      color: var(--ink3);
      font-family: 'JetBrains Mono', monospace;
    }
    .sk-browser-body {
      flex: 1;
      overflow: hidden;
      position: relative;
      background: var(--paper);
    }
  `;
  document.head.appendChild(s);

  // Load sketchy fonts once
  if (!document.getElementById('sk-fonts')) {
    const l = document.createElement('link');
    l.id = 'sk-fonts';
    l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;700&family=Patrick+Hand&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap';
    document.head.appendChild(l);
  }
}

// ─── Small helper components ─────────────────────────────────────────
function Lines({ count = 3, widths }) {
  const ws = widths || ['long', 'long', 'med'];
  return (
    <div>
      {Array.from({ length: count }).map((_, i) => (
        <span key={i} className={`sk-line ${ws[i % ws.length]}`} />
      ))}
    </div>
  );
}

function Chip({ children, variant, style }) {
  const cls = variant ? `sk-chip ${variant}` : 'sk-chip';
  return <span className={cls} style={style}>{children}</span>;
}

function Eyebrow({ children, style }) {
  return <div className="sk-eyebrow" style={style}>{children}</div>;
}

function Annot({ children, style }) {
  return <span className="sk-annot" style={style}>{children}</span>;
}

// Browser frame wrapping an artboard's content
function BrowserFrame({ url, children }) {
  return (
    <div className="sk-browser">
      <div className="sk-browser-bar">
        <span className="sk-browser-dot" />
        <span className="sk-browser-dot" />
        <span className="sk-browser-dot" />
        <span className="sk-browser-url">{url}</span>
      </div>
      <div className="sk-browser-body">{children}</div>
    </div>
  );
}

// Global nav bar stub, matches Registry layout.
// variant="signin" collapses the right side to just a Sign-in button —
// used on collective pages where the primary visitor action is authenticating.
function RegistryNav({ variant = 'default' }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '11px 24px', borderBottom: '1.5px solid var(--ink4)',
      background: 'var(--paper)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span className="sk-icon" style={{ background: 'var(--accent)', color: '#fff', borderColor: 'var(--accent)' }}>♪</span>
        <span style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 14 }}>Multivox</span>
      </div>
      {variant === 'signin' ? (
        <button className="sk-btn primary" style={{ fontSize: 12 }}>Sign in →</button>
      ) : (
        <div style={{ display: 'flex', gap: 18, fontFamily: 'Inter', fontSize: 12, color: 'var(--ink3)' }}>
          <span>Find a Choir</span>
          <span>Register</span>
          <span>Sign in</span>
        </div>
      )}
    </div>
  );
}

// Breadcrumb
function Breadcrumb({ trail }) {
  return (
    <div style={{
      fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)',
      padding: '10px 24px 0', display: 'flex', gap: 6, alignItems: 'center',
    }}>
      {trail.map((t, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span style={{ color: 'var(--ink4)' }}>›</span>}
          <span style={{ color: i === trail.length - 1 ? 'var(--ink2)' : 'var(--ink3)' }}>{t}</span>
        </React.Fragment>
      ))}
    </div>
  );
}

Object.assign(window, {
  Lines, Chip, Eyebrow, Annot, BrowserFrame, RegistryNav, Breadcrumb,
});
