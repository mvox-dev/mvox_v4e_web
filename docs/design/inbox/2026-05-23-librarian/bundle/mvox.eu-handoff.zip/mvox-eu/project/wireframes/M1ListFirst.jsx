// M1 — List-first agenda.
// Big chronological list left; right rail = toggle, week summary, quick stats.

function M1ListFirst() {
  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column' }}>
        <WorkspaceNav />
        <WorkspaceSubnav active="agenda" />

        {/* Page header */}
        <div style={{ padding:'16px 24px 10px', borderBottom:'1px solid var(--ink5)', display:'flex', justifyContent:'space-between', alignItems:'flex-end' }}>
          <div>
            <Eyebrow>Season 2024/25 · Piirid</Eyebrow>
            <div style={{ fontFamily:'Inter', fontWeight:700, fontSize:22, letterSpacing:'-0.01em', marginTop:2 }}>
              Agenda
            </div>
            <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginTop:2 }}>
              10 upcoming events · 6 awaiting RSVP
            </div>
          </div>
          <div style={{ display:'flex', gap:10, alignItems:'center' }}>
            <ExternalToggle on={false} />
            <span style={{ color:'var(--ink4)' }}>·</span>
            <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>View: <span style={{ color:'var(--ink)', fontWeight:600 }}>list</span> · week · month</span>
          </div>
        </div>

        <div style={{ flex:1, overflow:'hidden', padding:'14px 24px', display:'grid', gridTemplateColumns:'1fr 260px', gap:24, minHeight:0 }}>
          {/* Agenda list */}
          <div style={{ overflow:'hidden' }}>
            <div style={{ fontFamily:'Inter', fontSize:10, fontWeight:600, letterSpacing:'0.12em', color:'var(--ink4)', textTransform:'uppercase', margin:'0 0 4px' }}>This week</div>
            {AGENDA.slice(0,3).map(ev => <EventRow key={ev.id} ev={ev} />)}

            <div style={{ fontFamily:'Inter', fontSize:10, fontWeight:600, letterSpacing:'0.12em', color:'var(--ink4)', textTransform:'uppercase', margin:'16px 0 4px' }}>Next week</div>
            {AGENDA.slice(3,6).map(ev => <EventRow key={ev.id} ev={ev} />)}

            <div style={{ fontFamily:'Inter', fontSize:10, fontWeight:600, letterSpacing:'0.12em', color:'var(--ink4)', textTransform:'uppercase', margin:'16px 0 4px' }}>Later in May</div>
            {AGENDA.slice(6,9).map(ev => <EventRow key={ev.id} ev={ev} />)}

            <div style={{ fontFamily:'Inter', fontSize:10, fontWeight:600, letterSpacing:'0.12em', color:'var(--ink4)', textTransform:'uppercase', margin:'16px 0 4px' }}>June</div>
            {AGENDA.slice(9).map(ev => <EventRow key={ev.id} ev={ev} />)}

            <div style={{ marginTop:14, textAlign:'center' }}>
              <button className="sk-btn ghost" style={{ fontSize:11 }}>Show full season (24 more) →</button>
            </div>
          </div>

          {/* Right rail */}
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div className="sk-box accent" style={{ padding:10, background:'var(--paper)' }}>
              <Eyebrow>Next up · in 5 days</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:14, fontWeight:700, marginTop:4 }}>Reekviem — Duruflé</div>
              <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>Sat 03 May · 19:00 · Kaarli kirik</div>
              <div style={{ marginTop:8, fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>Your RSVP:</div>
              <div style={{ marginTop:4 }}><RSVP state="yes" /></div>
            </div>

            <div className="sk-box" style={{ padding:10 }}>
              <Eyebrow style={{ marginBottom:6 }}>Awaiting your RSVP</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink2)', lineHeight:1.55 }}>
                · Rehearsal · Mon 12 May<br/>
                · Kevadkontsert · 24 May<br/>
                · Spring Gala (Collegium)<br/>
                <span style={{ color:'var(--ink3)' }}>· +3 more</span>
              </div>
            </div>

            <div className="sk-box soft" style={{ padding:10 }}>
              <Eyebrow style={{ marginBottom:6 }}>Legend</Eyebrow>
              <Legend />
            </div>

            <div className="sk-box dashed" style={{ padding:10 }}>
              <Eyebrow style={{ marginBottom:6 }}>Your commitments</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink2)', lineHeight:1.6 }}>
                <div style={{ display:'flex', justifyContent:'space-between' }}><span>This choir</span><span className="mono">8 events</span></div>
                <div style={{ display:'flex', justifyContent:'space-between', color:'var(--ink3)' }}><span>Collegium Musicale</span><span className="mono">1 event</span></div>
                <div style={{ display:'flex', justifyContent:'space-between', color:'var(--ink3)' }}><span>Rae Kammerkoor</span><span className="mono">1 event</span></div>
              </div>
            </div>
          </div>
        </div>

        {/* Repertoire band */}
        <div style={{ borderTop:'1.5px solid var(--ink5)', padding:'14px 24px 18px', background:'var(--paper2)' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:6 }}>
            <div>
              <Eyebrow>Season repertoire</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:15, fontWeight:700 }}>6 works · 4 active</div>
            </div>
            <div style={{ fontFamily:'Inter', fontSize:11 }}>
              <span style={{ color:'var(--ink)', fontWeight:600 }}>All</span>
              <span style={{ color:'var(--ink4)', margin:'0 8px' }}>·</span>
              <span style={{ color:'var(--ink3)' }}>Active</span>
              <span style={{ color:'var(--ink4)', margin:'0 8px' }}>·</span>
              <span style={{ color:'var(--ink3)' }}>Learning</span>
              <span style={{ color:'var(--ink4)', margin:'0 8px' }}>·</span>
              <span style={{ color:'var(--ink3)' }}>Retired</span>
            </div>
          </div>
          <div style={{ maxHeight:140, overflow:'hidden' }}>
            {REPERTOIRE.slice(0,3).map((r,i)=><RepertoireRow key={i} item={r} />)}
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.M1ListFirst = M1ListFirst;
