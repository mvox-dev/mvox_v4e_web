// N2 — Grouped by topic. Collapsible topic "threads" gather all notices
// (announcements, polls, system events) that share a topic tag.
// Feels less like a chat, more like Notion-style grouped blocks.

function N2GroupedByTopic() {
  // Group notices by topic; items without a topic go into "General"
  const groups = {};
  NOTICES.forEach(n => {
    const key = n.topic || '__general';
    (groups[key] ??= []).push(n);
  });
  const topicOrder = ['Reekviem', 'Retreat 2025', '__general'];

  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor/notices">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column' }}>
        <WorkspaceNav />
        <NoticesSubnav />

        {/* Page header */}
        <div style={{
          padding:'14px 24px 10px', borderBottom:'1px solid var(--ink5)',
          display:'flex', justifyContent:'space-between', alignItems:'flex-end',
        }}>
          <div>
            <Eyebrow>Notices · grouped</Eyebrow>
            <div style={{ fontFamily:'Inter', fontWeight:700, fontSize:22, letterSpacing:'-0.01em', marginTop:2 }}>
              By topic
            </div>
            <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginTop:2 }}>
              3 topics · 10 notices · 3 unread
            </div>
          </div>
          <div style={{ display:'flex', gap:6, alignItems:'center', fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
            <span>View</span>
            <span style={{ padding:'3px 9px', fontFamily:'Inter', fontSize:11 }}>Flat</span>
            <span style={{ padding:'3px 9px', border:'1.25px solid var(--ink)', borderRadius:3, fontWeight:600, color:'var(--ink)' }}>Grouped</span>
            <span style={{ padding:'3px 9px' }}>Inbox</span>
          </div>
        </div>

        {/* Body */}
        <div style={{ flex:1, overflow:'hidden', padding:'14px 24px 24px', display:'flex', flexDirection:'column', gap:14 }}>
          <Composer variant="collapsed" />

          {topicOrder.map(key => {
            const items = groups[key];
            if (!items) return null;
            const label = key === '__general' ? 'General' : key;
            const isOpen = key !== '__general';
            return (
              <TopicGroup key={key} label={label} items={items} expanded={isOpen} />
            );
          })}

          <div style={{ textAlign:'center', padding:'4px 0 10px' }}>
            <button className="sk-btn ghost" style={{ fontSize:11 }}>+ Start a new topic</button>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

function TopicGroup({ label, items, expanded }) {
  const unread = items.filter(n => n.unread).length;
  const latest = items[0];
  return (
    <div style={{
      border: '1.5px solid var(--ink4)', borderRadius: 6,
      background: 'var(--paper)', overflow: 'hidden',
    }}>
      {/* Topic header */}
      <div style={{
        padding: '10px 14px', background: 'var(--paper2)',
        borderBottom: expanded ? '1px solid var(--ink5)' : 'none',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <span style={{
          fontSize: 12, color: 'var(--ink3)',
          transform: expanded ? 'rotate(90deg)' : 'rotate(0)',
          transition: 'transform 0.15s', display: 'inline-block',
        }}>▸</span>
        <span style={{
          fontFamily: 'Inter', fontSize: 14, fontWeight: 700,
          color: 'var(--ink)', letterSpacing: '-0.005em',
        }}>#{label}</span>
        <span style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)' }}>
          {items.length} {items.length === 1 ? 'notice' : 'notices'}
        </span>
        {unread > 0 && (
          <span style={{
            background: 'var(--accent)', color: '#fff',
            fontFamily: 'Inter', fontSize: 9, fontWeight: 700,
            padding: '1px 6px', borderRadius: 999, letterSpacing: '0.05em',
          }}>{unread} NEW</span>
        )}
        <span style={{ flex: 1 }} />
        <span style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink4)' }}>
          Last activity <span className="mono">{latest.when}</span>
        </span>
        <span style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)', display:'inline-flex', gap: 8 }}>
          <span className="sk-underline">Follow</span>
          <span className="sk-underline">Mute</span>
        </span>
      </div>

      {/* Items */}
      {expanded && (
        <div style={{ padding: '0 14px' }}>
          {items.map((n, i) => (
            <InlineNotice
              key={n.id}
              notice={n}
              isLast={i === items.length - 1}
            />
          ))}
        </div>
      )}

      {/* Topic composer footer */}
      {expanded && (
        <div style={{
          padding: '8px 14px', borderTop: '1px dashed var(--ink5)',
          background: 'var(--paper2)', display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <div style={{
            width: 24, height: 24, borderRadius: 999,
            background: 'var(--paper)', border: '1.25px solid var(--ink4)',
            fontFamily: 'Inter', fontSize: 10, fontWeight: 600, color: 'var(--ink2)',
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          }}>M</div>
          <span style={{ flex: 1, fontFamily: 'Inter', fontSize: 11, color: 'var(--ink4)' }}>
            Add a notice to <strong style={{ color: 'var(--ink3)', fontWeight: 600 }}>#{label}</strong>…
          </span>
          <span className="sk-icon" style={{ width: 20, height: 20, fontSize: 11 }}>✎</span>
          <span className="sk-icon" style={{ width: 20, height: 20, fontSize: 11 }}>◉</span>
          <span className="sk-icon" style={{ width: 20, height: 20, fontSize: 11 }}>📎</span>
        </div>
      )}
    </div>
  );
}

function InlineNotice({ notice, isLast }) {
  const n = notice;
  const a = NOTICE_AUTHORS[n.author];
  return (
    <div style={{
      display: 'flex', gap: 10, padding: '12px 0',
      borderBottom: isLast ? 'none' : '1px dashed var(--ink5)',
      position: 'relative',
    }}>
      {/* unread dot */}
      <div style={{
        position: 'absolute', top: 18, left: -10,
        width: 6, height: 6, borderRadius: 999,
        background: n.unread ? 'var(--accent)' : 'transparent',
      }} />

      <Avatar authorKey={n.author} size={28} />

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap',
          fontFamily: 'Inter', fontSize: 11,
        }}>
          <span style={{ fontWeight: 600, color: 'var(--ink)' }}>{a.name}</span>
          <RoleBadge role={a.role} />
          {n.type !== 'announcement' && <TypeChip type={n.type} />}
          {n.pinned && (
            <span style={{
              fontFamily: 'Inter', fontSize: 9, fontWeight: 700,
              letterSpacing: '0.1em', textTransform: 'uppercase',
              color: 'var(--ink3)',
            }}>📌 Pinned</span>
          )}
          <span style={{ color: 'var(--ink4)' }}>·</span>
          <span className="mono" style={{ color: 'var(--ink3)', fontSize: 10 }}>{n.when}</span>
        </div>

        <div style={{
          fontFamily: 'Inter', fontSize: 13, fontWeight: 600,
          color: 'var(--ink)', marginTop: 2,
        }}>{n.title}</div>

        {n.body && (
          <div style={{
            fontFamily: 'Inter', fontSize: 12, color: 'var(--ink2)',
            marginTop: 2, lineHeight: 1.45,
          }}>{n.body}</div>
        )}

        {n.poll && <PollBody poll={n.poll} />}
        {n.link && <LinkedItem link={n.link} type={n.type} />}

        <div style={{ marginTop: 6 }}>
          <Reactions reactions={n.reactions} youReacted={n.youReacted} compact />
        </div>
      </div>
    </div>
  );
}

window.N2GroupedByTopic = N2GroupedByTopic;
