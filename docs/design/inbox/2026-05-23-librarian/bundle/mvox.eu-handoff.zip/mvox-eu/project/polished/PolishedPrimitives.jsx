// Polished primitives — production-quality skin for the Vault workspace.
// Built directly on Polyphony tokens: Manrope, blue-600 primary, gray neutrals.

if (typeof document !== 'undefined' && !document.getElementById('pp-skin-styles')) {
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap';
  document.head.appendChild(link);

  const s = document.createElement('style');
  s.id = 'pp-skin-styles';
  s.textContent = `
    .pp {
      --pp-blue-50:#eff6ff; --pp-blue-100:#dbeafe; --pp-blue-200:#bfdbfe;
      --pp-blue-500:#3b82f6; --pp-blue-600:#2563eb; --pp-blue-700:#1d4ed8; --pp-blue-800:#1e40af;
      --pp-gray-50:#f9fafb; --pp-gray-100:#f3f4f6; --pp-gray-200:#e5e7eb;
      --pp-gray-300:#d1d5db; --pp-gray-400:#9ca3af; --pp-gray-500:#6b7280;
      --pp-gray-600:#4b5563; --pp-gray-700:#374151; --pp-gray-800:#1f2937; --pp-gray-900:#111827;
      --pp-green-100:#dcfce7; --pp-green-600:#16a34a; --pp-green-700:#15803d; --pp-green-800:#166534;
      --pp-red-100:#fee2e2; --pp-red-600:#dc2626; --pp-red-800:#991b1b;
      --pp-amber-100:#fef3c7; --pp-amber-500:#f59e0b; --pp-amber-600:#d97706;
      --pp-orange-600:#ea580c; --pp-orange-700:#c2410c;
      --pp-yellow-100:#fef9c3; --pp-yellow-600:#ca8a04; --pp-yellow-800:#854d0e;
      --pp-purple-100:#f3e8ff; --pp-purple-200:#e9d5ff; --pp-purple-600:#9333ea; --pp-purple-800:#6b21a8;
      --pp-teal-100:#ccfbf1; --pp-teal-200:#99f6e4; --pp-teal-800:#115e59;
      font-family:'Manrope', system-ui, -apple-system, sans-serif;
      color: var(--pp-gray-900);
      -webkit-font-smoothing: antialiased;
      font-feature-settings: "cv11","ss01";
    }
    .pp .mono { font-family:'JetBrains Mono', ui-monospace, Menlo, monospace; }

    .pp-frame {
      background:#fff; border-radius:14px; overflow:hidden;
      box-shadow: 0 12px 40px -20px rgb(15 23 42 / .35), 0 0 0 1px var(--pp-gray-200);
      height:100%; display:flex; flex-direction:column;
    }
    .pp-framehead {
      padding:9px 16px; border-bottom:1px solid var(--pp-gray-100);
      font-size:11px; color:var(--pp-gray-500); letter-spacing:.05em;
      text-transform:uppercase; font-weight:600;
      display:flex; justify-content:space-between; align-items:center; background:#fafbfc;
      flex-shrink:0;
    }
    .pp-framehead .url { font-family:'JetBrains Mono', monospace; font-size:10.5px; color:var(--pp-gray-400); text-transform:none; letter-spacing:0; }

    .pp-app { background:var(--pp-gray-50); flex:1; overflow:hidden; display:flex; flex-direction:column; }

    /* Topbar */
    .pp-topbar { display:flex; align-items:center; justify-content:space-between; padding:12px 24px; background:#fff; border-bottom:1px solid var(--pp-gray-200); flex-shrink:0; }
    .pp-tb-left { display:flex; align-items:center; gap:24px; }
    .pp-brand { display:flex; align-items:center; gap:9px; font-size:15px; font-weight:700; letter-spacing:-0.01em; }
    .pp-brand svg { color:var(--pp-blue-600); }
    .pp-org { display:flex; align-items:center; gap:6px; font-size:12.5px; color:var(--pp-gray-500); padding:5px 10px; border-radius:6px; background:var(--pp-gray-100); }
    .pp-org strong { color:var(--pp-gray-800); font-weight:600; }
    .pp-tb-nav { display:flex; gap:2px; }
    .pp-tb-nav a { padding:6px 11px; border-radius:6px; font-size:13px; color:var(--pp-gray-600); font-weight:500; cursor:pointer; }
    .pp-tb-nav a.active { background:var(--pp-blue-50); color:var(--pp-blue-700); }
    .pp-tb-right { display:flex; align-items:center; gap:12px; }
    .pp-avatar { width:30px; height:30px; border-radius:50%; background:var(--pp-blue-100); color:var(--pp-blue-700); font-weight:600; display:grid; place-items:center; font-size:12px; }

    /* Buttons */
    .pp-btn { font-family:inherit; font-size:13px; font-weight:500; border:1px solid transparent; border-radius:8px; padding:7px 13px; cursor:pointer; display:inline-flex; align-items:center; gap:6px; }
    .pp-btn-primary { background:var(--pp-blue-600); color:#fff; }
    .pp-btn-primary:hover { background:var(--pp-blue-700); }
    .pp-btn-secondary { background:#fff; color:var(--pp-gray-700); border-color:var(--pp-gray-300); }
    .pp-btn-secondary:hover { background:var(--pp-gray-50); }
    .pp-btn-ghost { background:transparent; color:var(--pp-gray-600); }
    .pp-btn-ghost:hover { background:var(--pp-gray-100); color:var(--pp-gray-900); }
    .pp-btn-sm { padding:4px 9px; font-size:12px; border-radius:6px; }

    /* Chips & badges */
    .pp-chip { display:inline-flex; align-items:center; gap:4px; font-size:11px; font-weight:500; padding:2px 9px; border-radius:9999px; border:1px solid; line-height:1.4; }
    .pp-chip-rehearsal { background:var(--pp-blue-50); color:var(--pp-blue-700); border-color:var(--pp-blue-200); }
    .pp-chip-concert   { background:#faf5ff; color:var(--pp-purple-800); border-color:var(--pp-purple-200); }
    .pp-chip-sectional { background:#fffbeb; color:var(--pp-amber-700, #b45309); border-color:#fde68a; }
    .pp-chip-retreat   { background:#ecfdf5; color:#047857; border-color:#a7f3d0; }
    .pp-chip-tour      { background:#fff7ed; color:var(--pp-orange-700); border-color:#fed7aa; }

    .pp-badge { display:inline-flex; align-items:center; gap:3px; font-size:11px; font-weight:500; padding:2px 7px; border-radius:4px; }
    .pp-badge-voice { background:var(--pp-purple-100); color:var(--pp-purple-800); }
    .pp-badge-section { background:var(--pp-teal-100); color:var(--pp-teal-800); }
    .pp-badge-active { background:var(--pp-blue-50); color:var(--pp-blue-700); border:1px solid var(--pp-blue-200); }
    .pp-badge-learning { background:var(--pp-amber-100); color:var(--pp-amber-700, #b45309); border:1px solid #fde68a; }
    .pp-badge-retired { background:var(--pp-gray-100); color:var(--pp-gray-600); border:1px solid var(--pp-gray-200); }

    /* Eyebrow */
    .pp-eyebrow { font-size:10.5px; font-weight:600; text-transform:uppercase; letter-spacing:.08em; color:var(--pp-gray-500); }

    /* Page header bits */
    .pp-h1 { font-size:22px; font-weight:700; letter-spacing:-0.02em; margin:0; color:var(--pp-gray-900); }
    .pp-lead { font-size:13px; color:var(--pp-gray-500); margin:3px 0 0; }

    /* Card */
    .pp-card { background:#fff; border:1px solid var(--pp-gray-200); border-radius:10px; }
    .pp-card-pad { padding:18px; }

    /* Subnav (tabs) */
    .pp-subnav { display:flex; align-items:center; gap:24px; padding:0 24px; background:#fff; border-bottom:1px solid var(--pp-gray-200); flex-shrink:0; }
    .pp-subnav a { padding:11px 0; font-size:13px; color:var(--pp-gray-500); font-weight:500; border-bottom:2px solid transparent; cursor:pointer; }
    .pp-subnav a.active { color:var(--pp-gray-900); border-bottom-color:var(--pp-blue-600); }

    /* RSVP grid */
    .pp-rsvp { display:grid; grid-template-columns:repeat(4,1fr); gap:5px; }
    .pp-rsvp button { padding:5px 4px; font-size:11.5px; font-weight:500; border-radius:5px; border:1px solid var(--pp-gray-300); background:#fff; color:var(--pp-gray-700); cursor:pointer; font-family:inherit; }
    .pp-rsvp .yes-on { background:var(--pp-green-600); color:#fff; border-color:var(--pp-green-700); }
    .pp-rsvp .no-on  { background:var(--pp-red-600); color:#fff; border-color:#b91c1c; }
    .pp-rsvp .maybe-on { background:var(--pp-yellow-600); color:#fff; border-color:#a16207; }
    .pp-rsvp .late-on { background:var(--pp-orange-600); color:#fff; border-color:var(--pp-orange-700); }

    /* Tiny chip */
    .pp-pill { display:inline-flex; align-items:center; gap:4px; font-size:11px; padding:1px 8px; border-radius:9999px; background:var(--pp-gray-100); color:var(--pp-gray-700); }

    /* Hide default scrollbar on inner panels */
    .pp-scroll::-webkit-scrollbar { width:6px; height:6px; }
    .pp-scroll::-webkit-scrollbar-thumb { background:var(--pp-gray-300); border-radius:3px; }
  `;
  document.head.appendChild(s);
}

// ─── Brand mark + Topbar ──────────────────────────────────────────────
function PPBrand() {
  return (
    <span className="pp-brand">
      <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/>
      </svg>
      Multivox
    </span>
  );
}

function PPTopbar({ active = 'agenda' }) {
  const tabs = [
    { id:'agenda',   label:'Agenda' },
    { id:'library',  label:'Library' },
    { id:'roster',   label:'Roster' },
    { id:'notices',  label:'Notices' },
  ];
  return (
    <div className="pp-topbar">
      <div className="pp-tb-left">
        <PPBrand />
        <div className="pp-org">Choir: <strong>Kaaren Kammerkoor</strong></div>
      </div>
      <div className="pp-tb-right">
        <button className="pp-btn pp-btn-ghost pp-btn-sm" style={{ position:'relative' }}>
          Inbox
          <span style={{ background:'var(--pp-red-600)', color:'#fff', borderRadius:9999, fontSize:9, padding:'1px 5px', fontWeight:600 }}>3</span>
        </button>
        <div className="pp-avatar">ML</div>
      </div>
    </div>
  );
}

function PPSubnav({ active = 'agenda' }) {
  const tabs = ['Agenda','Library','Roster','Notices'];
  return (
    <div className="pp-subnav">
      {tabs.map(t => (
        <a key={t} className={t.toLowerCase() === active ? 'active' : ''}>{t}</a>
      ))}
      <span style={{ flex:1 }} />
      <a style={{ color:'var(--pp-gray-400)', fontSize:12 }}>View public page ↗</a>
    </div>
  );
}

// Browser-frame wrapper that matches the polished Vault chrome
function PPFrame({ url, children }) {
  return (
    <div className="pp-frame">
      <div className="pp-framehead">
        <span>Members workspace · Vault</span>
        <span className="url">{url}</span>
      </div>
      <div className="pp-app">{children}</div>
    </div>
  );
}

Object.assign(window, { PPBrand, PPTopbar, PPSubnav, PPFrame });
