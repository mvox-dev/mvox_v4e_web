// V4 — Roster & stats
// Big social-proof strip leads (years active, choirs, singers, concerts this season).
// Then sections. Good for "we are a serious, thriving organisation" pitch.

function V4RosterStats() {
  return (
    <BrowserFrame url="mvox.eu/o/eesti-segakooride-liit">
      <div className="sk" style={{ height: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <RegistryNav />
        <Breadcrumb trail={['Directory', 'Eesti Segakooride Liit']} />

        {/* Hero: name + stats strip */}
        <div style={{ padding: '22px 40px 0' }}>
          <Eyebrow>Umbrella organisation · Tallinn, Estonia</Eyebrow>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, margin: '6px 0 4px' }}>
            <div className="sk-hatch" style={{ width: 54, height: 54, borderRadius: 8, border: '1.5px solid var(--ink3)', flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'Inter', fontWeight: 800, fontSize: 32, lineHeight: 1, color: 'var(--ink)', letterSpacing: '-0.02em' }}>
                Eesti Segakooride Liit
              </div>
              <div style={{ fontFamily: 'Inter', fontSize: 13, color: 'var(--ink3)', marginTop: 4 }}>
                <span className="sk-highlight">Many voices, one harmony</span> — since 1962
              </div>
            </div>
            <button className="sk-btn primary">Get in touch</button>
          </div>
        </div>

        {/* Stats strip */}
        <div style={{ padding: '18px 40px', display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14, borderBottom: '1.5px solid var(--ink5)' }}>
          {[
            ['64', 'years', 'active'],
            ['24', 'member', 'choirs'],
            ['~460', 'singers', 'across Estonia'],
            ['38', 'concerts', 'this season'],
            ['192', 'works in', 'shared library'],
          ].map(([n, l1, l2], i) => (
            <div key={i} className="sk-box filled" style={{ padding: '10px 12px', textAlign: 'center' }}>
              <div style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 28, color: 'var(--accent)', letterSpacing: '-0.03em', lineHeight: 1 }}>{n}</div>
              <div style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink2)', marginTop: 5, lineHeight: 1.3 }}>
                {l1}<br/><span style={{ color: 'var(--ink3)' }}>{l2}</span>
              </div>
            </div>
          ))}
        </div>

        <div style={{ flex: 1, overflow: 'hidden', padding: '20px 40px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28, minHeight: 0 }}>
          {/* LEFT: about + leadership + sections */}
          <div>
            <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 15, margin: '0 0 6px', color: 'var(--ink2)' }}>About</h2>
            <Lines count={3} widths={['long', 'long', 'med']} />
            <p style={{ fontFamily: 'Caveat', color: 'var(--ink2)', fontSize: 14, margin: '6px 0 14px' }}>
              2 short paragraphs — what we do, who we are for
            </p>

            <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 15, margin: '16px 0 8px', color: 'var(--ink2)' }}>Leadership</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
              {[['Heli K.', 'Artistic Director'], ['Mart R.', 'Chair'], ['Liisa T.', 'Secretary']].map(([n, t], i) => (
                <div key={i} style={{ textAlign: 'center' }}>
                  <div className="sk-hatch" style={{ width: 56, height: 56, borderRadius: '50%', border: '1.5px solid var(--ink4)', margin: '0 auto 6px' }} />
                  <div style={{ fontFamily: 'Inter', fontSize: 12, fontWeight: 600 }}>{n}</div>
                  <div style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)' }}>{t}</div>
                </div>
              ))}
            </div>

            <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 15, margin: '18px 0 8px', color: 'var(--ink2)' }}>Aggregate voice sections</h2>
            {/* horizontal bars visualising section sizes */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[['Soprano', 142, 0.95], ['Alto', 118, 0.78], ['Tenor', 96, 0.64], ['Bass', 104, 0.69]].map(([v, n, w]) => (
                <div key={v} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 58, fontFamily: 'Inter', fontSize: 11, color: 'var(--ink2)' }}>{v}</div>
                  <div className="sk-box" style={{ flex: 1, height: 14, padding: 0, background: 'var(--paper)', position: 'relative', overflow: 'hidden' }}>
                    <div style={{ width: `${w * 100}%`, height: '100%', background: 'var(--accent)', opacity: 0.75 }} />
                  </div>
                  <div className="mono" style={{ width: 36, textAlign: 'right', color: 'var(--ink3)' }}>{n}</div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT: member choirs + contact */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
              <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 15, margin: 0, color: 'var(--ink2)' }}>Featured member choirs</h2>
              <span style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--accent)' }} className="sk-underline">See all 24 →</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[
                ['Kammerkoor Crede', 'Tallinn', 28, '1987'],
                ['Collegium Musicale', 'Tallinn', 24, '2010'],
                ['Tartu Akadeemiline', 'Tartu', 44, '1912'],
                ['RAM', 'Tallinn', 36, '1944'],
                ['Voces Musicales', 'Tallinn', 18, '2003'],
              ].map(([n, c, s, y], i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '7px 10px', border: '1px solid var(--ink5)', borderRadius: 4, background: 'var(--paper)' }}>
                  <div className="sk-hatch" style={{ width: 32, height: 32, borderRadius: 4, border: '1px solid var(--ink4)', flexShrink: 0 }} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: 'Inter', fontSize: 12, fontWeight: 600 }}>{n}</div>
                    <div style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)' }}>{c} · {s} singers · est. {y}</div>
                  </div>
                  <div style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--accent)' }} className="sk-underline">Visit ↗</div>
                </div>
              ))}
            </div>

            <div className="sk-box soft" style={{ padding: 12, marginTop: 16 }}>
              <Eyebrow style={{ marginBottom: 8 }}>Get in touch</Eyebrow>
              <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '5px 10px', fontFamily: 'Inter', fontSize: 12 }}>
                <span style={{ color: 'var(--ink3)' }}>Email</span>
                <span className="mono" style={{ color: 'var(--accent)' }}>info@esl.ee</span>
                <span style={{ color: 'var(--ink3)' }}>Web</span>
                <span className="mono" style={{ color: 'var(--accent)' }}>esl.ee</span>
                <span style={{ color: 'var(--ink3)' }}>Address</span>
                <span>Roosikrantsi 13, Tallinn</span>
              </div>
              <div style={{ display: 'flex', gap: 5, marginTop: 10 }}>
                <Chip>Facebook</Chip><Chip>Instagram</Chip><Chip>YouTube</Chip>
              </div>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.V4RosterStats = V4RosterStats;
