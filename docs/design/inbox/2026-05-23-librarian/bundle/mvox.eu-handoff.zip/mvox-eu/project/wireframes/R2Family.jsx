// R2 family — table-based roster, three states.
//
// R2.1  Table with contact columns, no singer selected (default view)
// R2.2  Same table + singer-detail modal open (clicked another singer)
// R2.3  Same table + profile-edit modal open (clicked own row)
//
// Design notes:
//   - Builds on R2's dense table + SATB section headers.
//   - Brings email + phone columns from R1 (inline contact, no expand needed).
//   - Modal replaces side-panel detail. Editing own profile is a separate modal.

// Who "you" are for this wireframe — Liisa Mets, a regular Soprano.
const YOU_ID = 3;

// ─── Shared shell ─────────────────────────────────────────────────────
function R2Shell({ selectedId = null, modal = null }) {
  const groups = bySection();
  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor/roster">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column', position:'relative' }}>
        <WorkspaceNav />
        <RosterSubnav />
        <RosterToolbar />

        {/* Table */}
        <div style={{ flex:1, overflow:'hidden', padding:'0 24px' }}>
          <R2xHeader />
          {SECTIONS.map(sec => (
            <div key={sec.id}>
              <SectionHeader section={sec} count={groups[sec.id].length} />
              {groups[sec.id].map(m => (
                <R2xRow
                  key={m.id}
                  member={m}
                  selected={m.id === selectedId}
                  isYou={m.id === YOU_ID}
                />
              ))}
            </div>
          ))}
        </div>

        {modal}
      </div>
    </BrowserFrame>
  );
}

// ─── Table header ─────────────────────────────────────────────────────
const R2X_COLS = '1.25fr 54px 80px 1.35fr 105px 68px 100px 50px 50px';

function R2xHeader() {
  const cols = [
    { label:'Singer',   align:'left'  },
    { label:'Sub.',     align:'left'  },
    { label:'Role',     align:'left'  },
    { label:'Contact',  align:'left'  },
    { label:'Phone',    align:'left'  },
    { label:'Birthday', align:'left'  },
    { label:'Attend.',  align:'left'  },
    { label:'RSVP',     align:'right' },
    { label:'Loans',    align:'right' },
  ];
  return (
    <div style={{
      display:'grid', gridTemplateColumns: R2X_COLS,
      gap:10, padding:'8px 14px 6px 4px',
      borderBottom:'1.5px solid var(--ink4)', background:'var(--paper2)',
      fontFamily:'Inter', fontSize:9, fontWeight:600, letterSpacing:'0.08em',
      textTransform:'uppercase', color:'var(--ink4)',
      position:'sticky', top:0, zIndex:2,
    }}>
      {cols.map(c => (
        <span key={c.label} style={{ textAlign:c.align }}>{c.label}</span>
      ))}
    </div>
  );
}

// ─── Data row ─────────────────────────────────────────────────────────
function R2xRow({ member, selected, isYou }) {
  const m = member;
  return (
    <div style={{
      display:'grid', gridTemplateColumns: R2X_COLS,
      gap:10, padding:'7px 14px 7px 4px',
      borderBottom:'1px solid var(--ink5)',
      alignItems:'center',
      background: selected ? 'var(--accent-soft)' : 'transparent',
      borderLeft: selected ? '3px solid var(--accent)' : '3px solid transparent',
      marginLeft: selected ? -3 : 0,
    }}>
      {/* Singer */}
      <div style={{ display:'flex', alignItems:'center', gap:8, minWidth:0 }}>
        <MemberAvatar member={m} size={22} />
        <span style={{
          fontFamily:'Inter', fontSize:12, fontWeight:600, color:'var(--ink)',
          overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
        }}>{m.name}</span>
        {isYou && <YouChip />}
        <SectionLeaderChip member={m} />
        <StatusChip status={m.status} />
      </div>

      {/* Subsection chip (only if section has subs) */}
      <span><VoiceChip member={m} /></span>

      {/* Role */}
      <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
        {m.role || '—'}
      </span>

      {/* Contact (email) */}
      <span className="sk-underline" style={{
        fontFamily:'Inter', fontSize:11, color:'var(--ink2)',
        overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
      }}>{m.email}</span>

      {/* Phone */}
      <span className="mono" style={{ fontSize:11, color:'var(--ink3)' }}>
        {m.phone}
      </span>

      {/* Birthday */}
      <BirthdayCell member={m} />

      {/* Attendance */}
      <Attendance value={m.attendance} compact />

      {/* RSVP */}
      <span className="mono" style={{ fontSize:11, color: m.rsvpOpen > 0 ? 'var(--accent)' : 'var(--ink4)', textAlign:'right' }}>
        {m.rsvpOpen > 0 ? m.rsvpOpen : '—'}
      </span>

      {/* Loans */}
      <span className="mono" style={{ fontSize:11, color: m.loans > 0 ? 'var(--ink2)' : 'var(--ink4)', textAlign:'right' }}>
        {m.loans > 0 ? m.loans : '—'}
      </span>
    </div>
  );
}

function YouChip() {
  return (
    <span style={{
      fontFamily:'Inter', fontSize:9, fontWeight:700, letterSpacing:'0.08em',
      padding:'1px 5px', borderRadius:3,
      background:'var(--ink)', color:'var(--paper)',
    }}>YOU</span>
  );
}

// ═══ R2.1 — no selection ══════════════════════════════════════════════
function R2_1Table() {
  return <R2Shell />;
}

// ═══ R2.2 — singer detail modal open ══════════════════════════════════
function R2_2Modal() {
  const member = MEMBERS.find(m => m.id === 2); // Kaarin (conductor)
  return (
    <R2Shell
      selectedId={member.id}
      modal={<R2xDetailModal member={member} />}
    />
  );
}

// ═══ R2.3 — profile edit modal (own row) ══════════════════════════════
function R2_3Edit() {
  const member = MEMBERS.find(m => m.id === YOU_ID); // Liisa Mets
  return (
    <R2Shell
      selectedId={member.id}
      modal={<R2xEditModal member={member} />}
    />
  );
}

// ─── Detail modal (view-only) ─────────────────────────────────────────
function R2xDetailModal({ member }) {
  const m = member;
  return (
    <ModalBackdrop>
      <div style={{
        width:560, background:'var(--paper)',
        border:'1.5px solid var(--ink3)', borderRadius:6,
        boxShadow:'8px 8px 0 rgba(42,38,32,0.12)',
        display:'flex', flexDirection:'column', overflow:'hidden',
      }}>
        {/* Header */}
        <div style={{
          padding:'14px 18px', borderBottom:'1.5px solid var(--ink4)', background:'var(--paper2)',
          display:'flex', justifyContent:'space-between', alignItems:'flex-start',
        }}>
          <div style={{ display:'flex', gap:12, alignItems:'center' }}>
            <MemberAvatar member={m} size={44} />
            <div>
              <div style={{ fontFamily:'Inter', fontSize:16, fontWeight:700, letterSpacing:'-0.005em' }}>{m.name}</div>
              <div style={{ display:'flex', gap:5, marginTop:3, alignItems:'center' }}>
                <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink2)', fontWeight:600 }}>
                  {SECTION_BY_ID[m.section].label}{m.sub ? ` · ${m.sub}` : ''}
                </span>
                <VoiceChip member={m} />
                <SectionLeaderChip member={m} />
                <RoleChip role={m.role} />
                <StatusChip status={m.status} />
              </div>
            </div>
          </div>
          <span style={{ fontFamily:'Inter', fontSize:16, color:'var(--ink3)', cursor:'pointer' }}>✕</span>
        </div>

        {/* Body */}
        <div style={{ padding:'14px 18px', display:'grid', gridTemplateColumns:'1fr 1fr', gap:18 }}>
          <div>
            <Eyebrow>Contact</Eyebrow>
            <div style={{ fontFamily:'Inter', fontSize:11.5, color:'var(--ink2)', marginTop:4, lineHeight:1.6 }}>
              <div><span className="sk-underline">{m.email}</span></div>
              <div className="mono">{m.phone}</div>
              <div style={{ color:'var(--ink3)' }}>joined {m.joined}</div>
              {m.birthday && (
                <div style={{ color:'var(--ink3)', marginTop:2 }}>
                  Birthday <BirthdayCell member={m} />
                </div>
              )}
            </div>
          </div>
          <div>
            <Eyebrow>Voices · biographical</Eyebrow>
            <div style={{ marginTop:5 }}>
              <VoicesList voices={m.voices} />
            </div>
            <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)', marginTop:4, lineHeight:1.5 }}>
              Singing in <strong style={{ color:'var(--ink2)' }}>{SECTION_BY_ID[m.section].label}{m.sub ? ` / ${m.sub}` : ''}</strong> this season.
            </div>
          </div>
          <div style={{ gridColumn:'1 / -1', height:1, background:'var(--ink5)' }} />
          <div>
            <Eyebrow>Attendance</Eyebrow>
            <div style={{ marginTop:4 }}>
              <Attendance value={m.attendance} showLabel={true} />
            </div>
            <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)', marginTop:4 }}>
              {Math.round(m.attendance*12)} of 12 last rehearsals
            </div>
          </div>
          <div>
            <Eyebrow>Open RSVPs · {m.rsvpOpen}</Eyebrow>
            <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink2)', marginTop:4, lineHeight:1.55 }}>
              {m.rsvpOpen > 0 ? (
                <>
                  <div>Tue 7 May — Tutti</div>
                  <div>Thu 9 May — Sectional</div>
                </>
              ) : <span style={{ color:'var(--ink4)' }}>All responded.</span>}
            </div>
          </div>
          <div>
            <Eyebrow>Library loans · {m.loans} out</Eyebrow>
            <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink2)', marginTop:4, lineHeight:1.55 }}>
              {m.loans > 0 ? (
                <div>Duruflé · <em>Requiem</em> <span className="mono" style={{ color:'var(--ink3)' }}>#001</span></div>
              ) : <span style={{ color:'var(--ink4)' }}>None out.</span>}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          padding:'10px 18px', borderTop:'1.5px solid var(--ink4)', background:'var(--paper2)',
          display:'flex', gap:6, justifyContent:'flex-end',
        }}>
          <button className="sk-btn ghost" style={{ fontSize:11 }}>⇣ vCard</button>
          <button className="sk-btn primary" style={{ fontSize:11 }}>✉ Message</button>
        </div>
      </div>
    </ModalBackdrop>
  );
}

// ─── Edit modal (own profile) ─────────────────────────────────────────
function R2xEditModal({ member }) {
  const m = member;
  return (
    <ModalBackdrop>
      <div style={{
        width:520, background:'var(--paper)',
        border:'1.5px solid var(--ink3)', borderRadius:6,
        boxShadow:'8px 8px 0 rgba(42,38,32,0.12)',
        display:'flex', flexDirection:'column', overflow:'hidden',
      }}>
        {/* Header */}
        <div style={{
          padding:'14px 18px', borderBottom:'1.5px solid var(--ink4)', background:'var(--paper2)',
          display:'flex', justifyContent:'space-between', alignItems:'center',
        }}>
          <div>
            <Eyebrow>Edit your profile</Eyebrow>
            <div style={{ fontFamily:'Inter', fontSize:15, fontWeight:700, letterSpacing:'-0.005em', marginTop:2 }}>
              {m.name}
            </div>
          </div>
          <span style={{ fontFamily:'Inter', fontSize:16, color:'var(--ink3)', cursor:'pointer' }}>✕</span>
        </div>

        {/* Form */}
        <div style={{ padding:'14px 18px', display:'flex', flexDirection:'column', gap:12 }}>
          {/* Avatar */}
          <div style={{ display:'flex', alignItems:'center', gap:12 }}>
            <MemberAvatar member={m} size={48} />
            <div>
              <button className="sk-btn ghost" style={{ fontSize:11 }}>Upload photo</button>
              <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)', marginTop:4 }}>
                PNG or JPG · square · ≤ 2MB
              </div>
            </div>
          </div>

          {/* Display name */}
          <EditField label="Display name" value={m.name} hint="How others see you in the choir." />

          {/* Email */}
          <EditField label="Email" value={m.email} type="email" hint="Used for RSVP reminders and notifications." />

          {/* Phone */}
          <EditField label="Phone" value={m.phone} hint="Only visible to your choir." />

          {/* Birthday */}
          <BirthdayEditor value={m.birthday} />

          {/* Voices — biographical, user-editable */}
          <div>
            <Eyebrow>Your voices & instruments</Eyebrow>
            <div style={{ marginTop:5 }}>
              <VoicesList voices={m.voices} />
              <span style={{
                display:'inline-block', marginLeft:4,
                fontFamily:'Inter', fontSize:10, color:'var(--ink3)',
                padding:'1px 7px', border:'1px dashed var(--ink4)', borderRadius:999,
                cursor:'pointer',
              }}>＋ add</span>
            </div>
            <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)', marginTop:4 }}>
              What you can sing or play. Edit freely — this is about you.
            </div>
          </div>

          {/* Section — gated, conductor-controlled */}
          <div style={{
            padding:'10px 12px', border:'1px solid var(--ink5)', borderRadius:4,
            background:'var(--paper2)',
            display:'flex', alignItems:'center', gap:10,
          }}>
            <div style={{ flex:1 }}>
              <Eyebrow>Section in Kaaren Kammerkoor</Eyebrow>
              <div style={{ display:'flex', gap:6, alignItems:'center', marginTop:5 }}>
                <span style={{ fontFamily:'Inter', fontSize:12, fontWeight:600, color:'var(--ink)' }}>
                  {SECTION_BY_ID[m.section].label}{m.sub ? ` · ${m.sub}` : ''}
                </span>
                <VoiceChip member={m} />
              </div>
            </div>
            <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)', textAlign:'right', lineHeight:1.45 }}>
              Only the conductor<br />can change this.<br />
              <span className="sk-underline" style={{ color:'var(--ink2)' }}>Request change</span>
            </div>
          </div>

          {/* Notification prefs */}
          <div>
            <Eyebrow>Email me about</Eyebrow>
            <div style={{ marginTop:6, display:'flex', flexDirection:'column', gap:5 }}>
              <Check label="New rehearsals and concerts" checked />
              <Check label="RSVP reminders (24h before)" checked />
              <Check label="Library loan due dates" checked />
              <Check label="All notices" checked={false} />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{
          padding:'10px 18px', borderTop:'1.5px solid var(--ink4)', background:'var(--paper2)',
          display:'flex', justifyContent:'space-between', alignItems:'center', gap:6,
        }}>
          <button className="sk-btn ghost" style={{ fontSize:11, color:'var(--red)', borderColor:'var(--red)' }}>
            Leave choir…
          </button>
          <div style={{ display:'flex', gap:6 }}>
            <button className="sk-btn ghost" style={{ fontSize:11 }}>Cancel</button>
            <button className="sk-btn primary" style={{ fontSize:11 }}>Save changes</button>
          </div>
        </div>
      </div>
    </ModalBackdrop>
  );
}

// ─── Shared form bits ─────────────────────────────────────────────────
function EditField({ label, value, type = 'text', hint }) {
  return (
    <label style={{ display:'flex', flexDirection:'column', gap:3 }}>
      <span style={{
        fontFamily:'Inter', fontSize:10, fontWeight:600, letterSpacing:'0.06em',
        textTransform:'uppercase', color:'var(--ink3)',
      }}>{label}</span>
      <input
        type={type}
        defaultValue={value}
        style={{
          fontFamily: type === 'email' || label === 'Phone' ? 'JetBrains Mono, monospace' : 'Inter',
          fontSize:12, color:'var(--ink)', background:'var(--paper)',
          border:'1.25px solid var(--ink4)', borderRadius:3,
          padding:'7px 9px', outline:'none',
        }}
      />
      {hint && (
        <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)' }}>{hint}</span>
      )}
    </label>
  );
}

function Check({ label, checked }) {
  return (
    <label style={{ display:'flex', alignItems:'center', gap:8, fontFamily:'Inter', fontSize:11.5, color:'var(--ink2)', cursor:'pointer' }}>
      <span style={{
        width:13, height:13, borderRadius:2, border:'1.25px solid var(--ink3)',
        background: checked ? 'var(--ink)' : 'var(--paper)',
        color:'var(--paper)', display:'inline-flex', alignItems:'center', justifyContent:'center',
        fontSize:9, fontWeight:700, flexShrink:0,
      }}>{checked ? '✓' : ''}</span>
      {label}
    </label>
  );
}

// ─── Birthday editor ─────────────────────────────────────────────────
// Three modes:
//   'full'    — full date (month, day, year)
//   'partial' — month + day only (privacy-friendly)
//   'none'    — not set
function BirthdayEditor({ value }) {
  const parsed = parseBirthday(value);
  const initialMode = parsed ? (parsed.hasYear ? 'full' : 'partial') : 'none';
  const [mode, setMode] = React.useState(initialMode);

  const day   = parsed?.day   ?? '';
  const month = parsed?.month ?? '';
  const year  = parsed?.hasYear ? parsed.year : '';

  return (
    <div>
      <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between' }}>
        <Eyebrow>Birthday</Eyebrow>
        <div style={{ display:'flex', gap:2, fontFamily:'Inter', fontSize:10 }}>
          <ModeTab label="Full date"    active={mode === 'full'}    onClick={() => setMode('full')} />
          <ModeTab label="Month + day"  active={mode === 'partial'} onClick={() => setMode('partial')} />
          <ModeTab label="Don't share"  active={mode === 'none'}    onClick={() => setMode('none')} />
        </div>
      </div>

      {mode === 'none' ? (
        <div style={{
          marginTop:6, padding:'8px 10px',
          border:'1px dashed var(--ink4)', borderRadius:3,
          fontFamily:'Inter', fontSize:11, color:'var(--ink4)',
        }}>
          Not shared with your choir.
        </div>
      ) : (
        <div style={{ display:'flex', gap:6, marginTop:6, alignItems:'center' }}>
          <BdayInput placeholder="DD"   defaultValue={day}   width={46} />
          <BdayInput placeholder="Mon"  defaultValue={month} width={60} />
          {mode === 'full' && <BdayInput placeholder="YYYY" defaultValue={year} width={64} />}
          <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)' }}>
            {mode === 'full'
              ? 'Age shown only to conductor.'
              : 'Only the day shows on the roster.'}
          </span>
        </div>
      )}
    </div>
  );
}

function ModeTab({ label, active, onClick }) {
  return (
    <span
      onClick={onClick}
      style={{
        padding:'2px 7px', borderRadius:3, cursor:'pointer',
        fontWeight: active ? 600 : 400,
        color: active ? 'var(--ink)' : 'var(--ink3)',
        background: active ? 'var(--paper2)' : 'transparent',
        border: active ? '1px solid var(--ink4)' : '1px solid transparent',
      }}
    >{label}</span>
  );
}

function BdayInput({ placeholder, defaultValue, width }) {
  return (
    <input
      placeholder={placeholder}
      defaultValue={defaultValue}
      style={{
        width, fontFamily:'JetBrains Mono, monospace', fontSize:12,
        color:'var(--ink)', background:'var(--paper)',
        border:'1.25px solid var(--ink4)', borderRadius:3,
        padding:'6px 8px', outline:'none', textAlign:'center',
      }}
    />
  );
}

function ModalBackdrop({ children }) {
  return (
    <div style={{
      position:'absolute', inset:0, zIndex:10,
      background:'rgba(42, 38, 32, 0.35)',
      display:'flex', alignItems:'flex-start', justifyContent:'center',
      paddingTop:60, backdropFilter:'blur(1px)',
    }}>
      {children}
    </div>
  );
}

Object.assign(window, { R2_1Table, R2_2Modal, R2_3Edit });
