// L3 — Card shelves grouped by composer. Shows the delete-referenced modal active.

function L3CardShelves() {
  // Group by composer
  const groups = {};
  LIBRARY.forEach(w => { (groups[w.composer] ??= []).push(w); });
  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor/library">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column', position:'relative' }}>
        <WorkspaceNav />
        <LibrarySubnav />
        <LibraryFilterBar />

        <div style={{ flex:1, overflow:'hidden', padding:'14px 24px', background:'var(--paper2)' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:10 }}>
            <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
              Grouped by <span style={{ fontWeight:600, color:'var(--ink)' }}>composer ▾</span>
              <span style={{ color:'var(--ink4)', margin:'0 8px' }}>·</span>
              <span>8 works across 8 composers</span>
            </div>
          </div>

          {Object.entries(groups).slice(0,3).map(([composer, works]) => (
            <div key={composer} style={{ marginBottom:16 }}>
              <div style={{
                display:'flex', alignItems:'baseline', gap:10, marginBottom:6,
                borderBottom:'1.5px solid var(--ink4)', paddingBottom:4,
              }}>
                <span style={{ fontFamily:'Inter', fontSize:13, fontWeight:700, color:'var(--ink)' }}>{composer}</span>
                <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>{works.length} {works.length===1?'work':'works'}</span>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(260px, 1fr))', gap:10 }}>
                {works.map(w => <ScoreCard key={w.id} work={w} />)}
              </div>
            </div>
          ))}

          <div style={{ fontFamily:'Caveat', fontSize:13, color:'var(--red)', marginTop:8 }}>
            ↳ more composer shelves scroll below
          </div>
        </div>

        <DeleteReferencedModal />
      </div>
    </BrowserFrame>
  );
}

function ScoreCard({ work }) {
  const stats = workCopyStats(work);
  return (
    <div className="sk-box" style={{ padding:10, background:'var(--paper)', display:'flex', flexDirection:'column', gap:6, cursor:'pointer' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:6 }}>
        <div style={{ minWidth:0 }}>
          <div style={{ fontFamily:'Inter', fontSize:12, fontWeight:700, color:'var(--ink)', lineHeight:1.2, fontStyle:'italic' }}>{work.title}</div>
          <div className="mono" style={{ fontSize:10, color:'var(--ink3)', marginTop:2 }}>{work.voicing} · {work.lang} · {work.year}</div>
        </div>
        <Difficulty level={work.difficulty} />
      </div>
      <div style={{ display:'flex', gap:3, flexWrap:'wrap' }}>
        {work.tags.map((t,i)=><Chip key={i} style={{ fontSize:8, padding:'1px 5px' }}>{t}</Chip>)}
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:'auto', paddingTop:6, borderTop:'1px dashed var(--ink5)' }}>
        <FileKindDots editions={work.editions} />
        <CopiesBadge stats={stats} />
      </div>
    </div>
  );
}

window.L3CardShelves = L3CardShelves;
