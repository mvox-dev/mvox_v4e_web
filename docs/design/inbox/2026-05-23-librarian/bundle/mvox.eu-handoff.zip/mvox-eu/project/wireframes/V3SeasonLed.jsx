// V3 — Season-led
// Current season + upcoming concerts dominate the page. Press/concert-goer bias.
// The umbrella identity sits as context under the fold.

function V3SeasonLed() {
  return (
    <BrowserFrame url="mvox.eu/o/eesti-segakooride-liit">
      <div className="sk" style={{ height: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <RegistryNav />

        {/* Poster-style season hero */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', borderBottom: '1.5px solid var(--ink4)' }}>
          <div style={{ padding: '24px 36px', background: 'var(--paper)' }}>
            <Eyebrow>Current season · 2025/26</Eyebrow>
            <div style={{
              fontFamily: 'Inter', fontWeight: 800, fontSize: 38, lineHeight: 1.05,
              color: 'var(--ink)', margin: '8px 0 6px', letterSpacing: '-0.02em',
            }}>
              Valgus <span style={{ color: 'var(--accent)' }}>&amp;</span> vari
            </div>
            <div style={{ fontFamily: 'Inter', fontSize: 13, color: 'var(--ink3)', fontStyle: 'italic', marginBottom: 10 }}>
              Light and shadow — a season on Estonian sacred choral tradition
            </div>
            <Lines count={3} widths={['long', 'long', 'med']} />
            <div style={{ marginTop: 14, display: 'flex', gap: 8 }}>
              <button className="sk-btn primary">Next concert →</button>
              <button className="sk-btn ghost">Full calendar</button>
            </div>
            <div style={{ marginTop: 14, fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)' }}>
              presented by <span style={{ color: 'var(--ink2)', fontWeight: 500 }}>Eesti Segakooride Liit</span> · 24 member choirs
            </div>
          </div>
          <div className="sk-hatch" style={{ position: 'relative', minHeight: 200, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ fontFamily: 'Caveat', fontSize: 15, color: 'var(--ink3)', textAlign: 'center' }}>
              season artwork<br/><span style={{ fontSize: 11, color: 'var(--ink4)' }}>(poster / key image)</span>
            </div>
            <Annot style={{ position: 'absolute', top: 10, right: 14 }}>image leads — press-friendly</Annot>
          </div>
        </div>

        <div style={{ flex: 1, overflow: 'hidden', padding: '20px 36px', display: 'grid', gridTemplateColumns: '1fr 240px', gap: 28, minHeight: 0 }}>
          {/* ── Upcoming events timeline ── */}
          <div style={{ overflow: 'hidden' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
              <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 16, margin: 0 }}>Upcoming concerts</h2>
              <span style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)' }}>6 in the next 3 months</span>
            </div>

            {[
              ['MAY', '03', 'Reekviem', 'Kaarli kirik, Tallinn', 'Collegium Musicale + Tallinna Kammerkoor', 'concert'],
              ['MAY', '18', 'Kevadkontsert', 'Estonia kontserdisaal', 'Eesti Filh. Kammerkoor', 'concert'],
              ['JUN', '02', 'Ühislaul', 'Tartu Jaani kirik', '12 member choirs', 'festival'],
              ['JUN', '21', 'Suvepäevad', 'Haapsalu', 'All members — retreat', 'retreat'],
            ].map(([mo, d, title, venue, who, kind], i) => (
              <div key={i} style={{ display: 'flex', gap: 14, padding: '10px 0', borderBottom: '1px dashed var(--ink5)' }}>
                <div className="sk-box filled" style={{ width: 48, textAlign: 'center', padding: '6px 0', flexShrink: 0 }}>
                  <div style={{ fontFamily: 'Inter', fontSize: 9, fontWeight: 600, color: 'var(--accent)', letterSpacing: '0.1em' }}>{mo}</div>
                  <div style={{ fontFamily: 'Inter', fontSize: 20, fontWeight: 700, color: 'var(--ink)', lineHeight: 1 }}>{d}</div>
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                    <span style={{ fontFamily: 'Inter', fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>{title}</span>
                    <Chip style={{ fontSize: 10, padding: '0 6px' }}>{kind}</Chip>
                  </div>
                  <div style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)' }}>
                    {venue} · <span style={{ color: 'var(--ink2)' }}>{who}</span>
                  </div>
                </div>
                <div style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--accent)', alignSelf: 'center' }} className="sk-underline">Details →</div>
              </div>
            ))}

            <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 16, margin: '18px 0 8px' }}>Season repertoire</h2>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5, fontFamily: 'Inter', fontSize: 12 }}>
              {[
                ['Pärt — Da pacem', 'SATB'],
                ['Tormis — Raua needmine', 'SATB + solo'],
                ['Kreek — Taaveti laul', 'SATB'],
                ['Tüür — Meditatio', 'SSAATTBB'],
                ['Sisask — Gloria Patri', 'SATB'],
                ['Eespere — Ärkamine', 'SATB'],
              ].map(([t, v], i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px dashed var(--ink5)' }}>
                  <span className="sk-underline" style={{ color: 'var(--accent)' }}>{t}</span>
                  <span style={{ color: 'var(--ink3)' }} className="mono">{v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* ── Sidebar: about + members ── */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="sk-box" style={{ padding: 12, background: 'var(--paper)' }}>
              <Eyebrow style={{ marginBottom: 6 }}>About the umbrella</Eyebrow>
              <div style={{ fontFamily: 'Inter', fontSize: 12, color: 'var(--ink2)' }}>
                Eesti Segakooride Liit
              </div>
              <Lines count={2} widths={['long', 'med']} />
              <div style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)', marginTop: 6 }}>
                est. 1962 · Tallinn · <span style={{ color: 'var(--accent)' }} className="sk-underline">esl.ee</span>
              </div>
            </div>
            <div className="sk-box soft" style={{ padding: 12 }}>
              <Eyebrow style={{ marginBottom: 6 }}>24 member choirs</Eyebrow>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                {Array.from({ length: 12 }).map((_, i) => (
                  <div key={i} className="sk-hatch" style={{ width: 28, height: 28, borderRadius: '50%', border: '1px solid var(--ink4)' }} />
                ))}
                <div className="sk-box" style={{ width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)' }}>+12</div>
              </div>
              <div className="sk-underline" style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--accent)', marginTop: 8, display: 'inline-block' }}>Browse directory →</div>
            </div>
            <div className="sk-box dashed" style={{ padding: 12 }}>
              <Eyebrow style={{ marginBottom: 6 }}>Press kit</Eyebrow>
              <div style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)', lineHeight: 1.6 }}>
                Logos · bios · photos ↓<br/>
                <span className="mono" style={{ color: 'var(--accent)' }}>press@esl.ee</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.V3SeasonLed = V3SeasonLed;
