// Shared pencil/paper primitives for the librarian view.
//
// Builds ON TOP of the existing SketchyPrimitives (.sk scope) but adds
// librarian-specific micro-components: pencil checkbox, voice chip,
// hand-drawn arrow, status dot, batch tally, paper-stack wrapper.

// One-time style injection — extends .sk styles already loaded
if (typeof document !== 'undefined' && !document.getElementById('lb-styles')) {
  const s = document.createElement('style');
  s.id = 'lb-styles';
  s.textContent = `
    .sk {
      --paper:   #f7f1e1;
      --paper2:  #efe7d2;
      --paper3:  #e5dcc4;
      --ink:     #2a2620;
      --ink2:    #4b443a;
      --ink3:    #7a7166;
      --ink4:    #a89f91;
      --ink5:    #c9bfa9;
      --red:     #b54a3a;
      --red-soft:#f0d8d0;
      --green:   #5f7a3b;
      --amber:   #b67a1e;
      --indigo:  #4f46e5;
      --indigo-soft: #e0e7ff;
      --accent:  #4f46e5;
      --accent-soft:#e0e7ff;
      --highlight:#f7e58a;
    }

    /* Subtle paper grain — used on big surfaces */
    .lb-paper {
      background:
        radial-gradient(ellipse at top left,  rgba(0,0,0,0.02), transparent 60%),
        radial-gradient(ellipse at bottom right, rgba(0,0,0,0.025), transparent 60%),
        var(--paper);
      background-blend-mode: multiply;
    }
    .lb-paper-2 { background: var(--paper2); }
    .lb-paper-3 { background: var(--paper3); }

    /* Ruled-paper variant — horizontal blue lines a librarian would use */
    .lb-ruled {
      background-image: repeating-linear-gradient(
        to bottom,
        transparent 0 27px,
        rgba(80,120,180,0.18) 27px 28px
      );
    }

    /* Hand-drawn underline (squiggly via repeating gradient) */
    .lb-uline {
      background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='80' height='5' viewBox='0 0 80 5'><path d='M0 3 Q 10 0 20 3 T 40 3 T 60 3 T 80 3' stroke='%232a2620' stroke-width='1.3' fill='none' stroke-linecap='round'/></svg>");
      background-repeat: repeat-x;
      background-position: 0 100%;
      background-size: 80px 5px;
      padding-bottom: 5px;
    }
    .lb-uline-red {
      background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='80' height='5' viewBox='0 0 80 5'><path d='M0 3 Q 10 0 20 3 T 40 3 T 60 3 T 80 3' stroke='%23b54a3a' stroke-width='1.5' fill='none' stroke-linecap='round'/></svg>");
      background-repeat: repeat-x;
      background-position: 0 100%;
      background-size: 80px 5px;
      padding-bottom: 5px;
    }

    /* Pencil checkbox */
    .lb-cb {
      width: 18px; height: 18px; flex-shrink: 0;
      border: 1.5px solid var(--ink2);
      border-radius: 3px;
      background: var(--paper);
      display: inline-block; vertical-align: middle;
      position: relative;
    }
    .lb-cb.checked::after {
      content:'';
      position:absolute;
      left: 1px; top: -3px;
      width: 22px; height: 22px;
      background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path d='M3 13 Q 8 22 12 16 T 22 2' stroke='%232a2620' stroke-width='2.5' fill='none' stroke-linecap='round'/></svg>");
      background-repeat: no-repeat;
    }
    .lb-cb.checked-red::after {
      background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path d='M3 13 Q 8 22 12 16 T 22 2' stroke='%23b54a3a' stroke-width='2.5' fill='none' stroke-linecap='round'/></svg>");
    }

    /* Strikethrough — looks like pencil */
    .lb-strike {
      position: relative;
      color: var(--ink3);
    }
    .lb-strike::after {
      content:'';
      position:absolute;
      left:-3px; right:-3px; top:55%;
      height:2px;
      background: var(--ink2);
      transform: rotate(-1.2deg);
      border-radius: 2px;
    }

    /* Voice badge (S1, A, B2, etc) */
    .lb-voice {
      display: inline-flex; align-items: center; justify-content: center;
      min-width: 26px; padding: 0 6px; height: 19px;
      border: 1.25px solid var(--ink2);
      border-radius: 4px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px; font-weight: 600;
      background: var(--paper);
      color: var(--ink);
    }
    .lb-voice.S, .lb-voice.S1, .lb-voice.S2 { background:#fbe3c1; }
    .lb-voice.A                              { background:#fadcc4; }
    .lb-voice.T, .lb-voice.T1, .lb-voice.T2 { background:#d6e9c2; }
    .lb-voice.B, .lb-voice.B1, .lb-voice.B2 { background:#cdd9ee; }

    /* Status dot */
    .lb-dot {
      display: inline-block; width: 8px; height: 8px;
      border-radius: 99px; margin-right: 6px;
      vertical-align: middle;
      border: 1px solid var(--ink3);
    }
    .lb-dot.green    { background: #91b864; border-color:#5f7a3b; }
    .lb-dot.red      { background: #d97a6a; border-color: var(--red); }
    .lb-dot.amber    { background: #e3b766; border-color: var(--amber); }
    .lb-dot.indigo   { background: #8a82ec; border-color: var(--indigo); }
    .lb-dot.gray     { background: var(--paper2); }

    /* Status pill */
    .lb-pill {
      display: inline-flex; align-items: center; gap:4px;
      padding: 2px 8px;
      border: 1.25px solid var(--ink3);
      border-radius: 99px;
      font-family: 'Inter', system-ui, sans-serif;
      font-size: 11px;
      background: var(--paper);
      color: var(--ink2);
      white-space: nowrap;
    }
    .lb-pill.green   { background:#e1edcc; border-color:#5f7a3b; color:#3c5320; }
    .lb-pill.red     { background:#f4d7d0; border-color: var(--red); color:#7a2418; }
    .lb-pill.amber   { background:#f5e3bf; border-color: var(--amber); color:#6f4710; }
    .lb-pill.indigo  { background: var(--indigo-soft); border-color: var(--indigo); color: var(--indigo); }
    .lb-pill.fade    { animation: lb-fade-out 0.0001s linear paused; opacity: 0.6; }

    @keyframes lb-fade-out {
      to { opacity: 0; }
    }

    /* Sticky-note / margin annotation card (red pen) */
    .lb-margin {
      font-family: 'Caveat', cursive;
      color: var(--red);
      font-size: 17px;
      line-height: 1.2;
    }
    .lb-margin .arrow {
      display: inline-block;
      transform: translateY(2px);
    }

    /* Big numerical tally */
    .lb-tally {
      font-family: 'Caveat', cursive;
      font-weight: 700;
      font-size: 56px;
      line-height: 0.9;
      color: var(--ink);
    }
    .lb-tally-red { color: var(--red); }

    /* Paper stack — used for the desk direction */
    .lb-stack {
      position: relative;
    }
    .lb-stack::before, .lb-stack::after {
      content:'';
      position: absolute; inset: 0;
      border: 1.5px solid var(--ink2);
      border-radius: 4px;
      background: var(--paper);
      z-index: -1;
    }
    .lb-stack::before { transform: rotate(-1.1deg) translate(2px, 3px); }
    .lb-stack::after  { transform: rotate(0.8deg) translate(-3px, 5px); background: var(--paper2); }

    /* Tab bar (ledger) */
    .lb-tabs {
      display: flex; align-items: flex-end; gap: 0;
      border-bottom: 2px solid var(--ink2);
    }
    .lb-tab {
      padding: 8px 16px 6px;
      font-family: 'Inter', system-ui, sans-serif;
      font-size: 12px;
      font-weight: 500;
      color: var(--ink3);
      border: 1.5px solid transparent;
      border-bottom: none;
      background: transparent;
      cursor: pointer;
      letter-spacing: 0.02em;
      position: relative;
      top: 2px;
    }
    .lb-tab .count {
      display: inline-block;
      margin-left: 6px;
      padding: 0 6px;
      border-radius: 99px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      font-weight: 500;
      background: var(--paper2);
      color: var(--ink3);
      border: 1px solid var(--ink5);
    }
    .lb-tab.active {
      color: var(--ink);
      font-weight: 600;
      background: var(--paper);
      border-color: var(--ink2);
      border-bottom: 2px solid var(--paper);
    }
    .lb-tab.active .count { background: var(--accent); color:#fff; border-color: var(--accent); }
    .lb-tab.warn .count { background: var(--red); color:#fff; border-color: var(--red); }

    /* Edition row reveal */
    .lb-edition-row {
      padding-left: 32px;
      border-left: 1.5px dashed var(--ink5);
      margin-left: 12px;
    }

    /* Press-key hint */
    .lb-key {
      display: inline-block;
      min-width: 18px;
      padding: 0 5px;
      height: 18px; line-height: 16px;
      border: 1.5px solid var(--ink3);
      border-bottom-width: 2.5px;
      border-radius: 4px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      background: var(--paper);
      color: var(--ink2);
      text-align: center;
    }

    /* Search input pencil-drawn */
    .lb-search {
      display: flex; align-items: center; gap: 8px;
      padding: 8px 12px;
      border: 1.5px solid var(--ink2);
      border-radius: 6px;
      background: var(--paper);
      box-shadow: 2px 2px 0 0 var(--ink4);
    }
    .lb-search input {
      flex: 1; border: none; outline: none; background: transparent;
      font-family: 'Inter', system-ui, sans-serif; font-size: 13px; color: var(--ink);
    }
    .lb-search input::placeholder { color: var(--ink4); }

    /* Number circle (rank) */
    .lb-rank {
      display: inline-flex; align-items: center; justify-content: center;
      width: 32px; height: 32px;
      border: 2px solid var(--ink2);
      border-radius: 50%;
      font-family: 'Caveat', cursive;
      font-size: 22px; font-weight: 700;
      background: var(--paper);
      color: var(--ink);
    }
    .lb-rank.done { background:#dde9cb; border-color: var(--green); color: var(--green); }
    .lb-rank.warn { background: var(--red-soft); border-color: var(--red); color: var(--red); }

    /* Section header — pencil eyebrow + thick ruling */
    .lb-section-h {
      display: flex; align-items: baseline; justify-content: space-between;
      padding-bottom: 6px;
      border-bottom: 1.5px solid var(--ink2);
      margin-bottom: 14px;
    }
    .lb-section-h h2 {
      font-family: 'Caveat', cursive;
      font-size: 30px; font-weight: 700;
      letter-spacing: -0.01em;
      margin: 0; color: var(--ink);
    }
    .lb-section-h .meta {
      font-family: 'Inter', sans-serif;
      font-size: 10px; letter-spacing: 0.14em; text-transform: uppercase;
      color: var(--ink3);
    }

    /* Pencil arrow (svg path) */
    .lb-arrow {
      display: inline-block;
    }
  `;
  document.head.appendChild(s);
}

// ─── Components ─────────────────────────────────────────────────────

function PencilCheckbox({ checked, red, onClick, size }) {
  return (
    <span
      className={`lb-cb ${checked ? (red ? 'checked checked-red' : 'checked') : ''}`}
      onClick={onClick}
      style={size ? { width:size, height:size } : null}
    />
  );
}

function Voice({ v }) {
  return <span className={`lb-voice ${v[0]} ${v}`}>{v}</span>;
}

function StatusPill({ tone, children, style }) {
  return <span className={`lb-pill ${tone || ''}`} style={style}>{children}</span>;
}

function StatusDot({ tone }) { return <span className={`lb-dot ${tone}`} />; }

function Margin({ children, rotate, style }) {
  return (
    <div className="lb-margin" style={{ transform: `rotate(${rotate || 0}deg)`, ...(style||{}) }}>
      {children}
    </div>
  );
}

// Hand-drawn arrow — SVG path with a curve and arrowhead
function PencilArrow({ d = 'M5,5 Q 30,30 70,25', stroke = '#b54a3a', width = 100, height = 50, style }) {
  return (
    <svg className="lb-arrow" width={width} height={height} viewBox={`0 0 ${width} ${height}`}
         style={style}>
      <path d={d} stroke={stroke} strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      {/* arrowhead derived from path direction (cheap: drawn at the path end) */}
    </svg>
  );
}

// A curved arrow that points from a label to a target. Provide x1,y1,x2,y2.
function CurvedArrow({ from, to, color = '#b54a3a', curve = 30, dashed = false, headSide = 'end' }) {
  const [x1, y1] = from; const [x2, y2] = to;
  const mx = (x1 + x2) / 2; const my = (y1 + y2) / 2 - curve;
  // arrowhead orientation derived from second-half tangent (mx,my -> x2,y2)
  const dx = x2 - mx, dy = y2 - my;
  const ang = Math.atan2(dy, dx);
  const ah = 8;
  const ax1 = x2 - ah * Math.cos(ang - 0.5);
  const ay1 = y2 - ah * Math.sin(ang - 0.5);
  const ax2 = x2 - ah * Math.cos(ang + 0.5);
  const ay2 = y2 - ah * Math.sin(ang + 0.5);
  return (
    <svg style={{ position:'absolute', left:0, top:0, pointerEvents:'none', overflow:'visible' }} width="100%" height="100%">
      <path d={`M${x1} ${y1} Q ${mx} ${my} ${x2} ${y2}`}
            stroke={color} strokeWidth="1.4" fill="none"
            strokeLinecap="round" strokeDasharray={dashed ? '4 4' : ''} />
      {headSide === 'end' && (
        <path d={`M${ax1} ${ay1} L ${x2} ${y2} L ${ax2} ${ay2}`}
              stroke={color} strokeWidth="1.4" fill="none"
              strokeLinecap="round" strokeLinejoin="round" />
      )}
    </svg>
  );
}

// Number circle (1, 2, 3)
function Rank({ n, tone }) {
  return <span className={`lb-rank ${tone || ''}`}>{n}</span>;
}

// Section heading with hand-drawn ruling under it
function SectionHeading({ title, meta, style }) {
  return (
    <div className="lb-section-h" style={style}>
      <h2>{title}</h2>
      {meta && <span className="meta">{meta}</span>}
    </div>
  );
}

// Search input
function PencilSearch({ placeholder, hint, style }) {
  return (
    <div className="lb-search" style={style}>
      <svg width="16" height="16" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.8" fill="none" strokeLinecap="round">
        <circle cx="11" cy="11" r="6" />
        <path d="m20 20-4-4" />
      </svg>
      <input placeholder={placeholder || 'Search composer, work, edition…'} />
      {hint && <span className="lb-key">{hint}</span>}
    </div>
  );
}

// Press hint
function KeyHint({ k, label }) {
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:5, fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
      <span className="lb-key">{k}</span>
      <span>{label}</span>
    </span>
  );
}

// Big tally — for "12 returned today" etc.
function Tally({ n, label, tone, style }) {
  return (
    <div style={{ display:'flex', alignItems:'baseline', gap:8, ...style }}>
      <span className={`lb-tally ${tone === 'red' ? 'lb-tally-red' : ''}`}>{n}</span>
      <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', letterSpacing:'0.06em', textTransform:'uppercase' }}>{label}</span>
    </div>
  );
}

// Composer · Title block (used everywhere)
function WorkTitle({ work, size = 'm', italic = true }) {
  const sizes = { s: 13, m: 15, l: 19, xl: 24 };
  const fs = sizes[size];
  return (
    <span style={{ fontFamily:'Inter', fontSize:fs, lineHeight:1.25, color:'var(--ink)' }}>
      <span style={{ fontWeight:600 }}>{work.composer}</span>
      <span style={{ color:'var(--ink3)', margin:'0 4px' }}>—</span>
      <span style={{ fontStyle: italic ? 'italic' : 'normal' }}>{work.title}</span>
    </span>
  );
}

// "Paper stack" wrapper — appears as three stacked sheets
function PaperStack({ children, style, color }) {
  return (
    <div className="lb-stack" style={{
      border:'1.5px solid var(--ink2)',
      borderRadius:4,
      background: color || 'var(--paper)',
      position:'relative',
      ...style,
    }}>
      {children}
    </div>
  );
}

// Voice tally row (e.g., "Tonight: S1×8 S2×8 A×12 T×10 B×10")
function VoiceTally({ counts }) {
  return (
    <div style={{ display:'inline-flex', gap:8, alignItems:'center' }}>
      {Object.entries(counts).map(([v, n]) => (
        <span key={v} style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
          <Voice v={v} />
          <span style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--ink2)' }}>×{n}</span>
        </span>
      ))}
    </div>
  );
}

// Browser frame with pencil chrome — slightly different from existing
function MvoxFrame({ url, children, dark }) {
  return (
    <div style={{
      height:'100%', background: dark ? '#1d1916' : 'var(--paper2)',
      border:'1.5px solid var(--ink2)',
      borderRadius:'8px 8px 3px 3px',
      overflow:'hidden', display:'flex', flexDirection:'column',
    }}>
      <div style={{
        display:'flex', alignItems:'center', gap:7,
        padding:'7px 12px',
        borderBottom:'1.5px solid var(--ink3)',
        background:'var(--paper2)', flexShrink:0,
      }}>
        <span style={{ width:9, height:9, borderRadius:'50%', border:'1px solid var(--ink3)' }} />
        <span style={{ width:9, height:9, borderRadius:'50%', border:'1px solid var(--ink3)' }} />
        <span style={{ width:9, height:9, borderRadius:'50%', border:'1px solid var(--ink3)' }} />
        <span style={{
          flex:1, background:'var(--paper)', border:'1px solid var(--ink4)',
          borderRadius:3, padding:'2px 10px',
          fontSize:12, color:'var(--ink3)', fontFamily:'JetBrains Mono, monospace',
        }}>{url}</span>
      </div>
      <div style={{ flex:1, overflow:'hidden', position:'relative' }}>{children}</div>
    </div>
  );
}

// Top nav specific to mvox librarian view
function MvoxNav({ active = 'library' }) {
  const tabs = ['agenda', 'library', 'roster', 'notices', 'settings'];
  return (
    <div style={{
      display:'flex', alignItems:'center', justifyContent:'space-between',
      padding:'10px 24px', borderBottom:'1.5px solid var(--ink2)',
      background:'var(--paper)',
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:16 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <span style={{
            width:24, height:24, borderRadius:6, background:'var(--ink)',
            color:'var(--paper)', fontFamily:'Caveat, cursive', fontWeight:700,
            display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:18,
          }}>m</span>
          <span style={{ fontFamily:'Inter', fontWeight:700, fontSize:15, letterSpacing:'-0.01em' }}>mvox</span>
        </div>
        <span style={{ color:'var(--ink4)' }}>/</span>
        <span style={{
          display:'inline-flex', alignItems:'center', gap:8,
          padding:'3px 10px', border:'1.25px solid var(--ink3)', borderRadius:4,
          background:'var(--paper)',
        }}>
          <span style={{
            width:18, height:18, borderRadius:3, background:'#293556',
            color:'#fff', fontFamily:'Inter', fontWeight:700, fontSize:8,
            display:'inline-flex', alignItems:'center', justifyContent:'center', letterSpacing:'0.04em',
          }}>EP</span>
          <span style={{ fontFamily:'Inter', fontWeight:600, fontSize:12 }}>Estonian Philharmonic Chamber Choir</span>
          <span style={{ color:'var(--ink4)' }}>▾</span>
        </span>
      </div>

      <div style={{ display:'flex', alignItems:'center', gap:16 }}>
        <div style={{ display:'flex', gap:14, fontFamily:'Inter', fontSize:12.5 }}>
          {tabs.map(t => (
            <span key={t} style={{
              color: t === active ? 'var(--ink)' : 'var(--ink3)',
              fontWeight: t === active ? 600 : 500,
              borderBottom: t === active ? '2px solid var(--ink)' : '2px solid transparent',
              paddingBottom: 4,
              textTransform: 'capitalize',
              display:'inline-flex', alignItems:'center', gap:5,
            }}>
              {t}
              {t === 'library' && t === active && (
                <span style={{
                  fontSize:8, letterSpacing:'0.08em', padding:'1px 5px',
                  background:'var(--ink)', color:'var(--paper)', borderRadius:2,
                  fontWeight:600,
                }}>LIBRARIAN</span>
              )}
            </span>
          ))}
        </div>
        <span style={{ color:'var(--ink4)' }}>·</span>
        <span style={{ display:'flex', alignItems:'center', gap:8, fontFamily:'Inter', fontSize:12 }}>
          <span style={{
            width:24, height:24, borderRadius:'50%', background:'#c8b290',
            color:'var(--ink)', display:'inline-flex', alignItems:'center', justifyContent:'center',
            fontFamily:'Caveat, cursive', fontSize:14, fontWeight:700,
            border:'1px solid var(--ink3)',
          }}>M</span>
          <span style={{ fontWeight:500 }}>Maire L.</span>
        </span>
      </div>
    </div>
  );
}

Object.assign(window, {
  PencilCheckbox, Voice, StatusPill, StatusDot, Margin, PencilArrow, CurvedArrow,
  Rank, SectionHeading, PencilSearch, KeyHint, Tally, WorkTitle, PaperStack,
  VoiceTally, MvoxFrame, MvoxNav,
});
