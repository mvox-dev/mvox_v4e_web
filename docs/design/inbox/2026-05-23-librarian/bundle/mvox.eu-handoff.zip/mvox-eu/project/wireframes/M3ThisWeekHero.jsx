// M3 — Season agenda + repertoire, side-by-side (no hero week).
// Locked direction: plain two-column workspace.

function M3ThisWeekHero() {
  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column' }}>
        <WorkspaceNav />
        <WorkspaceSubnav active="agenda" />

        {/* Page header */}
        <div style={{ padding:'16px 24px 10px', borderBottom:'1px solid var(--ink5)', display:'flex', justifyContent:'space-between', alignItems:'flex-end' }}>
          <div>
            <Eyebrow>Season 2024/25 · Piirid</Eyebrow>
            <div style={{ fontFamily:'Inter', fontWeight:700, fontSize:22, letterSpacing:'-0.01em', marginTop:2 }}>
              Your season
            </div>
            <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginTop:2 }}>
              10 upcoming events · 6 awaiting RSVP · 6 works in repertoire
            </div>
          </div>
          <ExternalToggle on={false} />
        </div>

        {/* Body: agenda + repertoire side-by-side */}
        <div style={{ flex:1, overflow:'hidden', padding:'14px 24px 18px', display:'grid', gridTemplateColumns:'1fr 1fr', gap:28, minHeight:0 }}>
          <div style={{ overflow:'hidden', display:'flex', flexDirection:'column', minHeight:0 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:6 }}>
              <div>
                <Eyebrow>Agenda</Eyebrow>
                <div style={{ fontFamily:'Inter', fontSize:14, fontWeight:700 }}>Upcoming events</div>
              </div>
              <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
                <span style={{ color:'var(--ink)', fontWeight:600 }}>List</span>
                <span style={{ color:'var(--ink4)', margin:'0 6px' }}>·</span>
                <span>Week</span>
                <span style={{ color:'var(--ink4)', margin:'0 6px' }}>·</span>
                <span>Month</span>
              </span>
            </div>
            <div style={{ flex:1, overflow:'hidden' }}>
              {AGENDA.map(ev => <EventRow key={ev.id} ev={ev} compact />)}
              <div style={{ marginTop:10, textAlign:'center' }}>
                <button className="sk-btn ghost" style={{ fontSize:11 }}>Show full season →</button>
              </div>
            </div>
          </div>

          <div style={{ overflow:'hidden', display:'flex', flexDirection:'column', minHeight:0 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:6 }}>
              <div>
                <Eyebrow>Season repertoire</Eyebrow>
                <div style={{ fontFamily:'Inter', fontSize:14, fontWeight:700 }}>6 works</div>
              </div>
              <span style={{ fontFamily:'Inter', fontSize:11 }}>
                <span style={{ color:'var(--ink)', fontWeight:600 }}>All</span>
                <span style={{ color:'var(--ink4)', margin:'0 6px' }}>·</span>
                <span style={{ color:'var(--ink3)' }}>Active</span>
                <span style={{ color:'var(--ink4)', margin:'0 6px' }}>·</span>
                <span style={{ color:'var(--ink3)' }}>Learning</span>
                <span style={{ color:'var(--ink4)', margin:'0 6px' }}>·</span>
                <span style={{ color:'var(--ink3)' }}>Retired</span>
              </span>
            </div>
            <div style={{ flex:1, overflow:'hidden' }}>
              {REPERTOIRE.map((r,i)=><RepertoireRow key={i} item={r} />)}
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.M3ThisWeekHero = M3ThisWeekHero;
