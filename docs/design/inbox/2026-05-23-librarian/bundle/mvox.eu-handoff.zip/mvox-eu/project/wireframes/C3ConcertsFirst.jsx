// C3 — Concerts-first, dense. Calendar-forward.

function C3ConcertsFirst({ withUmbrella = true }) {
  return (
    <BrowserFrame url="mvox.eu/o/kaaren-kammerkoor">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column', position:'relative' }}>
        <ContextToggle mode={withUmbrella ? 'umbrella member' : 'independent'} />
        <RegistryNav />
        <div style={{ padding:'8px 24px', borderBottom:'1.5px solid var(--ink5)', display:'flex', alignItems:'center', gap:12, background:'var(--paper)' }}>
          <div className="sk-hatch" style={{ width:28, height:28, borderRadius:6, border:'1.5px solid var(--ink3)' }} />
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontFamily:'Inter', fontWeight:700, fontSize:15 }}>Kaaren Kammerkoor</div>
            <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)', display:'flex', gap:6, alignItems:'center' }}>
              <span>Chamber · Tallinn · est. 2014 · 22 singers · dir. Mari Tõnisson</span>
              {withUmbrella && <UmbrellaBadge name="Eesti Segakooride Liit" slug="eesti-segakooride-liit" />}
            </div>
          </div>
          <button className="sk-btn ghost" style={{ fontSize:11 }}>About</button>
          <button className="sk-btn primary" style={{ fontSize:11 }}>Tickets</button>
        </div>

        {/* Next concert big block */}
        <div style={{ padding:'16px 24px', borderBottom:'1.5px solid var(--ink5)', display:'grid', gridTemplateColumns:'auto 1fr auto', gap:16, alignItems:'center' }}>
          <div className="sk-box accent" style={{ padding:'10px 14px', textAlign:'center', background:'var(--paper)' }}>
            <div style={{ fontFamily:'Inter', fontSize:10, fontWeight:600, color:'var(--accent)', letterSpacing:'0.1em' }}>SAT MAY</div>
            <div style={{ fontFamily:'Inter', fontSize:42, fontWeight:800, lineHeight:1, color:'var(--ink)', letterSpacing:'-0.03em' }}>03</div>
            <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>19:00</div>
          </div>
          <div>
            <Eyebrow>Next concert · in 11 days</Eyebrow>
            <div style={{ fontFamily:'Inter', fontSize:22, fontWeight:700, color:'var(--ink)', letterSpacing:'-0.01em', marginTop:4 }}>Reekviem — Duruflé Op. 9</div>
            <div style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink3)' }}>Kaarli kirik, Tallinn · w/ Collegium Musicale · organ: H. Reimann</div>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            <button className="sk-btn primary" style={{ fontSize:12 }}>Tickets →</button>
            <button className="sk-btn ghost" style={{ fontSize:11 }}>Programme PDF</button>
          </div>
        </div>

        <div style={{ flex:1, overflow:'hidden', padding:'14px 24px', display:'grid', gridTemplateColumns:'2fr 1fr', gap:20, minHeight:0 }}>
          <div>
            <CH2 right="iCal · subscribe →">Season calendar</CH2>
            {[
              ['MAY','03','Reekviem — Duruflé','Kaarli kirik','concert'],
              ['MAY','24','Kevadkontsert','Mustpeade Maja','concert'],
              ['JUN','14','Suvine õhtu','Vanemuise saal, Tartu','concert'],
              ['JUL','02','Suvefestival','Haapsalu toomkirik','festival'],
              ['JUL','19','Õppelaager','Viljandi','retreat'],
              ['SEP','06','Hooaja avamine','EMTA Saal','concert'],
              ['OCT','11','Pärt 90 · erikontsert','Arvo Pärt keskus','concert'],
              ['NOV','22','Jõululaulupidu','Estonia','festival'],
            ].map(([m,d,t,v,k],i)=>(
              <div key={i} style={{ display:'flex', gap:10, padding:'6px 0', borderBottom:'1px dashed var(--ink5)' }}>
                <div className="sk-box" style={{ width:36, textAlign:'center', padding:'3px 0', flexShrink:0 }}>
                  <div style={{ fontFamily:'Inter', fontSize:8, fontWeight:600, color:'var(--accent)', letterSpacing:'0.1em' }}>{m}</div>
                  <div style={{ fontFamily:'Inter', fontSize:15, fontWeight:700, lineHeight:1 }}>{d}</div>
                </div>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ display:'flex', gap:6, alignItems:'center' }}>
                    <span style={{ fontFamily:'Inter', fontSize:12, fontWeight:600 }}>{t}</span>
                    <Chip style={{ fontSize:9, padding:'0 5px' }}>{k}</Chip>
                  </div>
                  <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>{v}</div>
                </div>
                <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--accent)', alignSelf:'center' }} className="sk-underline">Details →</span>
              </div>
            ))}

            <CH2>Past season highlights</CH2>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8 }}>
              {['Laulupidu 2024','Nordic Fest 2023','Pärnu Muusikafest','Jõulukontsert 2024'].map((t,i)=>(
                <div key={i} className="sk-box filled" style={{ padding:8 }}>
                  <div className="sk-hatch-light" style={{ height:48, borderRadius:3, border:'1px dashed var(--ink4)', marginBottom:5 }} />
                  <div style={{ fontFamily:'Inter', fontSize:10, fontWeight:600, color:'var(--ink)' }}>{t}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div className="sk-box" style={{ padding:10 }}>
              <Eyebrow>Season 2025/26</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:14, fontWeight:700, marginTop:2 }}>"Piirid"</div>
              <Lines count={2} widths={['long','med']} />
              <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--accent)' }} className="sk-underline">Programme notes →</div>
            </div>
            <div className="sk-box soft" style={{ padding:10 }}>
              <Eyebrow style={{ marginBottom:6 }}>Voice openings</Eyebrow>
              <VoiceSections data={[['S',6,1],['A',5,0],['T',5,2],['B',6,0]]} />
              <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)', marginTop:8, lineHeight:1.5 }}>
                Auditions: rolling · individual sessions
              </div>
              <button className="sk-btn ghost" style={{ marginTop:6, width:'100%', fontSize:11, justifyContent:'center' }}>Audition info →</button>
            </div>
            <div className="sk-box" style={{ padding:10 }}>
              <Eyebrow style={{ marginBottom:6 }}>Rehearsals</Eyebrow>
              <RehearsalRow day="Mon" time="19:00–21:30" venue="EMTA R-207" />
              <RehearsalRow day="Thu" time="19:00–21:30" venue="EMTA R-207" />
            </div>
            <div className="sk-box dashed" style={{ padding:10 }}>
              <Eyebrow>Media · press</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)', lineHeight:1.55 }}>
                6 recordings · 3 reviews<br/>
                <span className="mono" style={{ color:'var(--accent)' }}>press@kaaren.ee</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.C3ConcertsFirst = C3ConcertsFirst;
