// Roster primitives — mock data + shared bits for R2 family.
//
// SCHEMA
// ─────────────────────────────────────────────────────────────────────
//   voice   = personal attribute of a musician (their vocal range and/or
//             instruments). Travels with them across any collective.
//             e.g. ['Soprano'], ['Tenor', 'Piano'], ['Oboe', 'Cor anglais'].
//
//   section = organizational slot WITHIN a collective. Hierarchical.
//             e.g. 'Soprano > S1', 'Bass', 'Keyboard'.
//             A person is in exactly one section per collective.
//             Subsections exist when a collective divides a section
//             (Sopranos split into S1/S2), otherwise the section is flat.
//
// Kaaren Kammerkoor has sections: Soprano (S1/S2), Alto (A1/A2),
// Tenor (T1/T2), Bass, Keyboard.

// ─── Section tree for Kaaren Kammerkoor ───────────────────────────────
const SECTIONS = [
  { id:'soprano',  label:'Soprano',  color:'#c84b3a',       initial:'S', subs:['S1','S2'] },
  { id:'alto',     label:'Alto',     color:'#8a6a2e',       initial:'A', subs:['A1','A2'] },
  { id:'tenor',    label:'Tenor',    color:'#2f7a4f',       initial:'T', subs:['T1','T2'] },
  { id:'bass',     label:'Bass',     color:'var(--accent)', initial:'B', subs:[] },        // no subsections
  { id:'keyboard', label:'Keyboard', color:'#6a5a8a',       initial:'♪', subs:[] },        // instrumentalists
];

const SECTION_ORDER = SECTIONS.map(s => s.id);
const SECTION_BY_ID = Object.fromEntries(SECTIONS.map(s => [s.id, s]));

// ─── Members ──────────────────────────────────────────────────────────
// Each member has:
//   section:  'soprano' | 'alto' | ... (section id)
//   sub:      'S1' | 'S2' | null   (only if the section is subdivided)
//   voices:   string[] — biographical
//   role:     null | 'Conductor' | 'Librarian'  (role in this collective)
const MEMBERS = [
  // Sopranos
  { id:1,  name:'Mari Tõnisson',  section:'soprano', sub:'S1', voices:['Soprano'],            status:'active', joined:'2018',
    email:'mari.tonisson@example.ee', phone:'+372 5123 4567', city:'Tallinn',
    birthday:'1987-05-12', sectionLeader:true,
    attendance:0.92, rsvpOpen:3, loans:1, role:null },
  { id:2,  name:'Kaarin Lepik',   section:'soprano', sub:'S1', voices:['Soprano','Piano'],   status:'active', joined:'2021',
    email:'kaarin@example.ee',        phone:'+372 5556 1122', city:'Tallinn',
    birthday:'1981-11-03',
    attendance:0.88, rsvpOpen:2, loans:0, role:'Conductor' },
  { id:3,  name:'Liisa Mets',     section:'soprano', sub:'S2', voices:['Soprano'],            status:'active', joined:'2020',
    email:'liisa.mets@example.ee',    phone:'+372 5888 9900', city:'Tartu',
    birthday:'--05-06', // month + day only
    attendance:0.81, rsvpOpen:4, loans:1, role:null },
  { id:4,  name:'Anu Rebane',     section:'soprano', sub:'S2', voices:['Soprano'],            status:'new',    joined:'Apr 2025',
    email:'anu.rebane@example.ee',    phone:'+372 5777 0011', city:'Tallinn',
    birthday:null, // hasn't filled it in
    attendance:1.00, rsvpOpen:1, loans:0, role:null },

  // Altos
  { id:5,  name:'Eva Kask',       section:'alto',    sub:'A1', voices:['Alto'],               status:'active', joined:'2016',
    email:'eva.kask@example.ee',      phone:'+372 5023 4466', city:'Tallinn',
    birthday:'1979-02-28', sectionLeader:true,
    attendance:0.95, rsvpOpen:0, loans:0, role:null },
  { id:6,  name:'Helena Kuusk',   section:'alto',    sub:'A1', voices:['Alto'],               status:'active', joined:'2019',
    email:'helena@example.ee',        phone:'+372 5111 2233', city:'Tallinn',
    birthday:'--09-19',
    attendance:0.78, rsvpOpen:5, loans:2, role:'Librarian' },
  { id:7,  name:'Kadri Saar',     section:'alto',    sub:'A2', voices:['Alto','Mezzo'],       status:'leave',  joined:'2017',
    email:'kadri.saar@example.ee',    phone:'+372 5444 3322', city:'Tallinn',
    birthday:'1985-07-22',
    attendance:0.45, rsvpOpen:0, loans:1, role:null, leaveNote:'parental leave · back Sep 2025' },
  { id:8,  name:'Tiina Oja',      section:'alto',    sub:'A2', voices:['Alto'],               status:'active', joined:'2022',
    email:'tiina.oja@example.ee',     phone:'+372 5890 1267', city:'Tallinn',
    birthday:null,
    attendance:0.90, rsvpOpen:1, loans:0, role:null },

  // Tenors
  { id:9,  name:'Jaan Pärnsalu',  section:'tenor',   sub:'T1', voices:['Tenor'],              status:'active', joined:'2015',
    email:'jaan.p@example.ee',        phone:'+372 5200 1100', city:'Tallinn',
    birthday:'1976-05-18', sectionLeader:true, // upcoming
    attendance:0.86, rsvpOpen:2, loans:1, role:null },
  { id:10, name:'Toomas Järv',    section:'tenor',   sub:'T1', voices:['Tenor','Oboe'],       status:'active', joined:'2020',
    email:'toomas@example.ee',        phone:'+372 5301 7788', city:'Tallinn',
    birthday:'1990-12-04',
    attendance:0.79, rsvpOpen:3, loans:0, role:null },
  { id:11, name:'Martin Raudla',  section:'tenor',   sub:'T2', voices:['Tenor'],              status:'active', joined:'2018',
    email:'martin.r@example.ee',      phone:'+372 5678 9012', city:'Tallinn',
    birthday:'--05-24', // upcoming, no year
    attendance:0.93, rsvpOpen:1, loans:0, role:null },

  // Basses  (no subsection)
  { id:12, name:'Rein Tamm',      section:'bass',    sub:null, voices:['Bass'],               status:'active', joined:'2014',
    email:'rein.tamm@example.ee',     phone:'+372 5400 5566', city:'Tallinn',
    birthday:'1971-08-11', sectionLeader:true,
    attendance:0.97, rsvpOpen:0, loans:1, role:null },
  { id:13, name:'Peeter Ojaste',  section:'bass',    sub:null, voices:['Bass','Baritone'],    status:'active', joined:'2019',
    email:'peeter.o@example.ee',      phone:'+372 5611 4477', city:'Tartu',
    birthday:null,
    attendance:0.72, rsvpOpen:4, loans:0, role:null },
  { id:14, name:'Kaarel Vaher',   section:'bass',    sub:null, voices:['Bass'],               status:'active', joined:'2017',
    email:'kaarel@example.ee',        phone:'+372 5505 3344', city:'Tallinn',
    birthday:'1983-01-30',
    attendance:0.84, rsvpOpen:2, loans:0, role:null },
  { id:15, name:'Siim Laur',      section:'bass',    sub:null, voices:['Bass'],               status:'active', joined:'2023',
    email:'siim.laur@example.ee',     phone:'+372 5999 1234', city:'Tallinn',
    birthday:'--10-07',
    attendance:0.88, rsvpOpen:1, loans:0, role:null },

  // Keyboard (instrumentalist)
  { id:16, name:'Reelika Tamm',   section:'keyboard', sub:null, voices:['Piano','Organ','Soprano'], status:'active', joined:'2022',
    email:'reelika@example.ee',       phone:'+372 5766 8421', city:'Tallinn',
    birthday:'1988-06-14',
    attendance:0.91, rsvpOpen:1, loans:0, role:null },
];

// ─── Helpers ──────────────────────────────────────────────────────────
function initials(name) {
  return name.split(' ').map(p => p[0]).join('').slice(0,2).toUpperCase();
}

function bySection() {
  const g = {}; SECTION_ORDER.forEach(s => g[s] = []);
  MEMBERS.forEach(m => g[m.section].push(m));
  return g;
}

// Count per section
function sectionCount(sectionId) {
  return MEMBERS.filter(m => m.section === sectionId).length;
}

// ─── Birthday parsing ────────────────────────────────────────────────
// Accepts:
//   'YYYY-MM-DD'  full date (has year)
//   '--MM-DD'     partial (month + day only)
//   null          not provided — do not show
function parseBirthday(bd) {
  if (!bd) return null;
  if (bd.startsWith('--')) {
    const [_, mm, dd] = bd.split('-');
    return { month: +mm, day: +dd, hasYear: false };
  }
  const [y, mm, dd] = bd.split('-');
  return { month: +mm, day: +dd, year: +y, hasYear: true };
}

const MONTH_ABBR = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

// Days until next occurrence of this month/day (today = 0; tomorrow = 1).
// Using a frozen 'today' so wireframes are deterministic — 6 May 2025.
const TODAY = { year: 2025, month: 5, day: 6 };
function daysUntilBirthday(bd) {
  const p = parseBirthday(bd);
  if (!p) return null;
  const now = new Date(TODAY.year, TODAY.month - 1, TODAY.day);
  let next = new Date(TODAY.year, p.month - 1, p.day);
  if (next < now) next = new Date(TODAY.year + 1, p.month - 1, p.day);
  return Math.round((next - now) / (1000 * 60 * 60 * 24));
}

function birthdayShort(bd) {
  const p = parseBirthday(bd);
  if (!p) return null;
  return `${p.day} ${MONTH_ABBR[p.month - 1]}`;
}

// ─── Birthday cell (table) ────────────────────────────────────────────
function BirthdayCell({ member }) {
  const label = birthdayShort(member.birthday);
  if (!label) {
    return <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink5)' }}>—</span>;
  }
  const days = daysUntilBirthday(member.birthday);
  const upcoming = days !== null && days <= 30;
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', gap:4,
      fontFamily:'Inter', fontSize:11,
      color: upcoming ? 'var(--accent)' : 'var(--ink3)',
      fontWeight: upcoming ? 600 : 400,
    }}>
      {upcoming && <span style={{ fontSize:10 }}>✽</span>}
      {label}
    </span>
  );
}

// ─── Avatar ───────────────────────────────────────────────────────────
function MemberAvatar({ member, size = 28 }) {
  const s = SECTION_BY_ID[member.section];
  return (
    <div style={{
      width:size, height:size, borderRadius:999, flexShrink:0,
      background:'var(--paper2)', border:`1.25px solid ${s.color}`,
      display:'inline-flex', alignItems:'center', justifyContent:'center',
      fontFamily:'Inter', fontSize:size*0.36, fontWeight:600, color:s.color,
    }}>{initials(member.name)}</div>
  );
}

// ─── Voice chip (shows SUBSECTION, not section; hidden if no subsection) ─
// This is the little "S1" / "T2" badge. If a section has no subdivisions
// (Bass, Keyboard), we render nothing — the section column already tells you.
function VoiceChip({ member }) {
  if (!member.sub) return null;
  const s = SECTION_BY_ID[member.section];
  return (
    <span style={{
      fontFamily:'Inter', fontSize:9, fontWeight:700, letterSpacing:'0.08em',
      padding:'1px 6px', borderRadius:3, color:s.color,
      border:`1px solid ${s.color}`, display:'inline-block',
    }}>{member.sub}</span>
  );
}

// ─── Voices pill list (biographical — "what this person can do") ─────
// Rendered in detail/edit modals, not in the table.
function VoicesList({ voices }) {
  if (!voices || !voices.length) return null;
  return (
    <div style={{ display:'flex', gap:4, flexWrap:'wrap' }}>
      {voices.map(v => (
        <span key={v} style={{
          fontFamily:'Inter', fontSize:10, color:'var(--ink2)',
          padding:'1px 7px', border:'1px dashed var(--ink4)', borderRadius:999,
          background:'var(--paper)',
        }}>{v}</span>
      ))}
    </div>
  );
}

// ─── Role / status ────────────────────────────────────────────────────
function RoleChip({ role }) {
  if (!role) return null;
  const cs = {
    Conductor: { bg:'var(--accent-soft)', fg:'var(--accent)', border:'var(--accent)' },
    Librarian: { bg:'#fff2d9',            fg:'#8a6a2e',       border:'#b8861a' },
  }[role];
  return (
    <span style={{
      fontFamily:'Inter', fontSize:9, fontWeight:600, letterSpacing:'0.08em',
      textTransform:'uppercase', padding:'1px 6px', borderRadius:3,
      background:cs.bg, color:cs.fg, border:`1px solid ${cs.border}`,
    }}>{role}</span>
  );
}

function StatusChip({ status }) {
  if (status === 'active') return null;
  const meta = {
    new:   { label:'NEW',   color:'#2f7a4f' },
    leave: { label:'LEAVE', color:'var(--ink4)' },
  }[status] || { label:status, color:'var(--ink4)' };
  return (
    <span style={{
      fontFamily:'Inter', fontSize:9, fontWeight:700, letterSpacing:'0.08em',
      padding:'1px 6px', borderRadius:3,
      color:meta.color, border:`1px dashed ${meta.color}`,
    }}>{meta.label}</span>
  );
}

// Section-leader chip — per-section designation, tinted by section color.
// Distinct from RoleChip, which is for org-wide roles like Conductor.
function SectionLeaderChip({ member }) {
  if (!member.sectionLeader) return null;
  const c = SECTION_BY_ID[member.section].color;
  return (
    <span title={`Leads the ${SECTION_BY_ID[member.section].label} section`} style={{
      display:'inline-flex', alignItems:'center', gap:3,
      fontFamily:'Inter', fontSize:9, fontWeight:700, letterSpacing:'0.06em',
      textTransform:'uppercase', padding:'1px 5px 1px 4px', borderRadius:3,
      color:'#fff', background:c,
    }}>
      <span style={{ fontSize:8 }}>▸</span>LEAD
    </span>
  );
}

// ─── Attendance bar ───────────────────────────────────────────────────
function Attendance({ value, compact = false, showLabel = true }) {
  const pct = Math.round(value * 100);
  const color = pct >= 85 ? '#2f7a4f' : pct >= 70 ? '#8a6a2e' : '#c84b3a';
  return (
    <div style={{ display:'flex', alignItems:'center', gap:5 }}>
      <div style={{
        width: compact ? 36 : 48, height:5, borderRadius:3,
        background:'var(--ink5)', overflow:'hidden',
      }}>
        <div style={{ width:`${pct}%`, height:'100%', background:color }} />
      </div>
      {showLabel && (
        <span className="mono" style={{ fontSize:10, color:'var(--ink3)' }}>
          {pct}%
        </span>
      )}
    </div>
  );
}

// ─── Subnav ───────────────────────────────────────────────────────────
function RosterSubnav() {
  const tabs = ['agenda', 'library', 'roster', 'notices'];
  const active = 'roster';
  return (
    <div style={{
      display:'flex', alignItems:'center', justifyContent:'space-between',
      padding:'8px 20px', borderBottom:'1.5px solid var(--ink5)',
      background:'var(--paper)', fontFamily:'Inter', fontSize:12,
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:14 }}>
        {tabs.map(t => (
          <span key={t} style={{
            color: active===t ? 'var(--ink)' : 'var(--ink3)',
            fontWeight: active===t ? 600 : 400,
            borderBottom: active===t ? '2px solid var(--accent)' : '2px solid transparent',
            padding:'3px 0', textTransform:'capitalize',
          }}>{t}</span>
        ))}
      </div>
      <a style={{ fontSize:11, color:'var(--ink3)' }}>
        <span className="sk-underline">View public page</span>
        <span className="mono" style={{ marginLeft:4, color:'var(--ink4)', fontSize:10 }}>/o/{OWN_CHOIR.slug} ↗</span>
      </a>
    </div>
  );
}

// ─── Toolbar ──────────────────────────────────────────────────────────
function RosterToolbar() {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:10, padding:'10px 24px',
      borderBottom:'1.5px solid var(--ink5)', background:'var(--paper2)',
    }}>
      <div>
        <Eyebrow>Roster · 2024/25</Eyebrow>
        <div style={{ fontFamily:'Inter', fontWeight:700, fontSize:16, letterSpacing:'-0.005em' }}>
          {MEMBERS.length} members · {MEMBERS.filter(m => m.status==='active' || m.status==='new').length} active · {MEMBERS.filter(m => m.status==='leave').length} on leave
        </div>
      </div>
      <span style={{ color:'var(--ink4)' }}>·</span>
      <span style={{ display:'flex', gap:8, fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
        {SECTIONS.map(s => <SectionTally key={s.id} section={s} n={sectionCount(s.id)} />)}
      </span>
      <div style={{ flex:1 }} />
      <button className="sk-btn ghost" style={{ fontSize:11 }}>⇣ Export</button>
      <button className="sk-btn primary" style={{ fontSize:11 }}>＋ Invite</button>
    </div>
  );
}

function SectionTally({ section, n }) {
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:4 }}>
      <span style={{ width:8, height:8, borderRadius:2, background:section.color }} />
      <span style={{ color:'var(--ink2)', fontWeight:600 }}>{n}</span>
      <span style={{ color:'var(--ink4)' }}>{section.label}</span>
    </span>
  );
}

// ─── Section header (group heading in the table) ─────────────────────
function SectionHeader({ section, count }) {
  return (
    <div style={{
      display:'flex', alignItems:'baseline', gap:10, padding:'10px 2px 6px',
      borderBottom:`1.5px solid ${section.color}`,
    }}>
      <span style={{
        width:22, height:22, borderRadius:3, background:section.color, color:'#fff',
        fontFamily:'Inter', fontSize:11, fontWeight:700,
        display:'inline-flex', alignItems:'center', justifyContent:'center',
      }}>{section.initial}</span>
      <span style={{ fontFamily:'Inter', fontSize:14, fontWeight:700, color:'var(--ink)' }}>
        {section.label}
      </span>
      <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
        {count} · {section.subs.length ? section.subs.join(' / ') : 'no subsections'}
      </span>
    </div>
  );
}

Object.assign(window, {
  SECTIONS, SECTION_ORDER, SECTION_BY_ID, MEMBERS,
  initials, bySection, sectionCount,
  parseBirthday, birthdayShort, daysUntilBirthday, BirthdayCell,
  MemberAvatar, VoiceChip, VoicesList, RoleChip, SectionLeaderChip, StatusChip, Attendance,
  RosterSubnav, RosterToolbar, SectionTally, SectionHeader,
});
