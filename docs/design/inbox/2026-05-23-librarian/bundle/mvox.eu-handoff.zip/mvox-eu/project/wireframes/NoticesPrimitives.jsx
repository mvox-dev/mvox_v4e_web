// Notices primitives — mock data + shared components for N1/N2/N3.
// Notices = mixed stream: announcements (human), system alerts (repertoire/library/RSVP),
// and polls. Reactions only (no replies). Role badges. Subtle unread dot.

// ─── Mock roster (subset for authors) ────────────────────────────────
const NOTICE_AUTHORS = {
  maarja:  { initials: 'ML', name: 'Maarja L.',     role: 'Conductor' },
  tiit:    { initials: 'TK', name: 'Tiit K.',       role: 'Librarian' },
  kaarel:  { initials: 'KV', name: 'Kaarel V.',     role: 'Bass'      },
  liisa:   { initials: 'LS', name: 'Liisa S.',      role: 'Soprano'   },
  jaan:    { initials: 'JP', name: 'Jaan P.',       role: 'Tenor'     },
  anu:     { initials: 'AR', name: 'Anu R.',        role: 'Alto'      },
  system:  { initials: '♪',  name: 'Multivox',      role: 'System'    },
};

// Types: announcement | poll | repertoire | library | rsvp
const NOTICES = [
  {
    id: 'n01', type: 'announcement', pinned: true, unread: false,
    author: 'maarja', when: '2 days ago', whenFull: 'Tue 22 Apr, 14:02',
    title: 'Dress code for Kaarli kirik · Saturday',
    body: 'Men: black suit, black tie, white shirt. Women: long black dress or black blouse + black skirt below knee. No visible jewellery beyond wedding bands. Arrive 17:30 for acoustic warm-up, call is 18:00.',
    topic: 'Reekviem',
    reactions: { '👍': 14, '🎉': 3 },
    youReacted: '👍',
  },
  {
    id: 'n02', type: 'poll', pinned: true, unread: true,
    author: 'maarja', when: '1 day ago', whenFull: 'Wed 23 Apr, 09:12',
    title: 'Retreat dates — pick all you can attend',
    body: 'We need to lock in the weekend retreat at Vihula mõis. Tick every weekend you could do; we go with the one with most bodies.',
    topic: 'Retreat 2025',
    poll: {
      closes: 'Fri 25 Apr',
      options: [
        { label: '17–18 May', votes: 11 },
        { label: '24–25 May', votes: 8  },
        { label: '31 May–1 Jun', votes: 14 },
        { label: "Can't do any of these", votes: 2 },
      ],
      total: 22, // unique voters
      youVoted: ['31 May–1 Jun', '17–18 May'],
    },
    reactions: {},
    youReacted: null,
  },
  {
    id: 'n03', type: 'repertoire', pinned: false, unread: true,
    author: 'system', when: '1 day ago', whenFull: 'Wed 23 Apr, 18:47',
    title: 'Rehearsal recording added',
    body: 'A new rehearsal recording was added to Duruflé — Requiem Op. 9.',
    topic: 'Reekviem',
    link: { label: 'Duruflé — Requiem Op. 9', href: '/repertoire/durufle-requiem', meta: 'rehearsal-22apr.mp3 · 34 min' },
    reactions: { '🎧': 6 },
    youReacted: null,
  },
  {
    id: 'n04', type: 'announcement', pinned: false, unread: true,
    author: 'tiit', when: '2 days ago', whenFull: 'Tue 22 Apr, 10:30',
    title: 'Returning library copies before the concert',
    body: 'Please return any borrowed scores by Friday rehearsal. I will be at the door with the box from 18:30. Four copies of Pärt · Da pacem are still out.',
    topic: null,
    reactions: { '👍': 9 },
    youReacted: null,
  },
  {
    id: 'n05', type: 'library', pinned: false, unread: false,
    author: 'system', when: '3 days ago', whenFull: 'Mon 21 Apr, 11:05',
    title: 'New edition catalogued',
    body: 'Tiit added a new edition to the library.',
    topic: null,
    link: { label: 'Kreek — Taaveti laul 141 · Eres Edition 2019', href: '/library/kreek-141', meta: '12 copies · tracked' },
    reactions: {},
    youReacted: null,
  },
  {
    id: 'n06', type: 'announcement', pinned: false, unread: false,
    author: 'kaarel', when: '3 days ago', whenFull: 'Mon 21 Apr, 19:22',
    title: 'Lift share to Kaarli on Saturday?',
    body: 'Driving from Mustamäe around 17:00, space for three with scores. Reply with 👍 if you want in and I\'ll message.',
    topic: 'Reekviem',
    reactions: { '👍': 4, '🙏': 2 },
    youReacted: null,
  },
  {
    id: 'n07', type: 'repertoire', pinned: false, unread: false,
    author: 'system', when: '4 days ago', whenFull: 'Sun 20 Apr, 22:10',
    title: 'Work moved to active',
    body: 'Maarja moved Sisask — Piirid from learning to active.',
    topic: null,
    link: { label: 'Sisask — Piirid', href: '/repertoire/sisask-piirid', meta: 'SATB div.' },
    reactions: { '🔥': 5 },
    youReacted: '🔥',
  },
  {
    id: 'n08', type: 'announcement', pinned: false, unread: false,
    author: 'liisa', when: '5 days ago', whenFull: 'Sat 19 Apr, 16:40',
    title: 'Welcome Anu Rebane — new alto!',
    body: 'Anu joins us from Collegium Musicale. She\'ll be at Monday rehearsal — please say hi.',
    topic: null,
    reactions: { '👋': 18, '🎉': 7, '❤️': 5 },
    youReacted: '👋',
  },
  {
    id: 'n09', type: 'library', pinned: false, unread: false,
    author: 'system', when: '5 days ago', whenFull: 'Sat 19 Apr, 09:00',
    title: 'Copy returned',
    body: 'Jaan P. returned a copy of Duruflé — Requiem Op. 9.',
    topic: 'Reekviem',
    link: { label: 'Duruflé — Requiem Op. 9', href: '/library/durufle-requiem', meta: '8/12 copies out' },
    reactions: {},
    youReacted: null,
  },
  {
    id: 'n10', type: 'announcement', pinned: false, unread: false,
    author: 'maarja', when: '1 week ago', whenFull: 'Wed 16 Apr',
    title: 'Programme notes for the May 3rd concert',
    body: 'Attaching the draft programme notes. If you spot errors in the Estonian translation of the Duruflé, flag them by Sunday — printer deadline is Monday.',
    topic: 'Reekviem',
    reactions: { '👍': 6, '📝': 2 },
    youReacted: null,
  },
];

// ─── Type metadata ────────────────────────────────────────────────────
const TYPE_META = {
  announcement: { label: 'Announcement', color: 'var(--ink2)',  icon: '✎' },
  poll:         { label: 'Poll',         color: 'var(--accent)', icon: '◉' },
  repertoire:   { label: 'Repertoire',   color: '#2f7a4f',      icon: '♫' },
  library:      { label: 'Library',      color: '#8a6a2e',      icon: '❒' },
  rsvp:         { label: 'RSVP',         color: '#6a5a8a',      icon: '✓' },
};

// ─── Avatar ───────────────────────────────────────────────────────────
function Avatar({ authorKey, size = 28 }) {
  const a = NOTICE_AUTHORS[authorKey];
  const isSystem = authorKey === 'system';
  return (
    <div style={{
      width: size, height: size, borderRadius: 999,
      background: isSystem ? 'var(--ink5)' : 'var(--paper2)',
      border: `1.25px solid ${isSystem ? 'var(--ink3)' : 'var(--ink4)'}`,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'Inter', fontSize: size * 0.38, fontWeight: 600,
      color: isSystem ? 'var(--ink3)' : 'var(--ink2)',
      flexShrink: 0,
    }}>
      {a.initials}
    </div>
  );
}

// ─── Role badge ───────────────────────────────────────────────────────
function RoleBadge({ role }) {
  const roleStyle = {
    Conductor: { bg: 'var(--accent-soft)', fg: 'var(--accent)',  border: 'var(--accent)' },
    Librarian: { bg: '#fff2d9',            fg: '#8a6a2e',        border: '#b8861a'      },
    System:    { bg: 'var(--paper2)',      fg: 'var(--ink4)',    border: 'var(--ink4)'  },
  }[role] || { bg: 'transparent', fg: 'var(--ink4)', border: 'var(--ink5)' };
  return (
    <span style={{
      fontFamily: 'Inter', fontSize: 9, fontWeight: 600, letterSpacing: '0.08em',
      textTransform: 'uppercase', padding: '1px 6px', borderRadius: 3,
      background: roleStyle.bg, color: roleStyle.fg, border: `1px solid ${roleStyle.border}`,
    }}>{role}</span>
  );
}

// ─── Type chip ────────────────────────────────────────────────────────
function TypeChip({ type }) {
  const t = TYPE_META[type];
  return (
    <span style={{
      fontFamily: 'Inter', fontSize: 9, fontWeight: 600, letterSpacing: '0.08em',
      textTransform: 'uppercase', padding: '1px 6px', borderRadius: 3,
      color: t.color, border: `1px solid ${t.color}`,
      display: 'inline-flex', alignItems: 'center', gap: 4,
    }}>
      <span style={{ fontSize: 10 }}>{t.icon}</span>
      {t.label}
    </span>
  );
}

// ─── Unread dot ───────────────────────────────────────────────────────
function UnreadDot({ on }) {
  return (
    <span style={{
      width: 7, height: 7, borderRadius: 999, flexShrink: 0,
      background: on ? 'var(--accent)' : 'transparent',
      display: 'inline-block',
    }} />
  );
}

// ─── Reactions row ────────────────────────────────────────────────────
function Reactions({ reactions, youReacted, showAdd = true, compact = false }) {
  const entries = Object.entries(reactions || {});
  if (!entries.length && !showAdd) return null;
  const pad = compact ? '1px 7px' : '2px 8px';
  const fs = compact ? 11 : 12;
  return (
    <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', alignItems: 'center' }}>
      {entries.map(([emoji, count]) => {
        const mine = youReacted === emoji;
        return (
          <span key={emoji} style={{
            display: 'inline-flex', alignItems: 'center', gap: 4,
            padding: pad, fontSize: fs, lineHeight: 1,
            border: `1px solid ${mine ? 'var(--accent)' : 'var(--ink5)'}`,
            background: mine ? 'var(--accent-soft)' : 'var(--paper)',
            borderRadius: 999, fontFamily: 'Inter',
            color: mine ? 'var(--accent)' : 'var(--ink2)',
            fontWeight: mine ? 600 : 500,
          }}>
            <span style={{ fontSize: compact ? 11 : 12 }}>{emoji}</span>
            <span style={{ fontSize: compact ? 10 : 11 }}>{count}</span>
          </span>
        );
      })}
      {showAdd && (
        <span style={{
          display: 'inline-flex', alignItems: 'center', gap: 2,
          padding: pad, fontSize: fs, lineHeight: 1,
          border: '1px dashed var(--ink4)', borderRadius: 999,
          color: 'var(--ink4)', fontFamily: 'Inter',
        }}>
          <span style={{ fontSize: compact ? 12 : 13 }}>☺</span>
          <span style={{ fontSize: 10 }}>+</span>
        </span>
      )}
    </div>
  );
}

// ─── Poll display ─────────────────────────────────────────────────────
function PollBody({ poll }) {
  const max = Math.max(...poll.options.map(o => o.votes), 1);
  return (
    <div style={{
      border: '1.25px solid var(--ink5)', borderRadius: 4,
      background: 'var(--paper)', padding: '10px 12px', marginTop: 6,
    }}>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        marginBottom: 8, fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)',
      }}>
        <span><strong style={{ color: 'var(--ink2)', fontWeight: 600 }}>{poll.total}</strong> voters · multi-select</span>
        <span>Closes <span className="mono" style={{ color: 'var(--ink2)' }}>{poll.closes}</span></span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
        {poll.options.map((opt, i) => {
          const mine = poll.youVoted.includes(opt.label);
          const pct = Math.round((opt.votes / max) * 100);
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '5px 8px', borderRadius: 3,
              border: `1.25px solid ${mine ? 'var(--accent)' : 'var(--ink5)'}`,
              background: mine ? 'var(--accent-soft)' : 'var(--paper)',
              position: 'relative', overflow: 'hidden',
            }}>
              <span style={{
                position: 'absolute', inset: 0,
                background: mine ? 'rgba(79,70,229,0.08)' : 'rgba(0,0,0,0.03)',
                width: `${pct}%`, zIndex: 0,
              }} />
              <span style={{
                position: 'relative', zIndex: 1, width: 14, height: 14,
                borderRadius: 3, border: `1.5px solid ${mine ? 'var(--accent)' : 'var(--ink4)'}`,
                background: mine ? 'var(--accent)' : 'var(--paper)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: '#fff', fontSize: 10, fontWeight: 700, flexShrink: 0,
              }}>{mine ? '✓' : ''}</span>
              <span style={{
                position: 'relative', zIndex: 1, flex: 1,
                fontFamily: 'Inter', fontSize: 12,
                fontWeight: mine ? 600 : 400,
                color: mine ? 'var(--accent)' : 'var(--ink2)',
              }}>{opt.label}</span>
              <span style={{
                position: 'relative', zIndex: 1,
                fontFamily: 'Inter', fontSize: 11,
                color: 'var(--ink3)',
              }}>{opt.votes}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Linked-item pill (repertoire / library references) ─────────────
function LinkedItem({ link, type }) {
  const meta = TYPE_META[type];
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      padding: '6px 10px', marginTop: 6,
      border: '1.25px solid var(--ink5)', borderRadius: 4,
      background: 'var(--paper2)', maxWidth: '100%',
    }}>
      <span style={{
        width: 22, height: 22, borderRadius: 3, flexShrink: 0,
        border: `1px solid ${meta.color}`, color: meta.color,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 12, background: 'var(--paper)',
      }}>{meta.icon}</span>
      <div style={{ minWidth: 0 }}>
        <div className="sk-underline" style={{
          fontFamily: 'Inter', fontSize: 12, fontWeight: 600, color: 'var(--ink)',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>{link.label}</div>
        <div className="mono" style={{ fontSize: 10, color: 'var(--ink3)', marginTop: 1 }}>
          {link.meta}
        </div>
      </div>
      <span style={{ color: 'var(--ink4)', fontSize: 12, flexShrink: 0 }}>↗</span>
    </div>
  );
}

// ─── Inline composer ──────────────────────────────────────────────────
function Composer({ variant = 'expanded', you = { initials: 'M', name: 'Mari L.' } }) {
  if (variant === 'collapsed') {
    return (
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        padding: '9px 12px', border: '1.5px solid var(--ink4)',
        borderRadius: 6, background: 'var(--paper)',
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: 999,
          background: 'var(--paper2)', border: '1.25px solid var(--ink4)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'Inter', fontSize: 11, fontWeight: 600, color: 'var(--ink2)',
        }}>{you.initials}</div>
        <span style={{ flex: 1, fontFamily: 'Inter', fontSize: 12, color: 'var(--ink4)' }}>
          Post a notice, announcement or poll…
        </span>
        <span className="sk-icon" style={{ fontSize: 13 }}>✎</span>
        <span className="sk-icon" style={{ fontSize: 13 }}>◉</span>
        <span className="sk-icon" style={{ fontSize: 13 }}>📎</span>
      </div>
    );
  }
  // expanded
  return (
    <div style={{
      border: '1.5px solid var(--ink3)', borderRadius: 6, background: 'var(--paper)',
      boxShadow: '2px 2px 0 0 var(--ink5)', overflow: 'hidden',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '8px 12px', borderBottom: '1px dashed var(--ink5)',
        background: 'var(--paper2)',
      }}>
        <div style={{
          width: 26, height: 26, borderRadius: 999,
          background: 'var(--paper)', border: '1.25px solid var(--ink4)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'Inter', fontSize: 11, fontWeight: 600, color: 'var(--ink2)',
        }}>{you.initials}</div>
        <span style={{ fontFamily: 'Inter', fontSize: 12, color: 'var(--ink2)', fontWeight: 600 }}>{you.name}</span>
        <span style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink4)' }}>posting to <strong style={{ color: 'var(--ink3)' }}>Kaaren Kammerkoor</strong></span>
        <span style={{ flex: 1 }} />
        <span style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)', display: 'flex', gap: 6 }}>
          <span style={{
            padding: '2px 8px', border: '1.25px solid var(--ink)',
            borderRadius: 3, background: 'var(--paper)', color: 'var(--ink)',
            fontWeight: 600,
          }}>✎ Announcement</span>
          <span style={{ padding: '2px 8px', border: '1.25px dashed var(--ink4)', borderRadius: 3 }}>◉ Poll</span>
        </span>
      </div>
      <div style={{ padding: '10px 12px' }}>
        <input
          placeholder="Title (short & specific)"
          style={{
            width: '100%', border: 'none', outline: 'none', background: 'transparent',
            fontFamily: 'Inter', fontSize: 14, fontWeight: 600, color: 'var(--ink)',
            padding: '2px 0', marginBottom: 4,
          }}
          defaultValue=""
        />
        <div style={{
          fontFamily: 'Inter', fontSize: 12, color: 'var(--ink4)',
          minHeight: 40, lineHeight: 1.4,
        }}>
          Write a message… drop a @mention, link a score with /, or attach a file.
        </div>
      </div>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '8px 12px', borderTop: '1px dashed var(--ink5)',
        background: 'var(--paper2)',
      }}>
        <span className="sk-icon" style={{ fontSize: 12 }}>📎</span>
        <span className="sk-icon" style={{ fontSize: 12 }}>♫</span>
        <span className="sk-icon" style={{ fontSize: 12 }}>❒</span>
        <span style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)' }}>link repertoire · library · event</span>
        <span style={{ flex: 1 }} />
        <label style={{
          fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)',
          display: 'inline-flex', alignItems: 'center', gap: 5,
        }}>
          <span style={{
            width: 12, height: 12, border: '1.25px solid var(--ink4)',
            background: 'var(--paper)', borderRadius: 2,
          }} />
          Pin to top
        </label>
        <button className="sk-btn ghost" style={{ fontSize: 11 }}>Save draft</button>
        <button className="sk-btn primary" style={{ fontSize: 11 }}>Post →</button>
      </div>
    </div>
  );
}

// ─── Subnav (workspace, notices active) ──────────────────────────────
function NoticesSubnav() {
  const tabs = ['agenda', 'library', 'roster', 'notices'];
  const active = 'notices';
  return (
    <div style={{
      display:'flex', alignItems:'center', justifyContent:'space-between',
      padding:'8px 20px', borderBottom:'1.5px solid var(--ink5)',
      background:'var(--paper)', fontFamily:'Inter', fontSize:12,
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:14 }}>
        {tabs.map(t => (
          <span key={t} style={{
            color: active===t ? 'var(--ink)' : 'var(--ink3)',
            fontWeight: active===t ? 600 : 400,
            borderBottom: active===t ? '2px solid var(--accent)' : '2px solid transparent',
            padding:'3px 0', textTransform:'capitalize',
            display:'inline-flex', alignItems:'center', gap:6,
          }}>
            {t}
            {t === 'notices' && (
              <span style={{
                background: 'var(--accent)', color: '#fff',
                fontSize: 9, fontWeight: 700, padding: '1px 5px',
                borderRadius: 999, fontFamily: 'Inter', lineHeight: 1.3,
              }}>3</span>
            )}
          </span>
        ))}
      </div>
      <a style={{ fontSize: 11, color: 'var(--ink3)' }}>
        <span className="sk-underline">Notification settings</span>
      </a>
    </div>
  );
}

Object.assign(window, {
  NOTICE_AUTHORS, NOTICES, TYPE_META,
  Avatar, RoleBadge, TypeChip, UnreadDot,
  Reactions, PollBody, LinkedItem, Composer, NoticesSubnav,
});
