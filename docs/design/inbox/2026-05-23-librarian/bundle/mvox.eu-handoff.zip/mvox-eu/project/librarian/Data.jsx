// Shared mock data for the Librarian view — Estonian Philharmonic Chamber Choir,
// Tuesday afternoon. Three pinned tasks for Maire today.
//
// Real composers/works (public-domain choral repertoire), synthetic Estonian names.

const TODAY = { iso: '2026-05-26', dow: 'Tue', date: '26 May 2026', time: '14:32' };

const CHOIR = {
  name: 'Estonian Philharmonic Chamber Choir',
  short: 'EPCC',
  slug: 'epcc',
  initials: 'EP',
  rehearsal_size: 48,
};

const MEMBERS = [
  { id:'mt',  name:'Maris Tamm',     voice:'S1' },
  { id:'ls',  name:'Liina Saar',     voice:'S2' },
  { id:'al',  name:'Ave Lepp',       voice:'A'  },
  { id:'kp',  name:'Kärt Põld',      voice:'A'  },
  { id:'tm',  name:'Toomas Mägi',    voice:'T1' },
  { id:'av',  name:'Andres Vahar',   voice:'T2' },
  { id:'mr',  name:'Margus Roos',    voice:'B1' },
  { id:'hk',  name:'Henn Kuusik',    voice:'B2' },
];

const byId = id => MEMBERS.find(m => m.id === id);

// Edition shape:
//   { id, label, voicing, lang, publisher, year, isbn,
//     total, on_loan, overdue, returned_today }
//
// Work shape:
//   { id, composer, title, year, lang, tags, notes, editions[] }
//
// We compose stats from editions, but pre-bake for clarity where the design needs it.

const WORKS = [
  {
    id:'tallis-spem',
    composer:'Thomas Tallis',
    title:'Spem in alium',
    year:1570,
    lang:'Latin',
    period:'Renaissance',
    tags:['sacred','motet','40-voice'],
    notes:'Returned this morning from December concert (basses brought the manila folder back). Twelve copies counted. Confirm before they walk out again.',
    editions:[
      { id:'tallis-40', label:'40-part original', voicing:'SSSSAAAATTTTBBBB ×5', publisher:'Chester Novello', year:1928,
        total:12, on_loan:0, overdue:0, returned_today:12 },
      { id:'tallis-8',  label:'8-part reduction (Cooke)', voicing:'SSAATTBB', publisher:'OUP', year:1989,
        total:6, on_loan:0, overdue:0, returned_today:0 },
    ],
  },
  {
    id:'part-magnificat',
    composer:'Arvo Pärt',
    title:'Magnificat',
    year:1989,
    lang:'Latin',
    period:'Contemporary',
    tags:['sacred','Estonian','tintinnabuli'],
    notes:'Four copies still out with two basses since November. Owe rental library. Nudge today or write off.',
    editions:[
      { id:'mag-ue',   label:'Universal Edition · original', voicing:'SSSAATBB', publisher:'Universal Edition', year:1989, isbn:'UE-19400',
        total:30, on_loan:4, overdue:4, returned_today:0,
        loans:[
          { copy:'#14', member:'hk', since:'2025-11-12', days_overdue:195 },
          { copy:'#15', member:'hk', since:'2025-11-12', days_overdue:195 },
          { copy:'#22', member:'mr', since:'2025-11-12', days_overdue:195 },
          { copy:'#23', member:'mr', since:'2025-11-12', days_overdue:195 },
        ],
      },
      { id:'mag-rh',   label:'Hyperion · reduced (Layton ed.)', voicing:'SATB div.', publisher:'Hyperion Eds.', year:2001,
        total:24, on_loan:0, overdue:0, returned_today:0 },
      { id:'mag-org',  label:'UE · with organ', voicing:'SATB + org.', publisher:'Universal Edition', year:1996,
        total:0, on_loan:0, overdue:0, returned_today:0, limitless:true },
    ],
  },
  {
    id:'tormis-raua',
    composer:'Veljo Tormis',
    title:'Raua needmine',
    title_alt:'Curse upon Iron',
    year:1972,
    lang:'Estonian',
    period:'Contemporary',
    tags:['Estonian','runo','shaman drum'],
    notes:'Conductor wants to try tonight. 48 singers expected — check copy count.',
    editions:[
      { id:'raua-fg', label:'Fennica Gehrman · SATB + shaman drum', voicing:'SATB · drum', publisher:'Fennica Gehrman', year:1991, isbn:'FG-552',
        total:52, on_loan:0, overdue:0, returned_today:0,
        location:'Cabinet B · shelf 1' },
      { id:'raua-pl', label:'Pelle Pyy · a cappella reduction', voicing:'SATB', publisher:'Pyy', year:2003,
        total:18, on_loan:0, overdue:0, returned_today:0 },
    ],
  },
  {
    id:'kreek-onnis',
    composer:'Cyrillus Kreek',
    title:'Õnnis on inimene',
    title_alt:'Blessed is the man',
    year:1923,
    lang:'Estonian',
    period:'20th century',
    tags:['Estonian','sacred','psalm'],
    notes:'For tonight. Owned in one edition — count is tight.',
    editions:[
      { id:'onnis-sp', label:'SP Muusikaprojekt', voicing:'SATB', publisher:'SP Muusikaprojekt', year:1998,
        total:42, on_loan:2, overdue:0, returned_today:0,
        location:'Cabinet A · shelf 4' },
    ],
  },
  {
    id:'esenvalds-stars',
    composer:'Ēriks Ešenvalds',
    title:'Stars',
    year:2011,
    lang:'English',
    period:'Contemporary',
    tags:['Latvian','contemporary','tuned glasses'],
    notes:'For tonight. Needs tuned water-glasses; cellist will be there.',
    editions:[
      { id:'stars-mt', label:'Musica Baltica · SATB + glasses', voicing:'SSAATTBB', publisher:'Musica Baltica', year:2011, isbn:'MB-2089',
        total:50, on_loan:0, overdue:0, returned_today:0,
        location:'Cabinet C · shelf 2' },
    ],
  },
  // Background holdings, for catalog density.
  {
    id:'part-beatitudes', composer:'Arvo Pärt', title:'The Beatitudes', year:1990,
    lang:'English', period:'Contemporary', tags:['sacred','Estonian','tintinnabuli'],
    editions:[{ id:'beat-ue', label:'Universal Edition', voicing:'SATB + org.', publisher:'Universal Edition', year:1990, total:32, on_loan:0, overdue:0, returned_today:0 }],
  },
  {
    id:'esenvalds-sleep', composer:'Ēriks Ešenvalds', title:'Only in Sleep', year:2010,
    lang:'English', period:'Contemporary', tags:['Latvian','soprano solo'],
    editions:[{ id:'sleep-mb', label:'Musica Baltica', voicing:'SSAATTBB + sop. solo', publisher:'Musica Baltica', year:2010, total:48, on_loan:0, overdue:0, returned_today:0 }],
  },
  {
    id:'byrd-ave', composer:'William Byrd', title:'Ave verum corpus', year:1605,
    lang:'Latin', period:'Renaissance', tags:['sacred','English'],
    editions:[{ id:'ave-st', label:'Stainer & Bell', voicing:'SATB', publisher:'Stainer & Bell', year:1923, total:60, on_loan:0, overdue:0, returned_today:0 }],
  },
  {
    id:'byrd-mass5', composer:'William Byrd', title:'Mass for Five Voices', year:1595,
    lang:'Latin', period:'Renaissance', tags:['sacred','English','mass'],
    editions:[{ id:'mass5-cs', label:'Chester · ed. Fellowes', voicing:'SSATB', publisher:'Chester', year:1922, total:24, on_loan:0, overdue:0, returned_today:0 }],
  },
  {
    id:'hildegard-pastor', composer:'Hildegard von Bingen', title:'O Pastor Animarum', year:1150,
    lang:'Latin', period:'Medieval', tags:['sacred','plainchant'],
    editions:[{ id:'pastor-am', label:'A-R Editions · transcription', voicing:'Unison + drone', publisher:'A-R Editions', year:1998, total:0, on_loan:0, overdue:0, returned_today:0, limitless:true }],
  },
  {
    id:'whitacre-sleep', composer:'Eric Whitacre', title:'Sleep', year:2000,
    lang:'English', period:'Contemporary', tags:['American'],
    editions:[{ id:'wh-sleep', label:'Walton Music', voicing:'SATB div.', publisher:'Walton Music', year:2000, total:56, on_loan:6, overdue:0, returned_today:0 }],
  },
  {
    id:'nystedt-immortal', composer:'Knut Nystedt', title:'Immortal Bach', year:1988,
    lang:'German', period:'Contemporary', tags:['Norwegian'],
    editions:[{ id:'im-no', label:'Norsk Musikforlag', voicing:'SATB div.', publisher:'Norsk Musikforlag', year:1988, total:50, on_loan:0, overdue:0, returned_today:0 }],
  },
  {
    id:'lauridsen-om', composer:'Morten Lauridsen', title:'O Magnum Mysterium', year:1994,
    lang:'Latin', period:'Contemporary', tags:['sacred','American'],
    editions:[{ id:'om-pe', label:'Peer Music', voicing:'SATB', publisher:'Peer Music', year:1994, total:48, on_loan:0, overdue:0, returned_today:0 }],
  },
];

// ─── Today's three tasks ─────────────────────────────────────────────
const TASKS = [
  {
    id:'returns',
    rank:1,
    kind:'returns',
    title:'Mark Tallis copies returned',
    summary:'12 copies of Spem in alium back from December concert',
    work_id:'tallis-spem',
    edition_id:'tallis-40',
    count:12,
    confirmed:8,    // 8 already ticked, 4 to confirm
    pending:4,
  },
  {
    id:'overdue',
    rank:2,
    kind:'overdue',
    title:'Chase Pärt Magnificat',
    summary:'4 copies still out with two basses since November',
    work_id:'part-magnificat',
    edition_id:'mag-ue',
    count:4,
    borrowers:['hk','mr'],
    days:195,
  },
  {
    id:'pull',
    rank:3,
    kind:'pull',
    title:'Pull tonight\u2019s three pieces',
    summary:'Tormis · Kreek · Ešenvalds — 48 singers',
    work_ids:['tormis-raua','kreek-onnis','esenvalds-stars'],
    pulled: { 'tormis-raua': 48, 'kreek-onnis': 0, 'esenvalds-stars': 0 },
  },
];

// ─── Aggregate library stats ────────────────────────────────────────
function libStats() {
  let works = WORKS.length, editions = 0, copies = 0, on_loan = 0, overdue = 0;
  WORKS.forEach(w => {
    editions += w.editions.length;
    w.editions.forEach(e => {
      copies   += e.total || 0;
      on_loan  += e.on_loan || 0;
      overdue  += e.overdue || 0;
    });
  });
  return { works, editions, copies, on_loan, overdue, available: copies - on_loan };
}

function workById(id) { return WORKS.find(w => w.id === id); }
function editionById(work, eid) { return work && work.editions.find(e => e.id === eid); }
function workStats(w) {
  let total = 0, loaned = 0, overdue = 0, returned_today = 0, has_limitless = false;
  w.editions.forEach(e => {
    if (e.limitless) { has_limitless = true; return; }
    total          += e.total || 0;
    loaned         += e.on_loan || 0;
    overdue        += e.overdue || 0;
    returned_today += e.returned_today || 0;
  });
  return { total, loaned, overdue, returned_today, available: total - loaned, has_limitless };
}

Object.assign(window, {
  TODAY, CHOIR, MEMBERS, byId, WORKS, TASKS, libStats, workById, editionById, workStats,
});
