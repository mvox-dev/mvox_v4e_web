// Repertoire — NOT a separate page in the product. It's the /library page
// with the "Current season" filter default-on and a "by programme" grouping
// view mode. This wireframe shows that state of the library page.
//
// Programme = a concert project (Reekviem, Spring Gala, Autumn). Each
// programme groups a subset of works. A work may appear in 0-2 programmes.

// Programmes for 2024/25 season, drawn from LIBRARY ids.
const PROGRAMMES = [
  { id:'reekviem', title:'Reekviem — Duruflé', when:'Sat 3 May', venue:'Kaarli kirik', workIds:[1, 2, 3] },
  { id:'spring',   title:'Spring Gala',         when:'Sat 24 May', venue:'Mustpeade Maja', workIds:[4, 5] },
  { id:'summer',   title:'Suvine õhtu',         when:'Sat 7 Jun',  venue:'Vanemuise, Tartu', workIds:[6] },
];

// Works not in any programme for this season
const CURRENT_SEASON_IDS = new Set([1,2,3,4,5,6]);

function RepertoireView() {
  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor/library?view=current&group=programme">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column' }}>
        <WorkspaceNav />
        <LibrarySubnav />

        {/* View toolbar — replaces the filter bar on this view */}
        <div style={{
          display:'flex', alignItems:'center', gap:10, padding:'10px 24px',
          borderBottom:'1.5px solid var(--ink5)', background:'var(--paper2)', flexWrap:'wrap',
        }}>
          <Eyebrow>View</Eyebrow>

          {/* Scope toggle */}
          <div style={{ display:'flex', alignItems:'center', gap:0, border:'1.25px solid var(--ink4)', borderRadius:4, overflow:'hidden', background:'var(--paper)' }}>
            <span style={{ padding:'4px 10px', fontFamily:'Inter', fontSize:11, fontWeight:600, background:'var(--ink)', color:'var(--paper)' }}>Current season</span>
            <span style={{ padding:'4px 10px', fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>Everything</span>
            <span style={{ padding:'4px 10px', fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>Archive</span>
          </div>

          <span style={{ color:'var(--ink4)' }}>·</span>

          {/* Group toggle */}
          <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>Group by</span>
          <div style={{ display:'flex', alignItems:'center', gap:0, border:'1.25px solid var(--ink4)', borderRadius:4, overflow:'hidden', background:'var(--paper)' }}>
            <span style={{ padding:'4px 10px', fontFamily:'Inter', fontSize:11, fontWeight:600, background:'var(--ink)', color:'var(--paper)' }}>Programme</span>
            <span style={{ padding:'4px 10px', fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>Composer</span>
            <span style={{ padding:'4px 10px', fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>None</span>
          </div>

          <span style={{ color:'var(--ink4)' }}>·</span>
          <Chip variant="accent" style={{ fontSize:10 }}>6 works · 3 programmes</Chip>

          <div style={{ flex:1 }} />
          <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
            <span className="sk-underline">Season 2024/25</span> ▾
          </span>
          <button className="sk-btn primary" style={{ fontSize:12 }}>＋ Add work</button>
        </div>

        {/* Callout strip */}
        <div style={{
          padding:'8px 24px', background:'var(--paper)', borderBottom:'1px solid var(--ink5)',
          fontFamily:'Inter', fontSize:11, color:'var(--ink3)',
          display:'flex', alignItems:'center', gap:8,
        }}>
          <Annot style={{ transform:'rotate(0)' }}>↳ "Repertoire" is just this view</Annot>
          <span>— /library with <span className="mono" style={{ color:'var(--ink2)' }}>?view=current&amp;group=programme</span> pre-applied. Switch scope or grouping to reach the full library.</span>
        </div>

        {/* Body: programme groups */}
        <div style={{ flex:1, overflow:'hidden', padding:'14px 24px 18px', display:'flex', flexDirection:'column', gap:14 }}>
          {PROGRAMMES.map(p => {
            const works = p.workIds.map(id => LIBRARY.find(w => w.id === id)).filter(Boolean);
            return <ProgrammeBlock key={p.id} programme={p} works={works} />;
          })}

          {/* Unprogrammed current-season works (if any) */}
          <UnprogrammedBlock />
        </div>
      </div>
    </BrowserFrame>
  );
}

function ProgrammeBlock({ programme, works }) {
  return (
    <div style={{
      border:'1.5px solid var(--ink4)', borderRadius:6,
      background:'var(--paper)', overflow:'hidden',
    }}>
      {/* Programme header */}
      <div style={{
        padding:'10px 14px', background:'var(--paper2)',
        borderBottom:'1px solid var(--ink5)',
        display:'flex', alignItems:'baseline', gap:10,
      }}>
        <span style={{ fontSize:11, color:'var(--ink3)' }}>▾</span>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontFamily:'Inter', fontSize:14, fontWeight:700, letterSpacing:'-0.005em', color:'var(--ink)' }}>
            {programme.title}
          </div>
          <div style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink3)', marginTop:1 }}>
            <span className="mono" style={{ color:'var(--ink2)' }}>{programme.when}</span>
            <span style={{ margin:'0 5px' }}>·</span>
            <span>{programme.venue}</span>
            <span style={{ margin:'0 5px' }}>·</span>
            <span>{works.length} works</span>
          </div>
        </div>
        <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)', display:'flex', gap:10 }}>
          <span className="sk-underline">Edit programme</span>
          <span className="sk-underline">View concert →</span>
        </span>
      </div>

      {/* Works in programme */}
      <div>
        {works.map((w, i) => <WorkRow key={w.id} work={w} compact />)}
      </div>
    </div>
  );
}

function UnprogrammedBlock() {
  return (
    <div style={{
      border:'1.5px dashed var(--ink4)', borderRadius:6,
      padding:'10px 14px', background:'transparent',
      display:'flex', alignItems:'center', gap:10,
    }}>
      <span style={{ fontSize:11, color:'var(--ink4)' }}>▸</span>
      <div style={{ flex:1 }}>
        <div style={{ fontFamily:'Inter', fontSize:12, fontWeight:600, color:'var(--ink2)' }}>
          Not programmed
        </div>
        <div style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink4)', marginTop:1 }}>
          0 works this season haven't been assigned to a concert programme.
        </div>
      </div>
      <button className="sk-btn ghost" style={{ fontSize:10 }}>+ Add programme</button>
    </div>
  );
}

window.RepertoireView = RepertoireView;
