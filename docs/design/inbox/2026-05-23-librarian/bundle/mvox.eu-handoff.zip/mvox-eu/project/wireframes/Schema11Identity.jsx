// 1.1 Identity + membership — organization, person, member, section, voice.
// Convention used across all five cards:
//   • Parent edges flow PARENT → CHILD (top-down).
//   • Every edge is labelled with verb + multiplicity.
//   • Multi-parent children render with a hollow circle at the parent end of
//     each of their parent edges (one of several parents).
//   • Recursion shown as a self-loop arrow over the top of the entity card.
//   • References are inline on the property rows (→ targetType), not arrows,
//     to avoid spaghetti.

function Schema11Identity() {
  // Card coordinates (top-left). Tuned by eye against rendered heights.
  const C = {
    person:  { x: 70,   y: 160, w: 240 },
    voice:   { x: 1130, y: 160, w: 210 },
    org:     { x: 470,  y: 140, w: 320 },
    section: { x: 320,  y: 510, w: 230 },
    member:  { x: 720,  y: 510, w: 260 },
  };

  // Parent → child arrows
  const arrows = [
    // person → org (founded by) — required-1 founder; org may also have umbrella parents
    {
      from: { x: C.person.x + C.person.w, y: 232 },
      to:   { x: C.org.x,                  y: 232 },
      verb: 'founded by',
      cardinality: '1 founder · N orgs per person',
      multi: true,
    },

    // org → org (umbrella of) — recursive self-loop on top of the org card
    {
      from:      { x: C.org.x + C.org.w - 70, y: C.org.y },
      waypoints: [
        { x: C.org.x + C.org.w - 70, y: C.org.y - 38 },
        { x: C.org.x + 70,           y: C.org.y - 38 },
      ],
      to:        { x: C.org.x + 70, y: C.org.y },
      verb: 'umbrella of',
      cardinality: '0..N umbrella parents · acyclic',
      multi: true,
      labelAt: { x: C.org.x + C.org.w / 2, y: C.org.y - 38 },
      labelOffset: [0, 0],
    },

    // org → section (section of)
    {
      from: { x: C.org.x + 90,  y: C.org.y + 260 },
      to:   { x: C.section.x + C.section.w - 50, y: C.section.y },
      verb: 'section of',
      cardinality: '1 parent per section',
    },

    // section → section (sub-section of) — recursive self-loop on top
    {
      from:      { x: C.section.x + C.section.w - 50, y: C.section.y },
      waypoints: [
        { x: C.section.x + C.section.w - 50, y: C.section.y - 32 },
        { x: C.section.x + 60,               y: C.section.y - 32 },
      ],
      to:        { x: C.section.x + 60, y: C.section.y },
      verb: 'sub-section of',
      cardinality: '1 parent · recursive',
      labelAt: { x: C.section.x + C.section.w / 2 - 10, y: C.section.y - 32 },
    },

    // org → member (roster of) — required parent
    {
      from: { x: C.org.x + 230, y: C.org.y + 260 },
      to:   { x: C.member.x + 80, y: C.member.y },
      verb: 'roster of',
      cardinality: '1 org per member · required',
      multi: true,
    },

    // section → member (sings in)
    {
      from: { x: C.section.x + C.section.w, y: C.section.y + 50 },
      to:   { x: C.member.x,                 y: C.section.y + 50 },
      verb: 'sings in',
      cardinality: '0..N sections per member',
      multi: true,
    },
  ];

  return (
    <div className="sk" style={{ height: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column', background: 'var(--paper)' }}>
      <SchemaSectionHead
        index="1.1"
        title="Identity + membership"
        intro="Person is the identity hub — one per human, lives at the database root, regardless of how many choirs they sing in. Organization is a rights island: _inheritrights:false blocks cascades from umbrella orgs. Member is the per-org consent record; minimal by design, with all self-edits moved to person."
        meta="organization · person · member · section · voice"
      />

      <div style={{ flex: 1, position: 'relative' }}>
        <ArrowLayer arrows={arrows} width={1400} height={770} />

        <EntityCard
          name="person"
          blurb="Identity hub — one per human"
          sharing="public"
          parent="add_user · system"
          props={[
            { name: 'name', type: 'string', req: true },
            { name: 'voice', type: 'voice', ref: true, list: true },
            { name: 'bio', type: 'text' },
            { name: 'avatar', type: 'file' },
            { name: 'preferred_contact_email', type: 'string · private' },
            { name: 'notes', type: 'text · private' },
            { name: 'entu_user', type: 'oauth · system', list: true },
          ]}
          top={C.person.y} left={C.person.x} width={C.person.w}
        />

        <EntityCard
          name="voice"
          blurb="Global vocal/instrument taxonomy"
          sharing="public"
          global
          parent="polyphony db root"
          props={[
            { name: 'name', type: 'string', req: true },
            { name: 'class', type: 'string', req: true },
            { name: 'display_order', type: 'number' },
            { name: 'description', type: 'text' },
          ]}
          top={C.voice.y} left={C.voice.x} width={C.voice.w}
        />

        <EntityCard
          name="organization"
          blurb="Choir, ensemble, or umbrella org"
          sharing="public"
          island
          variant="accent"
          parent="person · AND · 0..N organization"
          parentNote="founder is always a parent; umbrella orgs add more (multi-parent, acyclic)"
          props={[
            { name: 'name', type: 'string', req: true },
            { name: 'description', type: 'text' },
            { name: 'founded', type: 'date' },
            { name: 'location', type: 'string' },
            { name: 'website', type: 'string' },
            { name: 'logo', type: 'file' },
            { name: 'rsvp_lockout_hours', type: 'number · private' },
            { name: 'public_contact', type: 'member', ref: true, list: true },
            { name: 'member_count_per_section', type: 'recursive roll-up', formula: true },
          ]}
          top={C.org.y} left={C.org.x} width={C.org.w}
        />

        <EntityCard
          name="section"
          blurb="Voice grouping or sub-ensemble"
          sharing="public"
          parent="organization · OR · section"
          props={[
            { name: 'name', type: 'string', req: true },
            { name: 'voice', type: 'voice', ref: true },
            { name: 'description', type: 'text' },
            { name: 'display_order', type: 'number' },
            { name: 'member_count', type: '_child member SUM', formula: true },
          ]}
          top={C.section.y} left={C.section.x} width={C.section.w}
        />

        <EntityCard
          name="member"
          blurb="Per-org membership · admin-controlled"
          sharing="private"
          parent="organization + section(s)"
          parentNote="always under org · multi-parent under each section the person sings in"
          props={[
            { name: 'person', type: 'person', ref: true, req: true },
            { name: 'current_section', type: 'section', ref: true },
            { name: 'status', type: 'active | archived', req: true },
          ]}
          top={C.member.y} left={C.member.x} width={C.member.w}
        />

        {/* Margin annotations — Caveat handwritten notes */}
        <MarginNote top={C.org.y + 8} left={C.org.x + C.org.w + 18} indigo>
          <span className="arrow">←</span> rights island —<br />cascades from umbrella<br />stop at this border
        </MarginNote>

        <MarginNote top={C.voice.y + 165} left={C.voice.x - 10}>
          one source of truth<br />referenced by<br />person.voice & section.voice
        </MarginNote>

        <SchemaLegend />
      </div>
    </div>
  );
}

window.Schema11Identity = Schema11Identity;
