# Polyphony Schema v4E — Source of Truth for UI Design

**Date**: 2026-05-18
**Status**: Current canonical schema (post-design-sessions 1–3); reflects all decisions captured in `docs/superpowers/specs/2026-05-1*` and the case study at `docs/case-studies/2026-05-polyphony-on-entu.md`. Designed as the single reference UI designers + implementers should consult.

**Relation to v3**: v3 (in `docs/schema/v3/`) was the pre-redesign sketch with per-entity spec files and combined Participation, role-as-entity, Affiliation, and SQL-mapping notes. **v4E supersedes v3** as the canonical model. v3 is preserved for historical reference; new work should reference v4E.

**Format**: a single living document — six sections that cut across the schema. As the schema evolves, this file gets updated in place; individual design specs in `docs/superpowers/specs/` stay as append-only decision records.

---

## Section 1 — Entity catalog

19 entity types organised by domain. For each: parent options, properties table, notable behaviors, and link to the originating design spec.

Convention notes:

- All entity type names are **lowercase**, snake_case for multi-word (per Phase A rename, PR #30)
- Properties marked **(formula)** are computed at save time by Entu's formula engine — see formula limits in the case study Section A
- `_sharing` defaults shown per instance; type-level `_sharing: public` is required on the type definition to enable per-property public projection
- All entities default `_inheritrights: true` EXCEPT `organization` (which is `false` — rights island; see Section 3)

### 1.1 Identity + membership

#### `organization`

The choir, ensemble, or umbrella org. Recursive via multi-parent (a collective can be child of multiple umbrellas; an umbrella can be child of higher-level federations). Created as child of the founder's person entity per the founder-flow.

**Parent**: person (founder, at creation) OR another organization (umbrella relationship; multi-parent) OR a combination

**`_inheritrights`**: `false` (rights island — blocks cascading from umbrella to collective; see Section 3)

**`_sharing`**: type `public`, instance `public` default (federation-discoverable; admin can flip to `private` per org)

| Property                   | Type         | Required | Notes                                                                                                                    |
| -------------------------- | ------------ | -------- | ------------------------------------------------------------------------------------------------------------------------ |
| `name`                     | string       | yes      | choir's display name; public                                                                                             |
| `description`              | text         | no       | marketing copy; public                                                                                                   |
| `founded`                  | date         | no       | choir's founding date; public                                                                                            |
| `location`                 | string       | no       | e.g., "Tallinn, Estonia"; public                                                                                         |
| `website`                  | string       | no       | URL; public                                                                                                              |
| `logo`                     | file         | no       | display image; public                                                                                                    |
| `social_links`             | list         | no       | future — FB, IG, etc.; public                                                                                            |
| `rsvp_lockout_hours`       | number       | no       | hours before event start when RSVP becomes uneditable; `0` (default) = soft warning only, positive = hard block; private |
| `public_contact[*]`        | ref → member | no       | designated public contacts; default = owner + conductor; public                                                          |
| `member_count_per_section` | (formula)    | —        | aggregates across child sections; public                                                                                 |
| `_inheritrights`           | boolean      | yes      | `false` (rights island)                                                                                                  |

**Spec**: `2026-05-17-org-rights-isolation-design.md`, federation visibility additions in `2026-05-18-bff-rights-pattern-design.md`

#### `person`

Identity hub for humans — one per real person, regardless of org count. Created by Entu's OAuth auto-create flow.

**Parent**: the polyphony database's `add_user` target (system-managed)

**`_sharing`**: type `public`, instance `public` default (discoverable — singers benefit from being findable; per-person opt-out by flipping to `private`)

| Property                  | Type        | Required | Notes                                                                                                     |
| ------------------------- | ----------- | -------- | --------------------------------------------------------------------------------------------------------- |
| `name`                    | string      | yes      | display name; self-editable; public                                                                       |
| `voice[*]`                | ref → voice | no       | self-declared vocal capabilities; public                                                                  |
| `bio`                     | text        | no       | self-editable; public                                                                                     |
| `avatar`                  | file        | no       | self-editable; public                                                                                     |
| `notes`                   | text        | no       | self-editable; private; surfaced to org admins via BFF report                                             |
| `preferred_contact_email` | string      | no       | self-chosen from `entu_user[*].email` or custom; private; outbound only                                   |
| `preferences`             | (future)    | no       | self-editable; private                                                                                    |
| `entu_user[*]`            | system      | yes      | OAuth identity links `{uid, email, provider}`; private; multi-value (multiple OAuth providers per person) |
| `email`                   | string      | no       | Entu auto-create default; informational only; NEVER use for identity decisions                            |

`_editor: self` on person comes from Entu's auto-create flow — user can self-edit all `_editor`-visible properties.

**Spec**: `2026-05-17-onboarding-design.md`, `2026-05-17-email-trust-design.md`

#### `member`

Per-org membership record. Minimal — admin-controlled; all self-edit moved to person.

**Parent (multi-parent)**: `organization` (always) AND `section(s)` (zero or more; section assignment IS the parent relationship)

**`_sharing`**: type `public`, instance `private` default (member roster is org-internal)

| Property          | Type          | Required | Notes                                             |
| ----------------- | ------------- | -------- | ------------------------------------------------- |
| `person`          | ref → person  | yes      | the person this membership belongs to             |
| `current_section` | ref → section | no       | primary section pointer for multi-section members |
| `status`          | enum          | yes      | `active` \| `archived`                            |

No `role[]` (roles are rights grants — Section 3). No `section[]` (parent relationship). No `voice` (lives on person). No `contact_email` (uses `person.preferred_contact_email`).

**Spec**: `2026-05-17-onboarding-design.md` (entity structure section)

#### `section`

Voice grouping / sub-ensemble. **Recursive** — sections can have child sections (e.g., `Full Choir → S → S1, S2`). Multi-parent for members (a member can be in multiple sections).

**Parent**: `organization` OR another `section` (recursive)

**`_sharing`**: type `public`, instance `public` default (federation can see org's section structure); per-section opt-out by flipping to `private` (e.g., for an audition-only ensemble)

| Property        | Type        | Required | Notes                                                                                   |
| --------------- | ----------- | -------- | --------------------------------------------------------------------------------------- |
| `name`          | string      | yes      | e.g., "Soprano", "Soprano 1", "Quartet"; public                                         |
| `voice`         | ref → voice | no       | categorization; null for mixed-voice sections; public                                   |
| `description`   | text        | no       | public                                                                                  |
| `display_order` | number      | no       | UI sort within parent; public                                                           |
| `member_count`  | (formula)   | —        | `(_child.member COUNT) (_child.section.member_count SUM) +` — recursive roll-up; public |

**Spec**: `2026-05-17-section-structure-design.md`

#### `voice`

Global vocal-range taxonomy. Lives under polyphony database root (not under any org). One source of truth referenced by `person.voice` and `section.voice`.

**Parent**: polyphony database root (or dedicated `taxonomies` parent entity)

**`_sharing`**: type `public`, instance `public` default

| Property        | Type   | Required | Notes                                                                                                                  |
| --------------- | ------ | -------- | ---------------------------------------------------------------------------------------------------------------------- |
| `name`          | string | yes      | e.g., "Soprano", "Violin", "Trumpet"                                                                                   |
| `class`         | string | yes      | e.g., "vocals", "strings", "brass", "woodwinds", "percussion", "keyboards" — enables platform reach beyond pure choirs |
| `display_order` | number | no       | UI sort within class                                                                                                   |
| `description`   | text   | no       | for less-common voices (Countertenor, etc.)                                                                            |

**Spec**: `2026-05-17-section-structure-design.md` (voice taxonomy section)

### 1.2 Library

Librarian-scoped subtree. All entities default `_sharing: private` — librarian + admins see; federation does not.

#### `library`

1:1 with org. Container for catalog + lending.

**Parent**: `organization` (single, mandatory)

**`_sharing`**: `private`

| Property | Type   | Required | Notes                                             |
| -------- | ------ | -------- | ------------------------------------------------- |
| `name`   | string | yes      | typically "<Org name> Library" or just org's name |

#### `work`

Abstract composition (FRBR Work sense). Arrangements/translations are different Editions of the same Work.

**Parent**: `library` (or another `work` for movements via `part_of`)

**`_sharing`**: `private`

| Property            | Type         | Required | Notes                       |
| ------------------- | ------------ | -------- | --------------------------- |
| `name`              | string       | yes      | title                       |
| `composer`          | string       | no       |                             |
| `catalog_id`        | string       | no       | e.g., "243"                 |
| `catalog_system`    | string       | no       | e.g., "BWV"                 |
| `original_voicing`  | string       | no       | composer's intent           |
| `original_duration` | number       | no       | composer's intent (minutes) |
| `original_language` | list, string | no       | composer's text language(s) |
| `genre`             | list, string | no       |                             |
| `part_of`           | ref → work   | no       | for movements               |

#### `edition`

Concrete publication of a work. Where files live.

**Parent**: `work` (single)

**`_sharing`**: `private`

| Property        | Type             | Required | Notes                                                                                                        |
| --------------- | ---------------- | -------- | ------------------------------------------------------------------------------------------------------------ |
| `name`          | string           | yes      | e.g., "Bärenreiter BA 5103, vocal score"                                                                     |
| `external_link` | list, string     | no       | external resource URLs — IMSLP, YouTube, publisher site; complements `file` for non-uploaded references      |
| `work`          | string (formula) | —        | `_parent` — auto-derives work's name string (denormalization; supports `program_item.name` single-hop chain) |
| `edition_type`  | string (set)     | yes      | `full_score \| vocal_score \| part \| reduction \| audio \| video \| supplementary`                          |
| `arranger`      | string           | no       | for arrangements/transcriptions                                                                              |
| `voicing`       | string           | no       | optional override of work.original_voicing                                                                   |
| `duration`      | number           | no       | optional override                                                                                            |
| `language`      | list, string     | no       | optional override                                                                                            |
| `publisher`     | string           | no       |                                                                                                              |
| `year`          | number           | no       |                                                                                                              |
| `license`       | string (set)     | no       | `public_domain \| licensed \| owned`                                                                         |
| `acquired_at`   | date             | no       |                                                                                                              |
| `source`        | string           | no       | donor / vendor / publisher                                                                                   |
| `cost`          | number           | no       |                                                                                                              |
| `license_note`  | text             | no       |                                                                                                              |
| `file`          | list, file       | no       | S3-backed PDFs / audio / video                                                                               |

**Spec**: `2026-05-17-library-subtree-design.md` (edition section, with the `work` formula addition)

#### `copy`

Physical copy of an edition (was `inventory_copy` in v3).

**Parent**: `edition` (single)

**`_sharing`**: `private`

| Property      | Type         | Required | Notes                              |
| ------------- | ------------ | -------- | ---------------------------------- |
| `name`        | string       | yes      | e.g., "Copy #3"                    |
| `copy_number` | number       | yes      | sequential within parent edition   |
| `barcode`     | string       | no       | scannable; app-enforced uniqueness |
| `condition`   | string (set) | no       | `good \| fair \| poor \| lost`     |
| `notes`       | text         | no       | per-copy annotations               |

#### `lending`

First-class loan record. Replaces v3's inline `inventory_copy.assigned_to` / `assigned_at`.

**Parent**: `library` (single)

**`_sharing`**: `private`

| Property         | Type             | Required | Notes                                                                 |
| ---------------- | ---------------- | -------- | --------------------------------------------------------------------- |
| `name`           | string (formula) | —        | `member.*.name copy.*.name ' — ' CONCAT_WS` → "Alice Smith — Copy #3" |
| `copy`           | ref → copy       | yes      |                                                                       |
| `member`         | ref → member     | yes      |                                                                       |
| `assigned_at`    | date             | yes      |                                                                       |
| `assigned_until` | date             | no       | due back                                                              |
| `returned_at`    | date             | no       | absent = still out                                                    |
| `renewed_at`     | list, date       | no       | each renewal extends `assigned_until`                                 |
| `notes`          | text             | no       |                                                                       |

Same-org constraint (BFF-enforced): `lending.copy._parent` chain up to org must match `lending.member._parent` org.

**Spec**: `2026-05-17-library-subtree-design.md`

### 1.3 Onboarding

Bilateral consent model — both org and person must express intent for `member` to come into being. See lifecycle flows in Section 6.

#### `invitation`

Org's consent. Admin creates; user accepts → member created + invitation deleted.

**Parent**: `organization`

**`_sharing`**: `private` (default — invite tokens shouldn't be browsable)

| Property      | Type          | Required | Notes                                                         |
| ------------- | ------------- | -------- | ------------------------------------------------------------- |
| `email`       | string        | yes      | target address                                                |
| `sections[*]` | ref → section | no       | preset section parents to set on the new member at acceptance |
| `token`       | string        | yes      | UUID for URL-based access                                     |
| `expires_at`  | date          | yes      | default 30 days from creation; admin-settable                 |
| `inviter`     | ref → person  | system   | who created the invitation                                    |
| `message`     | text          | no       | personalised note                                             |

#### `application`

Person's consent. Person creates; admin accepts → member created + application deleted.

**Parent**: `person`

**Rights addition**: BFF adds explicit `_viewer: <target_org admin persons>` on creation (so admins can see it across the person→org boundary)

**`_sharing`**: `private`

| Property     | Type               | Required | Notes                                                                |
| ------------ | ------------------ | -------- | -------------------------------------------------------------------- |
| `target_org` | ref → organization | yes      |                                                                      |
| `message`    | text               | no       | applicant's note; can include voice/section preferences in free text |
| `status`     | enum               | yes      | `pending` \| `rejected`                                              |
| `expires_at` | date               | yes      | default 30 days (both pending and rejected)                          |

On reject, BFF flips `_inheritrights: false` + adds explicit `_viewer: <person>` to lock from delete (withdraw-lock for rate limiting).

**Spec**: `2026-05-17-onboarding-design.md`, edge cases E1–E6

### 1.4 Temporal layer

#### `season`

Annual cycle.

**Parent**: `organization` (single)

**`_sharing`**: type `public`, instance `public` default

| Property      | Type   | Required | Notes                                                                                             |
| ------------- | ------ | -------- | ------------------------------------------------------------------------------------------------- |
| `name`        | string | yes      | e.g., "2025/2026 season"; public                                                                  |
| `start_date`  | date   | yes      | public                                                                                            |
| `end_date`    | date   | yes      | required — needed to know "when does ongoing season end" (v3's open-ended model rejected); public |
| `description` | text   | no       | public                                                                                            |

#### `event_series`

Recurring pattern that materialises into events. Series defines defaults; events inherit + override.

**Parent (multi-parent)**: `organization` (always) + optionally `season(s)` + optionally `section(s)`

**`_sharing`**: type `public`, instance `private` default (rehearsal series typically internal; admin flips to public for concert series)

| Property              | Type   | Required | Notes                                                                                   |
| --------------------- | ------ | -------- | --------------------------------------------------------------------------------------- |
| `name`                | string | yes      | e.g., "Tuesday Rehearsals 2025/2026"                                                    |
| `event_type`          | enum   | yes      | `rehearsal \| concert \| festival \| retreat \| workshop \| meeting \| social \| other` |
| `interval_days`       | number | yes      | 7 = weekly; 14 = biweekly; 1 = daily; 30 ≈ monthly                                      |
| `start_time`          | string | yes      | "19:00" (HH:MM)                                                                         |
| `duration_minutes`    | number | yes      | 120                                                                                     |
| `start_date`          | date   | yes      | first occurrence (anchor)                                                               |
| `end_date`            | date   | yes      | last occurrence                                                                         |
| `default_location`    | string | no       | inherited by child events                                                               |
| `default_description` | text   | no       | inherited by child events                                                               |

#### `event`

Concrete occurrence. Inherits unset properties from parent `event_series` (read-time, BFF-mediated).

**Parent (multi-parent)**: `organization` (always) + optionally `season(s)` + optionally `section(s)` + optionally `event_series`

**`_sharing`**: type `public`, instance `private` default; series-level `_sharing` change cascades to children via BFF

| Property           | Type     | Required | Notes                                                                      |
| ------------------ | -------- | -------- | -------------------------------------------------------------------------- |
| `name`             | string   | no       | inherited from series.name if not set                                      |
| `event_type`       | enum     | no       | inherited from series.event_type if not set                                |
| `start_datetime`   | datetime | yes      |                                                                            |
| `duration_minutes` | number   | no       | inherited from series.duration_minutes if not set                          |
| `location`         | string   | no       | inherited from series.default_location if not set                          |
| `description`      | text     | no       | inherited from series.default_description if not set                       |
| `capacity`         | number   | no       | optional venue / attendance cap; UI surfaces for RSVP collection vs. limit |

No `status` field — cancellation = delete. BFF series-regeneration must not blindly recreate deleted dates.

**Spec**: `2026-05-18-seasons-events-design.md`

#### `repertoire_item`

Junction: which works the org is engaged with this season.

**Parent**: `season` (single)

**`add_from`**: `season` type (Entu UI "Add" appears only when browsing a season)

**`_sharing`**: type `public`, instance `public` default

| Property  | Type             | Required | Notes                                                                                   |
| --------- | ---------------- | -------- | --------------------------------------------------------------------------------------- |
| `name`    | string (formula) | —        | `work.*.name CONCAT` — auto from work's name                                            |
| `work`    | ref → work       | yes      |                                                                                         |
| `edition` | ref → edition    | no       | preferred/pinned edition for this season                                                |
| `status`  | enum             | no       | `learning \| active \| retired \| dropped`; default `active`; admin/conductor maintains |

#### `program_item`

Junction: which works are performed at a specific event.

**Parent**: `event` (single)

**`add_from`**: `event` type

**`_sharing`**: matches parent event's `_sharing` (BFF cascade)

| Property  | Type             | Required | Notes                                                            |
| --------- | ---------------- | -------- | ---------------------------------------------------------------- |
| `name`    | string (formula) | —        | `edition.*.work CONCAT` — work name via edition's `work` formula |
| `edition` | ref → edition    | yes      | work is derivable as `edition._parent`                           |
| `ordinal` | number           | yes      | position in concert programme; admin-set                         |
| `notes`   | text             | no       | soloists, dedications                                            |

**Spec**: `2026-05-18-programs-design.md`

### 1.5 Participation

#### `rsvp`

Member's pre-event commitment. Lives under person so member can create natively.

**Parent**: `person`

**`add_from`**: `person` type

**`_sharing`**: `private` (person sees own; admins/conductors aggregate via BFF report)

| Property | Type         | Required | Notes                                                        |
| -------- | ------------ | -------- | ------------------------------------------------------------ |
| `event`  | ref → event  | yes      |                                                              |
| `member` | ref → member | yes      | per-org context (same person may be member of multiple orgs) |
| `status` | enum         | yes      | `going \| not_going \| maybe`                                |
| `notes`  | text         | no       |                                                              |

#### `attendance`

Conductor's post-event record.

**Parent**: `event`

**`add_from`**: `event` type

**`_sharing`**: `private` (org members see via cascade)

| Property | Type         | Required | Notes                          |
| -------- | ------------ | -------- | ------------------------------ |
| `member` | ref → member | yes      |                                |
| `status` | enum         | yes      | `present \| absent \| late`    |
| `notes`  | text         | no       | "left after intermission" etc. |

Excused absence derivable from rsvp+attendance combination — no separate flag.

**Spec**: `2026-05-18-participation-design.md`

---

## Section 2 — Relationships

### 2.1 Hierarchical tree (rights cascade flows down)

```
polyphony database root
  ├── voice (global taxonomy)
  ├── person (one per real human)
  │     ├── rsvp (each RSVP this person has made)
  │     └── application (each application this person has submitted)
  └── organization (each choir/federation; _inheritrights: false → rights island)
        ├── library
        │     ├── work
        │     │     ├── work (movements via part_of)
        │     │     └── edition
        │     │           └── copy
        │     └── lending
        ├── section (recursive — can have sub-sections)
        │     └── section
        ├── member (always child of org; ALSO multi-parent under section(s))
        ├── season
        │     └── repertoire_item
        ├── event_series
        ├── event (multi-parent: org + season + section(s) + event_series)
        │     ├── program_item
        │     └── attendance
        └── invitation
```

### 2.2 Reference table (entity.property → target type)

| Reference                        | Target         | Cardinality                                          |
| -------------------------------- | -------------- | ---------------------------------------------------- |
| `member.person`                  | `person`       | single, required                                     |
| `member.current_section`         | `section`      | single, optional                                     |
| `section.voice`                  | `voice`        | single, optional                                     |
| `person.voice[*]`                | `voice`        | list                                                 |
| `rsvp.event`                     | `event`        | single, required                                     |
| `rsvp.member`                    | `member`       | single, required                                     |
| `attendance.member`              | `member`       | single, required                                     |
| `repertoire_item.work`           | `work`         | single, required                                     |
| `repertoire_item.edition`        | `edition`      | single, optional                                     |
| `program_item.edition`           | `edition`      | single, required (work derived as `edition._parent`) |
| `lending.copy`                   | `copy`         | single, required                                     |
| `lending.member`                 | `member`       | single, required                                     |
| `work.part_of`                   | `work`         | single, optional (movements)                         |
| `invitation.sections[*]`         | `section`      | list, optional                                       |
| `application.target_org`         | `organization` | single, required                                     |
| `organization.public_contact[*]` | `member`       | list, optional                                       |

### 2.3 Multi-parent patterns

- **organization** — child of person (founder) AND optionally child of other orgs (umbrella/collective relationships); rights islands prevent cascade across this
- **member** — child of organization (always) AND child of each section the person sings in
- **section** — child of organization OR child of another section (recursive)
- **event** — child of organization + child of season(s) + child of section(s) + child of event_series (all optional except org)
- **event_series** — child of organization + child of season(s) + child of section(s)

---

## Section 3 — Rights matrix

**Single principle**: roles are rights grants on specific entities, not properties (per `2026-05-17-roles-as-rights-design.md`).

### 3.1 Role → rights mapping

| Role                        | Where the `_editor` / `_owner` grant lives                                    |
| --------------------------- | ----------------------------------------------------------------------------- |
| Member (basic)              | `member` entity exists; BFF writes `_viewer: <person>` on org (role→ACL sync) |
| Section-leader of section S | `_editor: <person>` on section S                                              |
| Librarian                   | `_editor: <person>` on org's `library` entity                                 |
| Conductor of season X       | `_editor: <person>` on season X                                               |
| Conductor of event series Y | `_editor: <person>` on `event_series` Y                                       |
| Guest conductor of event E  | `_editor: <person>` on event E                                                |
| Admin / Owner (merged)      | `_owner: <person>` on organization                                            |

### 3.2 What roles can do (cascades from rights tier)

`_owner` cascades to `_editor` / `_expander` / `_viewer` via Entu's tier mechanism, AND `_owner` itself cascades down via `_inheritrights` (verified — see case study Section A).

| Entity                | Member (viewer cascade)                                                      | Section-leader of S                         | Librarian | Conductor (scope)                         | Admin / Owner                                  |
| --------------------- | ---------------------------------------------------------------------------- | ------------------------------------------- | --------- | ----------------------------------------- | ---------------------------------------------- |
| organization          | read                                                                         | read                                        | read      | read                                      | full (incl. delete)                            |
| member                | read                                                                         | read                                        | read      | read                                      | create / edit / archive                        |
| section               | read                                                                         | edit (S + descendants)                      | read      | read                                      | create / edit / reparent                       |
| voice (global)        | read                                                                         | read                                        | read      | read                                      | (admin of polyphony DB only)                   |
| library               | read                                                                         | read                                        | full      | read                                      | full (cascade from org)                        |
| work / edition / copy | read                                                                         | read                                        | full      | read                                      | full (cascade from org)                        |
| lending               | read                                                                         | read                                        | full      | read                                      | full (cascade from org)                        |
| invitation            | (not visible until accepted)                                                 | —                                           | —         | —                                         | create / read / delete                         |
| application           | (own only — under own person)                                                | —                                           | —         | —                                         | read (via explicit BFF grant); accept / reject |
| season                | read                                                                         | read                                        | read      | full (if conductor of that season)        | full                                           |
| event_series          | read                                                                         | read                                        | read      | full (if conductor of that series)        | full                                           |
| event                 | read                                                                         | edit (if section parent of event matches S) | read      | full (if conductor scope contains event)  | full                                           |
| repertoire_item       | read                                                                         | read                                        | read      | full (if conductor of parent season)      | full                                           |
| program_item          | read                                                                         | read                                        | read      | full (if conductor of parent event scope) | full                                           |
| rsvp                  | own only                                                                     | own only                                    | own only  | own only                                  | own only (per-person)                          |
| attendance            | read                                                                         | edit (if section parent of event matches S) | read      | full (if conductor scope contains event)  | full                                           |
| person                | read public properties (everyone); read all properties (with explicit grant) | —                                           | —         | —                                         | —                                              |

### 3.3 Membership-rights invariant (BFF-enforced)

Any explicit `_owner` / `_editor` / `_viewer` grant on an entity under an organization MUST be paired with an active `member` entity for that person in that org. BFF blocks:

- Granting elevated rights to a non-member (prompts to invite first)
- Archiving a member who still holds explicit rights (prompts to clean up first)

See `2026-05-17-roles-as-rights-design.md`.

### 3.4 BFF user-rights principle

BFF acts in the authenticated user's rights by default. Elevated operations (cron cleanup, federation reports, cross-rights aggregations) are explicitly marked. Any frontend (polyphony app, Entu UI, custom client) can do everything the user is entitled to via rights — BFF has no magic capabilities beyond that. See `2026-05-18-bff-rights-pattern-design.md`.

---

## Section 4 — Sharing matrix

`_sharing` is independent of explicit rights. Two settings combine: entity type's `_sharing` (cap) and entity instance's `_sharing` (gate). Property defs can be marked `_sharing: public` to selectively project on otherwise-private contexts.

**`_sharing` does NOT inherit via `_inheritrights`** — each entity has its own setting. App-level cascade (BFF) handles intentional propagation (e.g., series → events).

| Entity                                    | Type `_sharing` | Instance default | Federation-anonymous-visible properties                                                                             |
| ----------------------------------------- | --------------- | ---------------- | ------------------------------------------------------------------------------------------------------------------- |
| organization                              | public          | public           | name, description, founded, location, website, logo, social_links, public_contact, member_count_per_section         |
| section                                   | public          | public           | name, voice, description, display_order, member_count                                                               |
| voice                                     | public          | public           | name, class, display_order, description                                                                             |
| season                                    | public          | public           | name, start_date, end_date, description                                                                             |
| event_series                              | public          | private          | (none by default; admin opts series public to surface its instances)                                                |
| event                                     | public          | private          | name, event_type, start_datetime, duration_minutes, location, description — only when instance is flipped to public |
| repertoire_item                           | public          | public           | name (= work name), work, edition                                                                                   |
| program_item                              | public          | matches event    | name, edition, ordinal, notes — when event is public                                                                |
| person                                    | public          | public           | name, voice, bio, avatar                                                                                            |
| member                                    | public          | private          | (none — roster is internal)                                                                                         |
| library / work / edition / copy / lending | private         | private          | n/a — librarian + admin only                                                                                        |
| invitation                                | private         | private          | n/a — token-gated URL access                                                                                        |
| application                               | private         | private          | n/a — own + explicit admin grant                                                                                    |
| rsvp / attendance                         | private         | private          | n/a — own + cascade                                                                                                 |

**Anonymous web user sees**: org public properties + section tree + season + repertoire + voice taxonomy + person public properties (across all orgs) + events that admin has explicitly flipped to `_sharing: public`.

**Per-instance opt-out**: org admin can flip `org._sharing` to `private` → entire org becomes invisible to anonymous; federation falls back to BFF reports. Per-person opt-out same.

**Per-property opt-out per instance is NOT supported by Entu** — per-value `_sharing` is stored but ignored at projection time (verified live). Whole-instance opt-out + schema-level property defaults are the only granularity.

---

## Section 5 — Common queries

UI's typical lookups. All readable; rights determine result-set.

### 5.1 Discovery

```
# List federation members (umbrella's direct child orgs)
GET /entity?_type.string=organization&_parent.reference=<umbrella-id>

# Federation directory — all public orgs
GET /entity?_type.string=organization&_sharing.string=public

# Find a person by OAuth email
GET /entity?_type.string=person&entu_user.email=<email>

# Find a person by name (public-only)
GET /entity?_type.string=person&name.string=<query>
```

### 5.2 Org structure

```
# All members of org X
GET /entity?_type.string=member&_parent.reference=<orgId>&status.string=active

# All members of section S
GET /entity?_type.string=member&_parent.reference=<sectionId>&status.string=active

# All sections of org X
GET /entity?_type.string=section&_parent.reference=<orgId>

# All sub-sections of section S (recursive — direct children only)
GET /entity?_type.string=section&_parent.reference=<sectionId>

# Org admins (people with explicit _owner on org)
GET /entity/<orgId> → filter _owner where inherited != true
```

### 5.3 Library + lending

```
# All works in org X's library
GET /entity?_type.string=work&_parent.reference=<libraryId>

# All editions of work W
GET /entity?_type.string=edition&_parent.reference=<workId>

# Active lendings (not yet returned)
GET /entity?_type.string=lending&_parent.reference=<libraryId>&returned_at._exists=false

# Lendings overdue
GET /entity?_type.string=lending&_parent.reference=<libraryId>&returned_at._exists=false&assigned_until.date.lt=<today>

# All lendings for member M (across orgs)
GET /entity?_type.string=lending&member.reference=<memberId>
```

### 5.4 Temporal

```
# Events in next N days for org X
GET /entity?_type.string=event&_parent.reference=<orgId>&start_datetime.datetime.gte=<now>&start_datetime.datetime.lte=<now+N>&sort=start_datetime

# Events in current season
GET /entity?_type.string=event&_parent.reference=<seasonId>

# Repertoire of season S
GET /entity?_type.string=repertoire_item&_parent.reference=<seasonId>

# Program of event E (ordered)
GET /entity?_type.string=program_item&_parent.reference=<eventId>&sort=ordinal
```

### 5.5 Participation

```
# All RSVPs by person P (across all orgs)
GET /entity?_type.string=rsvp&_parent.reference=<personId>

# RSVPs for event E (cross-person query — BFF aggregation typically needed)
GET /entity?_type.string=rsvp&event.reference=<eventId>

# Attendance for event E
GET /entity?_type.string=attendance&_parent.reference=<eventId>

# Member M's attendance history
GET /entity?_type.string=attendance&member.reference=<memberId>

# "Open to attend" — events in user's ongoing seasons that user has NOT yet RSVP'd
# Step 1: get user's active seasons (across all their orgs)
GET /entity?_type.string=season&_parent.reference=<orgId>&start_date.date.lte=<today>&end_date.date.gte=<today>
# Step 2: events under those seasons
GET /entity?_type.string=event&_parent.reference=<seasonId>&start_datetime.datetime.gte=<now>
# Step 3 (BFF aggregation): subtract events the user already has rsvp for
#   user's RSVPs → set of event ids → filter out from step 2 results
```

### 5.6 Onboarding

```
# Person's pending invitations (dashboard listing)
# Query invitations where invitation.email ∈ person.entu_user[*].email
# BFF aggregates this — direct API query example:
GET /entity?_type.string=invitation&email.string=<entu_user.email>&status.string=pending

# Org's pending applications
GET /entity?_type.string=application&target_org.reference=<orgId>&status.string=pending

# Org's pending invitations
GET /entity?_type.string=invitation&_parent.reference=<orgId>
```

---

## Section 6 — Lifecycle flows

### 6.1 Org creation (founder flow)

1. Person P initiates "create new choir"
2. BFF atomic operation:
   - Org entity created with `_parent = [P]`, `_inheritrights: false`
   - Entu's "creator gets `_owner`" rule fires → P becomes `_owner`
   - Member entity created in org: `person = P`, `_parent = [org]`
3. P's `_owner` tier cascade gives `_editor` / `_expander` / `_viewer` throughout — no separate `_viewer` sync needed
4. Org is ready; founder is admin + member

### 6.2 Member onboarding — Path A (org-initiated)

1. Admin creates `invitation` under org (email + optional preset sections + token + 30-day expiry)
2. Email sent: `https://polyphony.app/invite/<token>`
3. User clicks → Entu OAuth (finds existing person via `entu_user.uid` OR auto-creates new)
4. App resolves token → checks logged-in person's verified emails against `invitation.email` → soft warning if mismatch + explicit confirmation
5. If `person.preferred_contact_email` is unset → prompt; if `person.voice` is unset → prompt; saved on person
6. `member` created as child of org + `invitation.sections[*]` (multi-parent); person ref set
7. `invitation` deleted (consumed)
8. Admin natively writes `_viewer: <person>` on org via their `_owner` cascade (role→ACL sync; no elevation needed)

### 6.3 Member onboarding — Path B (person-initiated)

1. User OAuths in (creates orphan person if new); fills `person.voice` and profile
2. User browses public org directory; submits `application` under their person (target_org + optional message)
3. Admin sees application in pending list (via BFF `_viewer` grant)
4. Admin clicks accept → admin chooses initial section assignment(s) → `member` created + `application` deleted
5. Role→ACL sync as in Path A

### 6.4 Application rejection (rate limit)

1. Admin clicks reject on a pending application
2. BFF: `application.status = rejected`, `expires_at = now + 30 days`, `_inheritrights = false`, add explicit `_viewer: <person>`
3. Person sees rejection status but cannot delete the application (rate limit enforced via rights)
4. After 30 days: cron deletes the application
5. During the 30 days: person CANNOT submit a new application to the same org (BFF dup-prevention checks for existing application with same `person + target_org`)

### 6.5 Event series creation + generation

1. Admin creates `event_series` (interval_days, start_time, duration, start_date, end_date, default_location)
2. BFF generates `event` entities for `start_date` to `end_date` at `interval_days` intervals; each event is child of `[org, season(s), section(s), series]`
3. Per-event override: admin edits one event's location → that event stores the override; future series-default changes don't affect overridden properties
4. Series `_sharing` flip → BFF cascades to all child events
5. Series `end_date` extended → BFF generates additional events (idempotent — dedupes by `start_datetime`)
6. Series `end_date` shortened → BFF deletes future-only events past new end
7. Cancelled occurrence: admin deletes the specific event; BFF series-regeneration must NOT recreate it

### 6.6 Lending lifecycle

1. Librarian creates `lending` under library (refs copy + member; sets `assigned_at`, optional `assigned_until`)
2. BFF validates: `copy._parent` chain up to org matches `lending.member._parent` org (same-org constraint)
3. Member returns the copy: librarian sets `lending.returned_at`
4. Renewal: librarian appends to `lending.renewed_at` list + updates `assigned_until`
5. Lost copy: `copy.condition = lost`; lending stays as historical record

### 6.7 Member archive

1. Admin clicks "Archive member" on member M
2. BFF check (membership-rights invariant): does M's person have any explicit `_editor` / `_owner` grants on entities under this org?
   - Yes → block; prompt admin to revoke those grants first
   - No → proceed
3. BFF: `member.status = archived`; BFF removes `_viewer: <person>` from org (role→ACL sync reverse)
4. Member entity preserved for history; person no longer has read access to the org subtree

### 6.8 Org deletion

1. Admin clicks "Delete org" in UI
2. UI requires explicit confirmation (type the org's name)
3. BFF audit log entry
4. Admin uses their `_owner` rights to delete org entity; Entu's "can't delete last `_owner`" rule prevents accidental ownerless state at org level (but children may orphan — see case study E1 follow-up)
5. Backup/restore is the recovery path (standard ops concern; not in schema)
