// Shared helpers for collective landing page wireframes.
// Reuses all SketchyPrimitives; adds just what's collective-specific:
// section headings, an audition/voice-gap widget, a rehearsal row.

function CH2({ children, right }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', margin: '0 0 8px' }}>
      <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 14, margin: 0, color: 'var(--ink)' }}>{children}</h2>
      {right && <span style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--accent)' }} className="sk-underline">{right}</span>}
    </div>
  );
}

// Voice sections row with open-spot indicator
function VoiceSections({ data }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
      {data.map(([v, n, open], i) => (
        <div key={i} className={`sk-box ${open > 0 ? 'accent' : ''}`} style={{ padding: '7px 8px', textAlign: 'center', background: 'var(--paper)' }}>
          <div style={{ fontFamily: 'Inter', fontSize: 11, fontWeight: 600, color: 'var(--ink2)', letterSpacing: '0.05em' }}>{v}</div>
          <div style={{ fontFamily: 'Inter', fontSize: 22, fontWeight: 700, color: 'var(--ink)', letterSpacing: '-0.02em', lineHeight: 1 }}>{n}</div>
          <div style={{ fontFamily: 'Inter', fontSize: 9, color: open > 0 ? 'var(--accent)' : 'var(--ink4)', marginTop: 3 }}>
            {open > 0 ? `${open} open` : 'full'}
          </div>
        </div>
      ))}
    </div>
  );
}

// Rehearsal schedule row
function RehearsalRow({ day, time, venue, note }) {
  return (
    <div style={{ display: 'flex', gap: 10, padding: '5px 0', borderBottom: '1px dashed var(--ink5)', fontFamily: 'Inter', fontSize: 11, alignItems: 'center' }}>
      <span style={{ width: 64, fontWeight: 600, color: 'var(--ink)' }}>{day}</span>
      <span className="mono" style={{ color: 'var(--ink3)' }}>{time}</span>
      <span style={{ flex: 1, color: 'var(--ink2)' }}>{venue}</span>
      {note && <span style={{ color: 'var(--ink4)', fontStyle: 'italic' }}>{note}</span>}
    </div>
  );
}

// Umbrella parent badge — only rendered when collective belongs to one
function UmbrellaBadge({ name, slug }) {
  return (
    <a style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '3px 10px', border: '1px dashed var(--ink3)', borderRadius: 999, fontFamily: 'Inter', fontSize: 10, color: 'var(--ink2)', background: 'var(--paper)', textDecoration: 'none' }}>
      <span style={{ color: 'var(--ink4)' }}>part of</span>
      <span className="sk-underline" style={{ color: 'var(--accent)' }}>{name}</span>
      <span className="mono" style={{ color: 'var(--ink4)', fontSize: 9 }}>↗ /o/{slug}</span>
    </a>
  );
}

// Toggle showing independent vs. umbrella-member state
function ContextToggle({ mode }) {
  return (
    <div style={{
      position: 'absolute', top: 6, right: 8, zIndex: 5,
      fontFamily: 'Caveat', fontSize: 13, color: 'var(--red)',
      background: 'rgba(255,255,230,0.85)', padding: '2px 8px',
      border: '1px dashed var(--red)', borderRadius: 4, transform: 'rotate(-1deg)',
    }}>
      showing: {mode}
    </div>
  );
}

Object.assign(window, { CH2, VoiceSections, RehearsalRow, UmbrellaBadge, ContextToggle });
