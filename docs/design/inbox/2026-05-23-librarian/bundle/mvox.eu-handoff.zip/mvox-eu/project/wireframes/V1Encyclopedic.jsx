// V1 — Encyclopedic
// Wikipedia-esque single column, TOC left, infobox right.
// Most information-dense; editorial; content leads everything.

function V1Encyclopedic() {
  return (
    <BrowserFrame url="mvox.eu/o/eesti-segakooride-liit">
      <div className="sk" style={{ height: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <RegistryNav />
        <Breadcrumb trail={['Home', 'Directory', 'Eesti Segakooride Liit']} />

        {/* Title block — centered, editorial */}
        <div style={{ padding: '18px 48px 12px', borderBottom: '1.5px solid var(--ink5)' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 18 }}>
            <div className="sk-hatch" style={{
              width: 72, height: 72, borderRadius: 6,
              border: '1.5px solid var(--ink3)', flexShrink: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'Inter', fontSize: 9, color: 'var(--ink3)',
            }}>LOGO</div>
            <div style={{ flex: 1 }}>
              <Eyebrow>Umbrella Organisation · since 1962</Eyebrow>
              <div style={{
                fontFamily: 'Inter', fontWeight: 700, fontSize: 32,
                lineHeight: 1.1, color: 'var(--ink)', margin: '6px 0 4px',
                letterSpacing: '-0.02em',
              }}>
                Eesti Segakooride Liit
              </div>
              <div style={{ fontFamily: 'Inter', fontSize: 13, color: 'var(--ink3)', fontStyle: 'italic' }}>
                Estonian Association of Mixed Choirs · Tallinn, Estonia
              </div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <button className="sk-btn primary">Contact</button>
              <button className="sk-btn ghost">Share</button>
            </div>
          </div>
        </div>

        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '170px 1fr 260px', gap: 24, padding: '18px 48px', overflow: 'hidden', minHeight: 0 }}>

          {/* ── TOC ── */}
          <div style={{ fontFamily: 'Inter', fontSize: 12 }}>
            <Eyebrow style={{ marginBottom: 8 }}>Contents</Eyebrow>
            <ol style={{ listStyle: 'none', padding: 0, margin: 0, color: 'var(--ink3)', lineHeight: 2 }}>
              <li>1 <span className="sk-underline" style={{ color: 'var(--accent)' }}>About</span></li>
              <li>2 History</li>
              <li>3 Member choirs <span style={{ color: 'var(--ink4)' }}>(24)</span></li>
              <li>4 Voice sections</li>
              <li>5 Leadership</li>
              <li>6 Upcoming events</li>
              <li>7 Current season</li>
              <li>8 Contact &amp; links</li>
            </ol>
            <div style={{ marginTop: 18 }}>
              <Annot>long TOC ok — this is the "library" variant</Annot>
            </div>
          </div>

          {/* ── Main column ── */}
          <div style={{ overflow: 'hidden', minHeight: 0 }}>
            <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 18, margin: '0 0 6px', borderBottom: '1.5px solid var(--ink4)', paddingBottom: 4 }}>1 · About</h2>
            <Lines count={4} widths={['long', 'long', 'long', 'med']} />
            <p style={{ fontFamily: 'Caveat', color: 'var(--ink2)', fontSize: 15, margin: '8px 0' }}>
              <span className="sk-highlight">Lead paragraph:</span> short mission + what the umbrella actually does for its member choirs (shared rep, liaison with composers, copyright pooling).
            </p>

            <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 18, margin: '18px 0 6px', borderBottom: '1.5px solid var(--ink4)', paddingBottom: 4 }}>2 · History</h2>
            <Lines count={2} widths={['long', 'med']} />

            <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 18, margin: '18px 0 6px', borderBottom: '1.5px solid var(--ink4)', paddingBottom: 4 }}>3 · Member choirs (24)</h2>
            {/* compact alphabetical list — dense */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', columnGap: 22, rowGap: 3, fontFamily: 'Inter', fontSize: 12 }}>
              {[
                'Kammerkoor Crede', 'Tallinna Kammerkoor', 'Tartu Akadeemiline', 'RAM',
                'Collegium Musicale', 'Voces Musicales', 'Eesti Filh. Kammerkoor', 'Noorte Segakoor',
                'Chorus Gaudium', 'Sireen', 'Cantate', 'Modus',
              ].map((n, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px dashed var(--ink5)' }}>
                  <span style={{ color: 'var(--accent)' }} className="sk-underline">{n}</span>
                  <span style={{ color: 'var(--ink4)' }} className="mono">{(20 + i * 3)} m.</span>
                </div>
              ))}
            </div>
            <div style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)', marginTop: 8 }}>+ 12 more →</div>

            <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 18, margin: '18px 0 6px', borderBottom: '1.5px solid var(--ink4)', paddingBottom: 4 }}>4 · Voice sections <span style={{ color: 'var(--ink4)', fontWeight: 400 }}>(aggregated)</span></h2>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
              {[['S', 142], ['A', 118], ['T', 96], ['B', 104]].map(([v, n]) => (
                <Chip key={v} variant="filled">
                  <span style={{ fontWeight: 600 }}>{v}</span>
                  <span style={{ color: 'var(--ink3)' }}>·</span>
                  <span className="mono">{n}</span>
                </Chip>
              ))}
            </div>

            <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 18, margin: '18px 0 6px', borderBottom: '1.5px solid var(--ink4)', paddingBottom: 4 }}>5 · Leadership</h2>
            <Lines count={1} widths={['med']} />
            <Annot style={{ marginTop: 4 }}>↳ director names + photos, 3-across</Annot>
          </div>

          {/* ── Infobox right rail ── */}
          <div className="sk-box soft" style={{ padding: 14, fontFamily: 'Inter', fontSize: 12, alignSelf: 'start' }}>
            <div style={{ fontWeight: 600, fontSize: 14, textAlign: 'center', borderBottom: '1.5px solid var(--ink4)', paddingBottom: 6, marginBottom: 10 }}>
              Eesti Segakooride Liit
            </div>
            <div className="sk-hatch" style={{ height: 110, marginBottom: 10, border: '1.25px solid var(--ink4)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink3)', fontSize: 10 }}>
              group photo
            </div>
            {[
              ['Type', 'Umbrella'],
              ['Founded', '1962'],
              ['Seat', 'Tallinn'],
              ['Members', '24 choirs'],
              ['Singers', '~460'],
              ['Director', 'H. Kaljuste'],
              ['Website', 'esl.ee'],
              ['Email', 'info@esl.ee'],
            ].map(([k, v]) => (
              <div key={k} style={{ display: 'flex', padding: '4px 0', borderBottom: '1px dashed var(--ink5)' }}>
                <span style={{ width: 70, color: 'var(--ink3)', fontSize: 11 }}>{k}</span>
                <span style={{ flex: 1, color: 'var(--ink) ', fontWeight: 500 }}>{v}</span>
              </div>
            ))}
            <div style={{ marginTop: 10, display: 'flex', gap: 5, flexWrap: 'wrap' }}>
              <Chip>FB</Chip><Chip>IG</Chip><Chip>YT</Chip>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.V1Encyclopedic = V1Encyclopedic;
