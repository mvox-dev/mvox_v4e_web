// C2 — Conductor-led, spacious. Editorial, artist-forward.
// Artistic director + group portrait lead; audition CTA is a clear but calm section.

function C2ConductorLed({ withUmbrella = true }) {
  return (
    <BrowserFrame url="mvox.eu/o/kaaren-kammerkoor">
      <div className="sk" style={{ height: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column', position: 'relative' }}>
        <ContextToggle mode={withUmbrella ? 'umbrella member' : 'independent'} />
        <RegistryNav />

        {/* Full-bleed portrait hero */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1.2fr', borderBottom:'1.5px solid var(--ink4)' }}>
          <div className="sk-hatch" style={{ minHeight:260, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <div style={{ fontFamily:'Caveat', fontSize:15, color:'var(--ink3)', textAlign:'center' }}>
              conductor portrait<br/><span style={{ fontSize:11, color:'var(--ink4)' }}>editorial crop</span>
            </div>
          </div>
          <div style={{ padding:'30px 40px 24px' }}>
            <Eyebrow>Chamber choir · Tallinn · since 2014</Eyebrow>
            <div style={{ fontFamily:'Inter', fontWeight:800, fontSize:44, lineHeight:1, color:'var(--ink)', margin:'6px 0', letterSpacing:'-0.03em' }}>
              Kaaren<br/>Kammerkoor
            </div>
            {withUmbrella && <div style={{ marginTop:6 }}><UmbrellaBadge name="Eesti Segakooride Liit" slug="eesti-segakooride-liit" /></div>}
            <p style={{ fontFamily:'Inter', fontSize:13, color:'var(--ink2)', lineHeight:1.55, margin:'14px 0 0', maxWidth:420 }}>
              A 22-voice chamber choir working at the edges of Baltic sacred and contemporary repertoire.
            </p>
            <Lines count={2} widths={['long','med']} />
          </div>
        </div>

        <div style={{ flex:1, overflow:'hidden', padding:'22px 40px', display:'grid', gridTemplateColumns:'2fr 1fr', gap:32, minHeight:0 }}>
          <div>
            <CH2>Under the direction of</CH2>
            <div style={{ display:'flex', gap:16 }}>
              <div className="sk-hatch" style={{ width:110, height:140, borderRadius:4, border:'1px solid var(--ink4)', flexShrink:0 }} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontFamily:'Inter', fontSize:17, fontWeight:700, color:'var(--ink)' }}>Mari Tõnisson</div>
                <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginBottom:8 }}>Artistic director & conductor since 2018</div>
                <Lines count={4} widths={['long','long','long','med']} />
                <div style={{ fontFamily:'Caveat', fontSize:13, color:'var(--red)', marginTop:6 }}>→ 3–4 sentence bio, awards, studies</div>
              </div>
            </div>

            <CH2 right="full season →" >Now performing</CH2>
            <Lines count={2} widths={['long','med']} />
            <div style={{ marginTop:8, fontFamily:'Inter', fontSize:12, color:'var(--ink2)' }}>
              {['Duruflé · Requiem Op.9','Pärt · Da pacem Domine','Kreek · Taaveti laul','Sisask · Piirid (world premiere)'].map((w,i)=>(
                <div key={i} style={{ padding:'5px 0', borderBottom:'1px dashed var(--ink5)' }}>
                  <span style={{ color:'var(--accent)' }} className="sk-underline">{w}</span>
                </div>
              ))}
            </div>

            <CH2 right="listen all →" >Recordings & press</CH2>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              {[['Õhtupalve','Klassikaraadio, 2024'],['Gloria in D','live · Estonia kontserdisaal'],['Piirid — studio EP','Alba Records, 2023'],['ERR review 2024','★★★★☆']].map(([t,src],i)=>(
                <div key={i} className="sk-box" style={{ padding:'8px 10px', background:'var(--paper)' }}>
                  <div style={{ fontFamily:'Inter', fontSize:12, fontWeight:600 }}>{t}</div>
                  <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>{src}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <div className="sk-box" style={{ padding:12 }}>
              <Eyebrow>Next concert</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:14, fontWeight:700, color:'var(--ink)', marginTop:4 }}>Reekviem</div>
              <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>Sat 03 May · 19:00 · Kaarli kirik</div>
              <button className="sk-btn primary" style={{ marginTop:8, width:'100%', fontSize:12, justifyContent:'center' }}>Tickets →</button>
            </div>
            <div className="sk-box soft" style={{ padding:12 }}>
              <Eyebrow>Join the choir</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink2)', margin:'4px 0 8px' }}>3 voice spots open</div>
              <VoiceSections data={[['S',6,1],['A',5,0],['T',5,2],['B',6,0]]} />
              <button className="sk-btn ghost" style={{ marginTop:8, width:'100%', fontSize:11, justifyContent:'center' }}>Audition info →</button>
            </div>
            <div className="sk-box dashed" style={{ padding:12 }}>
              <Eyebrow style={{ marginBottom:6 }}>Rehearsals · public</Eyebrow>
              <RehearsalRow day="Mon" time="19:00–21:30" venue="EMTA R-207" />
              <RehearsalRow day="Thu" time="19:00–21:30" venue="EMTA R-207" />
            </div>
            <div className="sk-box" style={{ padding:12 }}>
              <Eyebrow style={{ marginBottom:6 }}>Awards</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink2)', lineHeight:1.55 }}>
                · Laulupidu 2024 · selected<br/>
                · Nordic Festival 2023 · silver<br/>
                · EMP 2022 · premiere commission
              </div>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.C2ConductorLed = C2ConductorLed;
