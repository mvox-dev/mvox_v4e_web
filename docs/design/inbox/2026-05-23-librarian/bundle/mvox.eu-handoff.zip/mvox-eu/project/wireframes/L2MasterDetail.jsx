// L2 — Master-detail split. List left, detail right.
// Shows the loan picker active + physical copy list populated.

function L2MasterDetail() {
  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor/library">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column' }}>
        <WorkspaceNav />
        <LibrarySubnav />
        <LibraryFilterBar />

        <div style={{ flex:1, overflow:'hidden', display:'grid', gridTemplateColumns:'380px 1fr' }}>
          {/* List */}
          <div style={{ borderRight:'1.5px solid var(--ink4)', overflow:'hidden', display:'flex', flexDirection:'column', background:'var(--paper)' }}>
            <div style={{
              padding:'8px 14px', background:'var(--paper2)', borderBottom:'1px solid var(--ink4)',
              fontFamily:'Inter', fontSize:9, fontWeight:600, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--ink4)',
              display:'flex', justifyContent:'space-between',
            }}>
              <span>8 works</span>
              <span>Sorted: composer ↑</span>
            </div>
            <div style={{ overflow:'hidden', flex:1 }}>
              {LIBRARY.map((w,i) => <WorkRow key={w.id} work={w} compact selected={i===0} />)}
            </div>
          </div>

          {/* Detail */}
          <div style={{ overflow:'hidden', display:'flex', flexDirection:'column', background:'var(--paper2)' }}>
            <div style={{
              padding:'12px 16px', background:'var(--paper)', borderBottom:'1.5px solid var(--ink4)',
              display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:12,
            }}>
              <div>
                <Eyebrow>Selected work</Eyebrow>
                <div style={{ fontFamily:'Inter', fontSize:18, fontWeight:700, color:'var(--ink)', marginTop:2, letterSpacing:'-0.01em' }}>
                  {LIBRARY[0].composer} — <em>{LIBRARY[0].title}</em>
                </div>
                <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginTop:2 }}>
                  <span className="mono">{LIBRARY[0].voicing}</span> · {LIBRARY[0].lang} · {LIBRARY[0].year}
                </div>
              </div>
              <div style={{ display:'flex', gap:6, flexShrink:0 }}>
                <button className="sk-btn ghost" style={{ fontSize:11 }}>Edit metadata</button>
                <button className="sk-btn ghost" style={{ fontSize:11, color:'var(--red)', borderColor:'var(--red)' }}>Delete</button>
              </div>
            </div>

            <div style={{ flex:1, overflow:'hidden' }}>
              <WorkDetail work={LIBRARY[0]} showLoanPicker={true} />
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.L2MasterDetail = L2MasterDetail;
