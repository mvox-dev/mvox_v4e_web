// Polished Proposal 2 — "Editorial timeline"
// Slightly more editorial flavor: agenda is a vertical date-rail timeline
// grouped by week; repertoire is grouped by programme with composer
// monograms and a small status meter. Same Manrope/blue tokens.

const P2_AGENDA = [
  { week:'This week · 28 Apr', items:[
    { id:2, day:1,  mon:'May', dow:'Thu', time:'19:00 – 21:30', title:'Duruflé focus',       type:'rehearsal', where:'EMTA R-207',           rsvp:'yes',   own:true },
    { id:3, day:2,  mon:'May', dow:'Fri', time:'18:00 – 20:00', title:'Dress rehearsal',     type:'rehearsal', where:'Kaarli kirik',         rsvp:'yes',   own:true },
    { id:4, day:3,  mon:'May', dow:'Sat', time:'19:00',         title:'Reekviem — Duruflé',  type:'concert',   where:'Kaarli kirik, Tallinn',rsvp:null,    own:true, headline:true },
  ]},
  { week:'12 May', items:[
    { id:7, day:12, mon:'May', dow:'Mon', time:'19:00 – 21:30', title:'Pärt + Kreek',        type:'rehearsal', where:'EMTA R-207',           rsvp:null,    own:true },
    { id:9, day:17, mon:'May', dow:'Sat', time:'14:00 – 18:00', title:'Käsmu retreat',       type:'retreat',   where:'Käsmu Creators\u2019 House', rsvp:null, own:false, viaLabel:'Rae Kammerkoor' },
    { id:8, day:24, mon:'May', dow:'Sat', time:'19:00',         title:'Kevadkontsert',       type:'concert',   where:'Mustpeade Maja',       rsvp:null,    own:true },
  ]},
];

const P2_PROGRAMMES = [
  {
    id:'reekviem', title:'Reekviem — Duruflé', when:'Sat 3 May · Kaarli kirik',
    progress: 0.85,
    works: [
      { abbr:'MD', composer:'Maurice Duruflé', work:'Requiem, Op. 9',   voicing:'SATB + org.', status:'active' },
      { abbr:'AP', composer:'Arvo Pärt',       work:'Da pacem Domine',  voicing:'SATB',        status:'active' },
      { abbr:'CK', composer:'Cyrillus Kreek',  work:'Taaveti laul 141', voicing:'SATB',        status:'active' },
    ],
  },
  {
    id:'spring', title:'Spring Gala', when:'Sat 24 May · Mustpeade Maja',
    progress: 0.40,
    works: [
      { abbr:'US', composer:'Urmas Sisask', work:'Piirid', voicing:'SATB div.', status:'learning' },
      { abbr:'EM', composer:'Ester Mägi',   work:'Laulud', voicing:'SSAA',      status:'learning' },
    ],
  },
  {
    id:'archive', title:'Recently retired', when:'Out of rotation',
    progress: 1,
    works: [
      { abbr:'VT', composer:'Veljo Tormis', work:'Raua needmine', voicing:'SATB · sham.', status:'retired' },
    ],
    muted:true,
  },
];

function P2WorkspaceTimeline() {
  return (
    <PPFrame url="kaaren-kammerkoor.multivox.eu/agenda">
      <div className="pp" style={{ display:'flex', flexDirection:'column', height:'100%', overflow:'hidden' }}>
        <PPTopbar active="agenda" />
        <PPSubnav active="agenda" />

        {/* Page header with summary stats */}
        <div style={{ padding:'16px 24px 14px', borderBottom:'1px solid var(--pp-gray-200)', flexShrink:0, background:'#fff' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
            <div>
              <div className="pp-eyebrow">Season 2024/25 · Piirid</div>
              <h1 className="pp-h1" style={{ marginTop:4, fontSize:20 }}>Your season</h1>
            </div>
            <div style={{ display:'flex', gap:8 }}>
              <button className="pp-btn pp-btn-secondary">Subscribe (.ics)</button>
              <button className="pp-btn pp-btn-primary">＋ New event</button>
            </div>
          </div>

          {/* Stat row */}
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:10 }}>
            <P2Stat label="Upcoming events" num="10" sub="next 8 weeks" />
            <P2Stat label="Awaiting RSVP" num="6" sub="3 this week" accent="amber" />
            <P2Stat label="Works in repertoire" num="6" sub="across 2 programmes" />
            <P2Stat label="Hours in May" num="14.5" sub="rehearsals + concerts" />
          </div>
        </div>

        {/* Two-column body */}
        <div style={{
          flex:1, overflow:'hidden', padding:'12px 24px 18px',
          display:'grid', gridTemplateColumns:'1fr 1fr', gap:18, minHeight:0,
        }}>
          {/* AGENDA — vertical timeline */}
          <section style={{ display:'flex', flexDirection:'column', minHeight:0, overflow:'hidden' }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
              <div>
                <div className="pp-eyebrow">Agenda</div>
                <div style={{ fontWeight:600, fontSize:15, marginTop:2 }}>Next 8 weeks</div>
              </div>
              <div style={{ fontSize:12, color:'var(--pp-gray-500)', display:'inline-flex', alignItems:'center', gap:6 }}>
                <span style={{ display:'inline-block', width:8, height:8, borderRadius:9999, background:'var(--pp-blue-600)' }} />
                Yours
                <span style={{ display:'inline-block', width:8, height:8, borderRadius:9999, background:'var(--pp-gray-300)', marginLeft:8 }} />
                From other choirs
              </div>
            </div>

            <div className="pp-scroll" style={{ flex:1, overflow:'auto', paddingRight:6 }}>
              {P2_AGENDA.map((wk, wi) => (
                <div key={wi} style={{ marginBottom:10 }}>
                  <div style={{ fontSize:10.5, fontWeight:600, color:'var(--pp-gray-500)', textTransform:'uppercase', letterSpacing:'.08em', marginBottom:5, paddingLeft:62 }}>
                    {wk.week}
                  </div>
                  {wk.items.map((ev, ei) => (
                    <P2TimelineRow key={ev.id} ev={ev} last={ei === wk.items.length - 1 && wi === P2_AGENDA.length - 1} />
                  ))}
                </div>
              ))}
            </div>
          </section>

          {/* REPERTOIRE — programme groups */}
          <section style={{ display:'flex', flexDirection:'column', minHeight:0, overflow:'hidden' }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:10 }}>
              <div>
                <div className="pp-eyebrow">Repertoire</div>
                <div style={{ fontWeight:600, fontSize:15, marginTop:2 }}>By programme</div>
              </div>
              <div style={{ fontSize:12, color:'var(--pp-blue-700)', cursor:'pointer' }}>
                Open library →
              </div>
            </div>

            <div className="pp-scroll" style={{ flex:1, overflow:'auto', display:'flex', flexDirection:'column', gap:14, paddingRight:4 }}>
              {P2_PROGRAMMES.map(p => <P2ProgrammeCard key={p.id} p={p} />)}
            </div>
          </section>
        </div>
      </div>
    </PPFrame>
  );
}

function P2Stat({ label, num, sub, accent }) {
  const accentColor = accent === 'amber' ? 'var(--pp-amber-600)' : 'var(--pp-gray-900)';
  return (
    <div className="pp-card" style={{ padding:'10px 14px' }}>
      <div style={{ fontSize:10.5, fontWeight:600, color:'var(--pp-gray-500)', textTransform:'uppercase', letterSpacing:'.08em' }}>{label}</div>
      <div style={{ display:'flex', alignItems:'baseline', gap:8, marginTop:3 }}>
        <span style={{ fontSize:24, fontWeight:700, letterSpacing:'-0.02em', color: accentColor, lineHeight:1 }}>{num}</span>
        <span style={{ fontSize:11.5, color:'var(--pp-gray-500)' }}>{sub}</span>
      </div>
    </div>
  );
}

function P2TimelineRow({ ev, last }) {
  const isOwn = ev.own;
  const dotColor = isOwn
    ? (ev.type === 'concert' ? 'var(--pp-purple-600)' : 'var(--pp-blue-600)')
    : 'var(--pp-gray-300)';
  return (
    <div style={{ display:'flex', gap:12, position:'relative', minHeight:52 }}>
      {/* Date column */}
      <div style={{ width:48, flexShrink:0, textAlign:'right', paddingTop:7 }}>
        <div style={{ fontSize:9.5, fontWeight:600, color:'var(--pp-gray-500)', textTransform:'uppercase', letterSpacing:'.08em' }}>{ev.mon}</div>
        <div style={{ fontSize:17, fontWeight:700, lineHeight:1.05, color: isOwn ? 'var(--pp-gray-900)' : 'var(--pp-gray-500)', letterSpacing:'-0.02em' }}>{ev.day}</div>
        <div style={{ fontSize:9.5, color:'var(--pp-gray-400)' }}>{ev.dow}</div>
      </div>

      {/* Rail + dot */}
      <div style={{ width:12, flexShrink:0, position:'relative', display:'flex', justifyContent:'center' }}>
        <div style={{ width:1.5, background:'var(--pp-gray-200)', position:'absolute', top:0, bottom: last ? 'auto' : 0, height: last ? 14 : 'auto' }} />
        <div style={{
          width:9, height:9, borderRadius:9999,
          background: dotColor, marginTop:11, position:'relative',
          boxShadow:'0 0 0 3px #fff',
          border: isOwn ? 'none' : '1.5px dashed var(--pp-gray-400)',
          backgroundClip:'padding-box',
        }} />
      </div>

      {/* Card */}
      <div style={{
        flex:1, marginBottom:7, padding:'8px 12px',
        border:'1px solid ' + (ev.headline ? 'var(--pp-purple-200)' : (isOwn && !ev.rsvp ? '#fde68a' : 'var(--pp-gray-200)')),
        borderLeft: !isOwn ? '3px solid var(--pp-gray-300)' : (isOwn && !ev.rsvp ? '3px solid var(--pp-amber-500)' : null),
        borderRadius:8, background: isOwn ? '#fff' : 'var(--pp-gray-50)',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:3, flexWrap:'wrap' }}>
          <span className={`pp-chip pp-chip-${ev.type}`} style={!isOwn ? { opacity:0.85 } : undefined}>{ev.type}</span>
          {!isOwn && (
            <span style={{ display:'inline-flex', alignItems:'center', gap:4, fontSize:11, color:'var(--pp-gray-500)' }}>
              <svg width="11" height="11" fill="none" stroke="currentColor" strokeWidth="1.7" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244"/></svg>
              Hosted by <span style={{ color:'var(--pp-blue-700)', fontWeight:500 }}>{ev.viaLabel}</span>
            </span>
          )}
          {ev.headline && <span className="pp-pill" style={{ background:'#faf5ff', color:'var(--pp-purple-800)' }}>★ Headline</span>}
          <span style={{ flex:1 }} />
          {isOwn ? <P2RsvpDot state={ev.rsvp} /> : <P2OpenToAttend />}
        </div>
        <div style={{ fontWeight:600, fontSize:13, color: isOwn ? 'var(--pp-gray-900)' : 'var(--pp-gray-700)', lineHeight:1.3 }}>{ev.title}</div>
        <div style={{ fontSize:11.5, color:'var(--pp-gray-500)', marginTop:2, display:'flex', gap:8, alignItems:'center' }}>
          <span className="mono" style={{ fontSize:10.5 }}>{ev.time}</span>
          <span>·</span>
          <span>{ev.where}</span>
          {!isOwn && (
            <>
              <span style={{ color:'var(--pp-gray-300)' }}>·</span>
              <span style={{ color:'var(--pp-gray-500)' }}>4 from KK going</span>
              <span style={{ flex:1 }} />
              <a style={{ color:'var(--pp-blue-700)', fontWeight:500, fontSize:11.5, cursor:'pointer' }}>Details →</a>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function P2OpenToAttend() {
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', gap:5, fontSize:11,
      padding:'2px 8px', borderRadius:9999,
      background:'var(--pp-blue-50)', color:'var(--pp-blue-700)',
      border:'1px solid var(--pp-blue-200)', fontWeight:500,
    }}>
      <span style={{ width:6, height:6, borderRadius:9999, background:'var(--pp-blue-600)' }} />
      Open to attend
    </span>
  );
}

function P2RsvpDot({ state }) {
  if (!state) {
    return (
      <div style={{ display:'inline-flex', alignItems:'center', gap:6 }}>
        <span style={{ fontSize:11, color:'var(--pp-amber-700, #b45309)', fontWeight:500 }}>RSVP</span>
        <div style={{ display:'inline-flex', border:'1px solid var(--pp-gray-300)', borderRadius:6, overflow:'hidden', background:'#fff' }}>
          <button style={{ padding:'3px 9px', fontSize:11, fontWeight:500, border:'none', background:'transparent', color:'var(--pp-gray-700)', cursor:'pointer', fontFamily:'inherit', borderRight:'1px solid var(--pp-gray-200)' }}>Yes</button>
          <button style={{ padding:'3px 9px', fontSize:11, fontWeight:500, border:'none', background:'transparent', color:'var(--pp-gray-700)', cursor:'pointer', fontFamily:'inherit', borderRight:'1px solid var(--pp-gray-200)' }}>Maybe</button>
          <button style={{ padding:'3px 9px', fontSize:11, fontWeight:500, border:'none', background:'transparent', color:'var(--pp-gray-700)', cursor:'pointer', fontFamily:'inherit' }}>No</button>
        </div>
      </div>
    );
  }
  const map = {
    yes:   { color:'var(--pp-green-600)',   label:'Yes' },
    no:    { color:'var(--pp-red-600)',     label:'No' },
    maybe: { color:'var(--pp-yellow-600)',  label:'Maybe' },
    late:  { color:'var(--pp-orange-600)',  label:'Late' },
  };
  const m = map[state];
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:11.5, color:'var(--pp-gray-700)' }}>
      <span style={{ width:8, height:8, borderRadius:9999, background:m.color }} />
      {m.label}
    </span>
  );
}

function P2ProgrammeCard({ p }) {
  return (
    <div className="pp-card" style={{ overflow:'hidden', opacity: p.muted ? 0.75 : 1 }}>
      {/* Header */}
      <div style={{
        padding:'12px 14px', borderBottom:'1px solid var(--pp-gray-100)',
        background:'var(--pp-gray-50)',
      }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:10 }}>
          <div style={{ minWidth:0 }}>
            <div style={{ fontWeight:700, fontSize:14, letterSpacing:'-0.005em', color:'var(--pp-gray-900)' }}>
              {p.title}
            </div>
            <div style={{ fontSize:11.5, color:'var(--pp-gray-500)', marginTop:2 }}>
              {p.when} · {p.works.length} works
            </div>
          </div>
          {!p.muted && (
            <div style={{ width:90, flexShrink:0 }}>
              <div style={{ fontSize:10, color:'var(--pp-gray-500)', textAlign:'right', fontWeight:500, letterSpacing:'.04em' }}>
                {Math.round(p.progress * 100)}% ready
              </div>
              <div style={{ height:5, background:'var(--pp-gray-200)', borderRadius:9999, marginTop:4, overflow:'hidden' }}>
                <div style={{ height:'100%', width: (p.progress*100)+'%', background: p.progress > 0.7 ? 'var(--pp-green-600)' : 'var(--pp-amber-500)', borderRadius:9999 }} />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Works */}
      <div>
        {p.works.map((w, i) => <P2WorkRow key={i} w={w} />)}
      </div>
    </div>
  );
}

function P2WorkRow({ w }) {
  const statusClass = {
    active: 'pp-badge-active',
    learning: 'pp-badge-learning',
    retired: 'pp-badge-retired',
  }[w.status];
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:12, padding:'10px 14px',
      borderTop:'1px solid var(--pp-gray-100)',
    }}>
      {/* Composer monogram */}
      <div style={{
        width:36, height:44, flexShrink:0, borderRadius:4,
        background:'#fff', border:'1px solid var(--pp-gray-200)',
        display:'grid', placeItems:'center',
        fontFamily:'Georgia, serif', fontWeight:700, fontSize:13, color:'var(--pp-gray-500)',
        position:'relative',
        backgroundImage:'repeating-linear-gradient(0deg, var(--pp-gray-100) 0 1px, transparent 1px 4px)',
      }}>
        <span style={{ background:'#fff', padding:'2px 4px', borderRadius:2 }}>{w.abbr}</span>
      </div>

      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ display:'flex', alignItems:'baseline', gap:8, flexWrap:'wrap' }}>
          <span style={{ fontWeight:600, fontSize:13, color:'var(--pp-gray-900)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{w.work}</span>
        </div>
        <div style={{ fontSize:11.5, color:'var(--pp-gray-500)', marginTop:2 }}>
          {w.composer} · <span className="mono" style={{ fontSize:11 }}>{w.voicing}</span>
        </div>
      </div>

      <div style={{ flexShrink:0, display:'flex', alignItems:'center', gap:8 }}>
        <span className={`pp-chip ${statusClass}`} style={{ textTransform:'capitalize' }}>{w.status}</span>
        <button className="pp-btn pp-btn-ghost pp-btn-sm" style={{ padding:'4px 6px' }} title="Open">
          <svg width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5"/></svg>
        </button>
      </div>
    </div>
  );
}

window.P2WorkspaceTimeline = P2WorkspaceTimeline;
