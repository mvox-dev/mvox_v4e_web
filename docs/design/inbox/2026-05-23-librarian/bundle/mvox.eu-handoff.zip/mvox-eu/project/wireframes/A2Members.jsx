// A2 · Two-tab settings · MEMBERS & ROLES tab active
// Admin workbench. Hierarchy of attention:
//   1. Pending requests (only when present) — work to do
//   2. Members directory — steady state
//   3. Audit log — right rail, ambient
//
// Role assignments shown here are the THREE COLLECTIVE-LEVEL roles
// (Admin, Conductor, Librarian). Section-leader assignments live on
// the Sections tab — we mention this and link there.

function A2Members() {
  const collectiveRoles = ROLES.filter(r => r.scope === 'collective');
  return (
    <div style={{
      height:'100%', background:'var(--paper2)',
      display:'flex', flexDirection:'column', overflow:'hidden',
    }}>
      <WorkspaceNav />
      <SettingsNav active="members" />
      <SettingsSubnav />

      <PanelHeader
        eyebrow="Members & Admin roles"
        title="Who's in the choir, and what they can do"
        count={
          <RoleHeaderCounters roles={collectiveRoles} />
        }
        desc={
          <>
            Approve newcomers and assign the three collective roles.
            {' '}
            <span className="sk-underline" style={{ color:'var(--ink2)' }}>
              Section leaders → Sections tab
            </span>.
          </>
        }
        actions={
          <>
            <button className="sk-btn ghost" style={{ fontSize:11 }}>Import CSV</button>
            <button className="sk-btn ghost" style={{ fontSize:11 }}>Export</button>
            <button className="sk-btn" style={{ fontSize:11 }}>+ Invite</button>
          </>
        }
      />

      <div style={{
        flex:1, display:'grid', gridTemplateColumns:'1fr 320px',
        gap:0, overflow:'hidden',
      }}>
        <div style={{ overflow:'auto' }}>
          <PendingStrip />
          <MembersList />
        </div>
        <AuditPanel />
      </div>
    </div>
  );
}

// ─── Counters in the header (replaces the grid of cards) ─────────────
function RoleHeaderCounters({ roles }) {
  return (
    <span style={{ display:'inline-flex', alignItems:'baseline', gap:10 }}>
      <span>{MEMBERS.length} active</span>
      <span style={{ color:'var(--ink5)' }}>·</span>
      {roles.map((r, i) => (
        <span key={r.id} style={{ display:'inline-flex', alignItems:'baseline', gap:4 }}>
          <span style={{
            width:8, height:8, background:r.color, borderRadius:2, display:'inline-block',
            transform:'translateY(-1px)',
          }} />
          <span className="mono" style={{ fontSize:12, color:'var(--ink2)', fontWeight:600 }}>
            {memberCountByRole(r.id)}
          </span>
          <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', textTransform:'lowercase' }}>
            {r.label.toLowerCase()}
          </span>
          {i < roles.length - 1 && <span style={{ color:'var(--ink5)', marginLeft:4 }}>·</span>}
        </span>
      ))}
    </span>
  );
}

// ─── Pending join requests ──────────────────────────────────────────
// Library-card visual language: rows with dashed separators, accent strip
// on the left to mark "needs attention". No boxy shadowed card.
function PendingStrip() {
  return (
    <div style={{
      borderBottom:'1.5px solid var(--ink4)',
      background:'var(--paper)',
    }}>
      <div style={{
        padding:'10px 24px', display:'flex', alignItems:'center', gap:10,
        borderBottom:'1px dashed var(--ink5)',
        borderLeft:'3px solid var(--accent)',
        background:'var(--accent-soft)',
      }}>
        <span style={{
          fontFamily:'Inter', fontSize:10, fontWeight:700, letterSpacing:'0.08em',
          textTransform:'uppercase', color:'#fff', background:'var(--accent)',
          padding:'2px 7px', borderRadius:3,
        }}>Pending · {PENDING.length}</span>
        <span style={{ fontFamily:'Inter', fontSize:12.5, fontWeight:600 }}>Join requests</span>
        <span style={{ flex:1 }} />
        <span className="sk-underline" style={{ fontSize:11, color:'var(--ink3)' }}>
          Auto-approve settings…
        </span>
      </div>
      {PENDING.map((p, i) => (
        <div key={p.id} style={{
          padding:'9px 24px 9px 27px',
          borderBottom: i === PENDING.length - 1 ? 'none' : '1px dotted var(--ink5)',
          display:'flex', alignItems:'center', gap:12,
          background:'var(--paper)',
        }}>
          <div className="sk-icon" style={{
            width:28, height:28, borderRadius:999,
            background:'var(--paper2)', fontSize:10,
          }}>{p.name.split(' ').map(w => w[0]).slice(0,2).join('')}</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ display:'flex', alignItems:'baseline', gap:8, flexWrap:'wrap' }}>
              <span style={{ fontFamily:'Inter', fontSize:12.5, fontWeight:600 }}>{p.name}</span>
              <span className="mono" style={{ fontSize:10, color:'var(--ink4)' }}>{p.email}</span>
              <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)' }}>· requested {p.when}</span>
              <span style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink3)' }}>
                · wants <strong style={{ color:'var(--ink2)' }}>{p.voicePref}</strong>
              </span>
            </div>
            {p.note && (
              <div style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink4)', marginTop:1, fontStyle:'italic' }}>
                “{p.note}”
              </div>
            )}
          </div>
          <div style={{ display:'flex', gap:4 }}>
            <button className="sk-btn ghost" style={{ fontSize:10, padding:'3px 7px', color:'var(--red)' }}>Decline</button>
            <button className="sk-btn" style={{ fontSize:10, padding:'3px 9px', background:'#2f7a4f', color:'#fff', borderColor:'#2f7a4f', boxShadow:'2px 2px 0 0 var(--ink3)' }}>
              Approve →
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Members directory ──────────────────────────────────────────────
// Library-row visual language: dashed separators, no box-shadowed wrapper.
// Filters live in a slim toolbar above the list.
function MembersList() {
  const rows = MEMBERS.filter(m => [1,2,3,5,6,7,9,12,13,16].includes(m.id));
  return (
    <div>
      {/* Toolbar */}
      <div style={{
        display:'flex', alignItems:'center', gap:10,
        padding:'8px 24px',
        borderBottom:'1.5px solid var(--ink4)',
        background:'var(--paper2)',
      }}>
        <span style={{ fontFamily:'Inter', fontSize:13, fontWeight:700 }}>All members</span>
        <span style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink4)' }}>
          {MEMBERS.length} active · click a row to manage
        </span>
        <span style={{ flex:1 }} />
        <div className="sk-input" style={{
          padding:'3px 8px', fontSize:11, display:'inline-flex', alignItems:'center', gap:6,
          background:'var(--paper)', minWidth:200,
        }}>
          <span style={{ color:'var(--ink4)' }}>⌕</span>
          <span style={{ color:'var(--ink4)' }}>filter members…</span>
        </div>
        <span className="sk-underline" style={{ fontSize:10.5, color:'var(--ink3)' }}>+ filter</span>
      </div>

      {/* Header row */}
      <div style={{
        display:'grid',
        gridTemplateColumns:'2.4fr 1.6fr 0.4fr',
        padding:'7px 24px',
        borderBottom:'1px solid var(--ink4)',
        fontFamily:'Inter', fontSize:9.5, fontWeight:700, letterSpacing:'0.08em',
        textTransform:'uppercase', color:'var(--ink4)',
        background:'var(--paper)',
      }}>
        <span>Name / email</span>
        <span>Roles</span>
        <span style={{ textAlign:'right' }} />
      </div>

      {/* Rows — list, no enclosing card */}
      <div style={{ background:'var(--paper)' }}>
        {rows.map((m, i) => {
          const sec = SECTION_BY_ID[m.section];
          const collective = (MEMBER_ROLES[m.id] || []);
          const isYou = m.id === 3;
          // Build a SECTION_NODES-style descriptor for this member's section/sub.
          // Top-level node always exists; if member has .sub, prefer the sub node.
          const subNode = m.sub
            ? (window.SECTION_NODES || []).find(n => n.parentSection === m.section && n.code === m.sub)
            : null;
          const sectionTag = subNode || (window.NODE_BY_ID && window.NODE_BY_ID[m.section]) || null;
          return (
            <div key={m.id} style={{
              display:'grid',
              gridTemplateColumns:'2.4fr 1.6fr 0.4fr',
              padding:'8px 24px',
              borderBottom:'1px dashed var(--ink5)',
              fontFamily:'Inter', fontSize:12, alignItems:'center',
              background: isYou ? 'var(--accent-soft)' : 'transparent',
              borderLeft: isYou ? '3px solid var(--accent)' : '3px solid transparent',
              marginLeft: isYou ? -3 : 0,
              cursor:'pointer',
            }}>
              <div style={{ display:'flex', alignItems:'center', gap:10, minWidth:0 }}>
                <div className="sk-icon" style={{ width:26, height:26, fontSize:10, borderRadius:999 }}>
                  {m.name.split(' ').map(w => w[0]).slice(0,2).join('')}
                </div>
                <div style={{ minWidth:0, flex:1 }}>
                  <div style={{ fontWeight:600, display:'flex', gap:6, alignItems:'center', flexWrap:'wrap' }}>
                    <span>{m.name}</span>
                    {isYou && <span className="mono" style={{ fontSize:9, color:'var(--accent)', fontWeight:600 }}>you</span>}
                    {sectionTag && window.SectionTag && <window.SectionTag node={sectionTag} size="sm" />}
                  </div>
                  <div className="mono" style={{ fontSize:9.5, color:'var(--ink4)' }}>{m.email}</div>
                </div>
              </div>
              <div style={{ display:'flex', gap:4, flexWrap:'wrap', alignItems:'center' }}>
                {collective.length === 0 && !m.sectionLeader && (
                  <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)', fontStyle:'italic' }}>
                    member
                  </span>
                )}
                {collective.map(r => <AdminRoleChip key={r} role={r} size="sm" />)}
                {m.sectionLeader && (
                  <span title="Section leader — managed on Sections tab" style={{
                    fontFamily:'Inter', fontSize:9, fontWeight:700, letterSpacing:'0.08em',
                    textTransform:'uppercase', padding:'1px 5px', borderRadius:3,
                    color:'#6a5a8a', border:'1px dashed #6a5a8a', background:'transparent',
                  }}>section lead</span>
                )}
                <span className="sk-underline" style={{ fontSize:10, color:'var(--ink4)', alignSelf:'center', marginLeft:2 }}>+</span>
              </div>
              <div style={{ textAlign:'right', color:'var(--ink4)' }}>⋯</div>
            </div>
          );
        })}
      </div>

      {/* Footer summary — list links not boxed */}
      <div style={{
        padding:'10px 24px', display:'flex', gap:14, alignItems:'center',
        fontFamily:'Inter', fontSize:11, color:'var(--ink3)',
        borderBottom:'1px dashed var(--ink5)', background:'var(--paper)',
      }}>
        <span className="sk-underline">Show all {MEMBERS.length} active</span>
        <span style={{ color:'var(--ink5)' }}>·</span>
        <span className="sk-underline">2 invited (pending accept)</span>
        <span style={{ color:'var(--ink5)' }}>·</span>
        <span className="sk-underline">4 archived / alumni</span>
      </div>
    </div>
  );
}

// ─── Audit log (right rail) ─────────────────────────────────────────
function AuditPanel() {
  const kindColor = {
    approve:'#2f7a4f', move:'#3a6a8a', invite:'var(--accent)',
    role:'#6a5a8a', archive:'var(--ink4)', section:'#8a6a2e',
  };
  return (
    <div style={{
      borderLeft:'1.5px solid var(--ink4)',
      background:'var(--paper)',
      overflow:'auto',
      display:'flex', flexDirection:'column',
    }}>
      <div style={{
        padding:'12px 18px',
        borderBottom:'1px dashed var(--ink5)',
      }}>
        <Eyebrow>Audit log</Eyebrow>
        <div style={{ fontFamily:'Inter', fontSize:13, fontWeight:700, marginTop:4 }}>
          Recent admin actions
        </div>
        <div style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink4)', marginTop:2 }}>
          Last 90 days. All role and section changes are recorded.
        </div>
      </div>

      <div style={{ flex:1 }}>
        {AUDIT.map((a, i) => (
          <div key={i} style={{
            padding:'8px 18px',
            borderBottom: i === AUDIT.length - 1 ? 'none' : '1px dotted var(--ink5)',
          }}>
            <div style={{ display:'flex', alignItems:'baseline', gap:6 }}>
              <span style={{
                width:6, height:6, background:kindColor[a.kind], borderRadius:999,
              }} />
              <span style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink4)' }}>
                {a.when}
              </span>
            </div>
            <div style={{ fontFamily:'Inter', fontSize:11.5, color:'var(--ink2)', marginTop:2, lineHeight:1.4 }}>
              <strong>{a.who}</strong> {a.what} <span style={{ color:'var(--ink3)' }}>{a.target}</span>
            </div>
          </div>
        ))}
      </div>

      <div style={{
        padding:'10px 18px',
        borderTop:'1px dashed var(--ink5)',
        fontFamily:'Inter', fontSize:10.5,
        background:'var(--paper2)',
      }}>
        <span className="sk-underline" style={{ color:'var(--ink3)' }}>View full audit log →</span>
      </div>
    </div>
  );
}

Object.assign(window, { A2Members });
