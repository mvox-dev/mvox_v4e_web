// Schema primitives — entity cards + arrows for the v4E diagrams.
// Lives on the same warm paper canvas as the wireframes.
// Visual: clean Inter inside structured cards, sketchy ink borders outside,
// indigo accent for parent edges, muted dashed strokes for references,
// Caveat for in-margin annotations.

// ─── One-time CSS injection ──────────────────────────────────────────
if (typeof document !== 'undefined' && !document.getElementById('schema-styles')) {
  const s = document.createElement('style');
  s.id = 'schema-styles';
  s.textContent = `
    .se-card {
      position: absolute;
      background: var(--paper);
      border: 1.5px solid var(--ink);
      border-radius: 4px;
      box-shadow: 2.5px 2.5px 0 0 rgba(0,0,0,.08);
      font-family: 'Inter', system-ui, sans-serif;
      font-size: 11px;
      color: var(--ink);
      overflow: hidden;
    }
    .se-card.island {
      border-width: 1.5px;
      box-shadow:
        2.5px 2.5px 0 0 rgba(0,0,0,.08),
        inset 0 0 0 3px var(--paper),
        inset 0 0 0 4.5px var(--ink);
    }
    .se-card.accent { border-color: var(--accent); }
    .se-card.dashed { border-style: dashed; border-color: var(--ink3); }

    .se-head {
      display: flex; align-items: center; gap: 6px;
      padding: 6px 9px 5px;
      border-bottom: 1px solid var(--ink5);
      background: var(--paper2);
    }
    .se-head .se-name {
      font-family: 'JetBrains Mono', ui-monospace, monospace;
      font-size: 12px; font-weight: 600;
      color: var(--ink);
      letter-spacing: -0.01em;
      flex: 1; min-width: 0;
    }
    .se-head .se-badge {
      font-family: 'Inter', system-ui, sans-serif;
      font-size: 8.5px; font-weight: 600;
      letter-spacing: 0.08em; text-transform: uppercase;
      padding: 1.5px 5px;
      border-radius: 2px;
      border: 1px solid;
      flex-shrink: 0;
      line-height: 1.1;
    }
    .se-badge.public  { color: #2f7a4f; border-color: #2f7a4f; background: #f0f7f2; }
    .se-badge.private { color: var(--ink3); border-color: var(--ink4); background: var(--paper2); }
    .se-badge.island  { color: var(--red); border-color: var(--red); background: #fef0ed; }
    .se-badge.global  { color: var(--accent); border-color: var(--accent); background: var(--accent-soft); }
    .se-badge.recursive { color: #8a6a2e; border-color: #b8861a; background: #fff2d9; }

    .se-blurb {
      padding: 5px 9px 6px;
      font-size: 10px;
      color: var(--ink3);
      line-height: 1.35;
      font-style: italic;
      border-bottom: 1px dashed var(--ink5);
    }

    .se-props {
      padding: 4px 0 5px;
    }
    .se-prop {
      display: flex; align-items: baseline; gap: 6px;
      padding: 1.5px 9px;
      font-size: 10.5px; line-height: 1.4;
    }
    .se-prop .se-pname {
      font-weight: 500;
      color: var(--ink);
      white-space: nowrap;
    }
    .se-prop .se-ptype {
      font-family: 'JetBrains Mono', ui-monospace, monospace;
      font-size: 9.5px;
      color: var(--ink3);
      flex: 1; min-width: 0;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .se-prop .se-req {
      color: var(--red);
      font-weight: 700;
      font-size: 11px;
      flex-shrink: 0;
    }
    .se-prop.formula .se-pname { color: var(--accent); font-style: italic; }
    .se-prop.formula .se-pname::after { content: ' ƒ'; opacity: 0.7; font-size: 9px; }
    .se-prop.ref .se-pname { color: var(--ink); }
    .se-prop.ref .se-ptype::before { content: '→ '; color: var(--accent); }
    .se-prop.list .se-pname::after { content: '[*]'; font-family: 'JetBrains Mono', monospace; color: var(--ink4); font-weight: 400; font-size: 9px; }

    .se-foot {
      padding: 5px 9px 6px;
      border-top: 1px dashed var(--ink5);
      background: var(--paper2);
      font-size: 9.5px;
      color: var(--ink2);
      line-height: 1.35;
    }
    .se-foot .se-parent {
      font-family: 'JetBrains Mono', monospace;
      color: var(--ink2);
    }
    .se-foot .se-parent::before { content: 'parent: '; color: var(--ink4); font-family: inherit; }

    /* Section header — eyebrow + index + title + intro */
    .se-section-head {
      padding: 14px 24px 12px;
      border-bottom: 1.5px solid var(--ink4);
      background: var(--paper);
      display: flex; align-items: flex-start; gap: 14px;
    }
    .se-section-index {
      font-family: 'Caveat', cursive;
      font-size: 32px;
      color: var(--accent);
      line-height: 0.9;
      font-weight: 600;
      flex-shrink: 0;
      width: 56px;
      text-align: center;
      border-bottom: 2px solid var(--accent);
      padding-bottom: 2px;
    }
    .se-section-title-wrap {
      flex: 1; min-width: 0;
    }
    .se-section-title {
      font-family: 'Inter', system-ui, sans-serif;
      font-size: 18px; font-weight: 700;
      letter-spacing: -0.01em;
      color: var(--ink);
      margin-bottom: 3px;
    }
    .se-section-intro {
      font-family: 'Inter', system-ui, sans-serif;
      font-size: 11.5px;
      color: var(--ink3);
      line-height: 1.4;
      max-width: 760px;
    }
    .se-section-meta {
      font-family: 'JetBrains Mono', monospace;
      font-size: 9px;
      color: var(--ink4);
      letter-spacing: 0.04em;
      text-transform: uppercase;
      margin-top: 3px;
    }

    /* Legend strip */
    .se-legend {
      position: absolute; bottom: 10px; right: 14px;
      padding: 7px 10px 6px;
      background: var(--paper);
      border: 1px dashed var(--ink4);
      border-radius: 3px;
      font-family: 'Inter', system-ui, sans-serif;
      font-size: 9.5px;
      color: var(--ink3);
      display: flex; flex-direction: column; gap: 3px;
      box-shadow: 1px 1px 0 0 rgba(0,0,0,.06);
      z-index: 5;
    }
    .se-legend .row { display: flex; align-items: center; gap: 6px; }
    .se-legend .swatch { display: inline-block; width: 18px; height: 0; border-top: 1.5px solid var(--ink); flex-shrink: 0; }
    .se-legend .swatch.dashed { border-top-style: dashed; border-top-color: var(--ink3); }
    .se-legend .swatch.accent { border-top-color: var(--accent); border-top-width: 2px; }

    /* In-canvas annotation */
    .se-margin-note {
      position: absolute;
      font-family: 'Caveat', cursive;
      font-size: 16px;
      color: var(--red);
      line-height: 1.1;
      max-width: 180px;
      z-index: 4;
    }
    .se-margin-note.indigo { color: var(--accent); }
    .se-margin-note .arrow { display: inline-block; margin-right: 3px; }
  `;
  document.head.appendChild(s);
}

// ─── Entity card ─────────────────────────────────────────────────────
// props: array of { name, type, req, ref, list, formula }
function EntityCard({
  name, blurb, props = [], parent, parentNote,
  sharing = 'public', island = false, global = false, recursive = false,
  variant, // 'accent' | 'dashed' | undefined
  top, left, width = 220, style = {},
}) {
  const cls = ['se-card'];
  if (island) cls.push('island');
  if (variant) cls.push(variant);

  return (
    <div className={cls.join(' ')} style={{ top, left, width, ...style }}>
      <div className="se-head">
        <span className="se-name">{name}</span>
        {island && <span className="se-badge island" title="_inheritrights: false">island</span>}
        {global && <span className="se-badge global">global</span>}
        {recursive && <span className="se-badge recursive">recursive</span>}
        <span className={`se-badge ${sharing}`}>{sharing}</span>
      </div>
      {blurb && <div className="se-blurb">{blurb}</div>}
      {props.length > 0 && (
        <div className="se-props">
          {props.map((p, i) => {
            const c = ['se-prop'];
            if (p.formula) c.push('formula');
            if (p.ref) c.push('ref');
            if (p.list) c.push('list');
            return (
              <div key={i} className={c.join(' ')}>
                <span className="se-pname">{p.name}</span>
                <span className="se-ptype">{p.type}</span>
                {p.req && <span className="se-req">*</span>}
              </div>
            );
          })}
        </div>
      )}
      {parent && (
        <div className="se-foot">
          <span className="se-parent">{parent}</span>
          {parentNote && <div style={{ marginTop: 2, color: 'var(--ink3)', fontStyle: 'italic' }}>{parentNote}</div>}
        </div>
      )}
    </div>
  );
}

// ─── Arrow layer ─────────────────────────────────────────────────────
// Convention: arrows flow PARENT → CHILD (top-down hierarchy feel).
// Each arrow carries:
//   verb        — semantic role of the parent-child link ("founded by", "sings in")
//   cardinality — multiplicity note (e.g. "1 person → N orgs", "0..N per member")
//   multi       — render a hollow circle at the PARENT end when the child is
//                 one of several parents (i.e. multi-parent on the child side)
//   waypoints   — for routed/curved paths (used by recursive self-loops)
function ArrowLayer({ arrows, width = 1400, height = 800 }) {
  return (
    <svg
      width={width}
      height={height}
      style={{ position: 'absolute', top: 0, left: 0, pointerEvents: 'none', zIndex: 1 }}
    >
      <defs>
        <marker id="ah-parent" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="9" markerHeight="9" orient="auto-start-reverse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill="#4f46e5" />
        </marker>
        <marker id="ah-ref" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill="#7a7166" />
        </marker>
        <marker id="multi-tail" viewBox="-1 -1 12 12" refX="5" refY="5" markerWidth="9" markerHeight="9" orient="auto">
          <circle cx="5" cy="5" r="3.5" fill="#faf7f0" stroke="#4f46e5" strokeWidth="1.6" />
        </marker>
      </defs>
      {arrows.map((a, i) => {
        const { from, to, kind = 'parent', verb, cardinality, multi = false, waypoints = [], labelOffset = [0, 0], labelAt } = a;
        const pts = [from, ...waypoints, to];
        const d = pts.map((p, j) => `${j === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
        const isRef = kind === 'ref';
        const stroke = isRef ? '#7a7166' : '#4f46e5';
        const sw = isRef ? 1.25 : 1.75;
        const dash = isRef ? '4 3' : 'none';
        const markerEnd = isRef ? 'url(#ah-ref)' : 'url(#ah-parent)';
        const markerStart = (multi && !isRef) ? 'url(#multi-tail)' : null;

        // Label anchor: by default midpoint of the path; can be overridden by labelAt
        const midPt = labelAt || (pts.length === 2
          ? { x: (from.x + to.x) / 2, y: (from.y + to.y) / 2 }
          : pts[Math.floor(pts.length / 2)]);
        const lx = midPt.x + labelOffset[0];
        const ly = midPt.y + labelOffset[1];

        // Size the label box from text length (rough)
        const verbW = (verb || '').length * 5.8;
        const cardW = (cardinality || '').length * 4.9;
        const w = Math.max(verbW, cardW) + 14;
        const h = cardinality ? 28 : 17;

        return (
          <g key={i}>
            <path d={d} stroke={stroke} strokeWidth={sw} fill="none" strokeDasharray={dash} markerEnd={markerEnd} markerStart={markerStart} />
            {verb && (
              <g>
                <rect x={lx - w / 2} y={ly - h / 2} width={w} height={h} fill="#faf7f0" stroke={stroke} strokeWidth={0.6} rx="2.5" opacity="0.96" />
                <text
                  x={lx} y={cardinality ? ly - 2 : ly + 3}
                  textAnchor="middle"
                  fontFamily="Inter, system-ui, sans-serif" fontSize="10" fontWeight="600"
                  fill={isRef ? '#4b443a' : '#4f46e5'}
                >
                  {verb}
                </text>
                {cardinality && (
                  <text
                    x={lx} y={ly + 10}
                    textAnchor="middle"
                    fontFamily="JetBrains Mono, ui-monospace, monospace" fontSize="9"
                    fill="#7a7166"
                  >
                    {cardinality}
                  </text>
                )}
              </g>
            )}
          </g>
        );
      })}
    </svg>
  );
}

// ─── Section header ──────────────────────────────────────────────────
function SchemaSectionHead({ index, title, intro, meta }) {
  return (
    <div className="se-section-head">
      <div className="se-section-index">{index}</div>
      <div className="se-section-title-wrap">
        <div className="se-section-title">{title}</div>
        <div className="se-section-intro">{intro}</div>
        {meta && <div className="se-section-meta">{meta}</div>}
      </div>
    </div>
  );
}

// ─── Legend ──────────────────────────────────────────────────────────
function SchemaLegend() {
  return (
    <div className="se-legend">
      <div className="row"><span className="swatch accent" /> parent → child (Entu _parent)</div>
      <div className="row"><span className="swatch dashed" /> reference (entity.property → target)</div>
      <div className="row" style={{ marginTop: 2 }}>
        <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: 999, background: '#faf7f0', border: '1.5px solid #4f46e5', flexShrink: 0 }} />
        multi-parent (child has additional parents)
      </div>
      <div className="row"><span style={{ color: 'var(--red)', fontWeight: 700, fontSize: 11 }}>*</span> required</div>
      <div className="row"><span style={{ color: 'var(--accent)', fontStyle: 'italic', fontSize: 10 }}>ƒ</span> formula (computed)</div>
    </div>
  );
}

// ─── Margin annotation ───────────────────────────────────────────────
function MarginNote({ top, left, right, bottom, indigo, children, style }) {
  return (
    <div className={`se-margin-note ${indigo ? 'indigo' : ''}`} style={{ top, left, right, bottom, ...style }}>
      {children}
    </div>
  );
}

Object.assign(window, {
  EntityCard, ArrowLayer, SchemaSectionHead, SchemaLegend, MarginNote,
});
