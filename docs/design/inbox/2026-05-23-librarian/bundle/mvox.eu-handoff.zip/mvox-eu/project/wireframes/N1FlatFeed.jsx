// N1 — Flat feed. Simple chronological stream, light composer, minimal chrome.
// No topics, no sidebar, no "mark all read", no per-card action menus.
// Schema per notice: pinned? unread? author, title, body?, poll?|link?, reactions.

function N1FlatFeed() {
  const pinned = NOTICES.filter(n => n.pinned);
  const rest   = NOTICES.filter(n => !n.pinned);

  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor/notices">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column' }}>
        <WorkspaceNav />
        <NoticesSubnav />

        {/* Single-column feed, generous side margin */}
        <div style={{ flex:1, overflow:'hidden', display:'flex', justifyContent:'center', padding:'18px 24px 24px' }}>
          <div style={{ width:'100%', maxWidth:680, display:'flex', flexDirection:'column', gap:14, overflow:'hidden' }}>

            {/* Page header: just a title + small meta */}
            <div>
              <Eyebrow>Notices</Eyebrow>
              <div style={{
                display:'flex', alignItems:'baseline', justifyContent:'space-between',
                marginTop:2,
              }}>
                <div style={{ fontFamily:'Inter', fontWeight:700, fontSize:22, letterSpacing:'-0.01em' }}>
                  Feed
                </div>
                <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
                  10 notices · 3 unread
                </div>
              </div>
            </div>

            {/* Light composer — collapsed, one line */}
            <Composer variant="collapsed" />

            {/* Small filter row — just three */}
            <div style={{
              display:'flex', alignItems:'center', gap:6,
              borderBottom:'1px solid var(--ink5)', paddingBottom:8,
            }}>
              <FilterTab label="All" count={10} active />
              <FilterTab label="Unread" count={3} />
              <FilterTab label="Pinned" count={2} />
            </div>

            {/* Feed */}
            <div style={{ display:'flex', flexDirection:'column', gap:0, overflow:'hidden' }}>
              {pinned.map(n => <NoticeItem key={n.id} notice={n} />)}
              {rest.map(n => <NoticeItem key={n.id} notice={n} />)}
            </div>

            <div style={{ textAlign:'center', padding:'2px 0 8px' }}>
              <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink4)' }}>
                <span className="sk-underline">Load older</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

// ─── Filter tab (tab-style, not chip-style) ───────────────────────────
function FilterTab({ label, count, active }) {
  return (
    <span style={{
      display:'inline-flex', alignItems:'center', gap:5,
      padding:'4px 10px',
      fontFamily:'Inter', fontSize:12,
      fontWeight: active ? 600 : 400,
      color: active ? 'var(--ink)' : 'var(--ink3)',
      borderBottom: active ? '2px solid var(--accent)' : '2px solid transparent',
      marginBottom: -9, paddingBottom: 8,
    }}>
      {label}
      <span style={{
        fontSize:10,
        color: active ? 'var(--accent)' : 'var(--ink4)',
        fontWeight: 600,
      }}>{count}</span>
    </span>
  );
}

// ─── Notice item — flat row with a thin divider, no card chrome ───────
function NoticeItem({ notice }) {
  const n = notice;
  const a = NOTICE_AUTHORS[n.author];
  const isSystem = n.author === 'system';
  return (
    <div style={{
      display:'flex', gap:10, padding:'14px 0',
      borderBottom:'1px dashed var(--ink5)',
      position:'relative',
    }}>
      {/* unread dot — in the left gutter */}
      <div style={{
        position:'absolute', top:22, left:-12,
        width:6, height:6, borderRadius:999,
        background: n.unread ? 'var(--accent)' : 'transparent',
      }} />

      <Avatar authorKey={n.author} size={28} />

      <div style={{ flex:1, minWidth:0 }}>
        {/* header line */}
        <div style={{
          display:'flex', alignItems:'center', gap:8, flexWrap:'wrap',
          fontFamily:'Inter', fontSize:11,
        }}>
          <span style={{ fontWeight:600, color:'var(--ink)', fontSize:12 }}>{a.name}</span>
          <RoleBadge role={a.role} />
          {n.type !== 'announcement' && <TypeChip type={n.type} />}
          <span style={{ color:'var(--ink4)' }}>·</span>
          <span className="mono" style={{ color:'var(--ink3)', fontSize:10 }}>{n.when}</span>
          {n.pinned && (
            <span style={{
              marginLeft:'auto',
              fontFamily:'Inter', fontSize:9, fontWeight:700, letterSpacing:'0.1em',
              textTransform:'uppercase', color:'var(--ink3)',
              display:'inline-flex', alignItems:'center', gap:3,
            }}>📌 Pinned</span>
          )}
        </div>

        {/* title */}
        <div style={{
          fontFamily:'Inter',
          fontSize: isSystem ? 12.5 : 14,
          fontWeight: isSystem ? 500 : 600,
          color:'var(--ink)', marginTop:3, letterSpacing:'-0.005em',
        }}>
          {n.title}
        </div>

        {/* body */}
        {n.body && (
          <div style={{
            fontFamily:'Inter', fontSize:12, color:'var(--ink2)',
            marginTop:3, lineHeight:1.5,
          }}>
            {n.body}
          </div>
        )}

        {n.poll && <PollBody poll={n.poll} />}
        {n.link && <LinkedItem link={n.link} type={n.type} />}

        {/* reactions only — no other actions */}
        <div style={{ marginTop:8 }}>
          <Reactions reactions={n.reactions} youReacted={n.youReacted} compact />
        </div>
      </div>
    </div>
  );
}

window.N1FlatFeed = N1FlatFeed;
