// Direction B — "The Ledger"
// Institutional / register. Tabs across the top, dense sortable table,
// task queue strip pinned at top-right, inspector drawer on the right.
// Maire as a working accountant of scores.

function DirectionB_Ledger() {
  const stats = libStats();
  const partWork = workById('part-magnificat');
  const partEd   = partWork.editions[0];

  const tabs = [
    { id:'holdings', label:'Holdings',       n: 13, tone:'' },
    { id:'loans',    label:'On loan',         n: stats.on_loan, tone:'' },
    { id:'overdue',  label:'Overdue',         n: 4, tone:'warn' },
    { id:'returns',  label:'Returns queue',   n: 12, tone:'' },
    { id:'pull',     label:'Pull list',       n: 3, tone:'' },
    { id:'activity', label:'Activity',        n: null, tone:'' },
  ];

  return (
    <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column', background:'var(--paper2)' }}>
      <MvoxNav active="library" />

      {/* Ledger header strip — like a bound register cover */}
      <div style={{
        padding:'14px 28px 0', background:'var(--paper3)',
        borderBottom:'1.5px solid var(--ink2)', position:'relative',
      }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', gap:24, marginBottom:14 }}>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.16em', textTransform:'uppercase', color:'var(--ink3)', fontWeight:600 }}>
              EPCC Library &nbsp;·&nbsp; Ledger of holdings & loans
            </div>
            <div style={{
              fontFamily:'Caveat, cursive', fontSize:38, fontWeight:700, lineHeight:1.0,
              color:'var(--ink)', letterSpacing:'-0.01em', marginTop:2,
            }}>
              Library register
              <span style={{ fontSize:18, color:'var(--ink3)', marginLeft:14 }}>
                {TODAY.date} · {TODAY.time}
              </span>
            </div>
          </div>

          {/* Pinned task queue */}
          <div style={{
            display:'flex', gap:8, flexShrink:0,
          }}>
            <TaskCard rank="1" title="12 Tallis to confirm" sub="Spem in alium · returned today" progress="8/12" tone="" />
            <TaskCard rank="2" title="4 Pärt overdue" sub="Magnificat · 195 days · 2 basses" progress="—" tone="red" />
            <TaskCard rank="3" title="Pull 3 for tonight" sub="Tormis · Kreek · Ešenvalds · 48" progress="1/3" tone="indigo" />
          </div>
        </div>

        {/* Tabs */}
        <div className="lb-tabs">
          {tabs.map(t => (
            <button key={t.id} className={`lb-tab ${t.id === 'holdings' ? 'active' : ''} ${t.tone}`}>
              {t.label}{t.n != null && <span className="count">{t.n}</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Toolbar */}
      <div style={{
        padding:'10px 28px', background:'var(--paper)',
        borderBottom:'1.5px solid var(--ink5)',
        display:'flex', alignItems:'center', gap:10, flexShrink:0,
      }}>
        <PencilSearch placeholder="Search composer, work, ISMN…" hint="⌘K" style={{ flex:1, padding:'4px 10px' }} />
        <span style={{ color:'var(--ink4)' }}>|</span>
        {[
          ['Voicing', 'All'],
          ['Language', 'All'],
          ['Period', 'All'],
          ['Status', 'Has copies'],
          ['Tag', 'sacred'],
        ].map(([k,v]) => (
          <button key={k} className="sk-btn ghost" style={{ fontSize:11, padding:'4px 9px', boxShadow:'1px 1px 0 0 var(--ink4)' }}>
            <span style={{ color:'var(--ink3)' }}>{k}:</span>
            <span style={{ fontWeight:600 }}>{v}</span>
            <span style={{ color:'var(--ink4)' }}>▾</span>
          </button>
        ))}
        <span style={{ color:'var(--ink4)' }}>|</span>
        <button className="sk-btn ghost" style={{ fontSize:11, padding:'4px 9px' }}>↓ Export CSV</button>
        <button className="sk-btn primary" style={{ fontSize:11, padding:'4px 9px' }}>＋ New work</button>
      </div>

      {/* Main grid: table | inspector */}
      <div style={{ flex:1, overflow:'hidden', display:'grid', gridTemplateColumns:'1fr 360px' }}>
        {/* Table */}
        <div style={{ overflowY:'auto', background:'var(--paper)' }}>
          <LedgerTable />
        </div>

        {/* Inspector */}
        <aside style={{
          borderLeft:'1.5px solid var(--ink2)',
          background:'var(--paper2)', overflowY:'auto',
        }}>
          <Inspector work={partWork} edition={partEd} />
        </aside>
      </div>

      {/* Footer summary */}
      <div style={{
        flexShrink:0, padding:'8px 28px',
        borderTop:'1.5px solid var(--ink2)',
        background:'var(--paper3)',
        display:'flex', justifyContent:'space-between', alignItems:'center',
        fontFamily:'Inter', fontSize:11, color:'var(--ink2)',
      }}>
        <div style={{ display:'flex', gap:22 }}>
          <span><strong style={{ color:'var(--ink)' }}>{stats.works}</strong> works</span>
          <span><strong style={{ color:'var(--ink)' }}>{stats.editions}</strong> editions</span>
          <span><strong style={{ color:'var(--ink)' }}>{stats.copies}</strong> copies owned</span>
          <span style={{ color:'var(--ink3)' }}>·</span>
          <span><StatusDot tone="green" /><strong style={{ color:'var(--ink)' }}>{stats.available}</strong> available</span>
          <span><StatusDot tone="amber" /><strong style={{ color:'var(--ink)' }}>{stats.on_loan}</strong> on loan</span>
          <span><StatusDot tone="red"   /><strong style={{ color:'var(--red)' }}>{stats.overdue}</strong> overdue</span>
        </div>
        <div style={{ display:'flex', gap:16 }}>
          <KeyHint k="↑↓" label="Move" />
          <KeyHint k="↵"  label="Open" />
          <KeyHint k="L"  label="Lend" />
          <KeyHint k="R"  label="Return" />
        </div>
      </div>
    </div>
  );
}

// Task card pinned at top right of ledger.
function TaskCard({ rank, title, sub, progress, tone }) {
  return (
    <div style={{
      width:180,
      padding:'8px 10px',
      background:'var(--paper)',
      border: tone === 'red' ? '1.5px solid var(--red)' : '1.5px solid var(--ink2)',
      borderRadius:4,
      boxShadow:'2px 2px 0 0 var(--ink4)',
      position:'relative',
    }}>
      <div style={{ display:'flex', alignItems:'flex-start', gap:8 }}>
        <span style={{
          width:20, height:20, borderRadius:'50%',
          background: tone === 'red' ? 'var(--red)' : (tone === 'indigo' ? 'var(--indigo)' : 'var(--ink)'),
          color:'#fff',
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          fontFamily:'Caveat, cursive', fontSize:14, fontWeight:700, flexShrink:0,
        }}>{rank}</span>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontFamily:'Inter', fontSize:11.5, fontWeight:600, color: tone === 'red' ? 'var(--red)' : 'var(--ink)' }}>{title}</div>
          <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)', marginTop:1, lineHeight:1.3 }}>{sub}</div>
        </div>
      </div>
      <div style={{
        marginTop:6, paddingTop:6, borderTop:'1px dashed var(--ink5)',
        display:'flex', justifyContent:'space-between', alignItems:'center',
        fontFamily:'JetBrains Mono', fontSize:10, color:'var(--ink3)',
      }}>
        <span>progress</span>
        <span style={{ fontWeight:600, color: tone === 'red' ? 'var(--red)' : 'var(--ink)', fontSize:11 }}>{progress}</span>
      </div>
    </div>
  );
}

function LedgerTable() {
  const partWork = workById('part-magnificat');

  return (
    <div>
      <div style={{
        position:'sticky', top:0, zIndex:2,
        display:'grid', gridTemplateColumns:'30px 36px 1.6fr 1.6fr 110px 100px 90px 100px 90px 110px',
        gap:8, padding:'10px 18px', background:'var(--paper3)',
        borderBottom:'2px solid var(--ink2)',
        fontFamily:'Inter', fontSize:10, letterSpacing:'0.10em',
        textTransform:'uppercase', color:'var(--ink2)', fontWeight:600,
      }}>
        <span></span>
        <span></span>
        <span>Composer · Work <span style={{ color:'var(--ink3)' }}>▲</span></span>
        <span>Edition · Publisher</span>
        <span>Voicing</span>
        <span style={{ textAlign:'right' }}>Year</span>
        <span style={{ textAlign:'right' }}>Owned</span>
        <span style={{ textAlign:'right' }}>Available</span>
        <span style={{ textAlign:'right' }}>Out</span>
        <span style={{ textAlign:'right' }}>Last activity</span>
      </div>

      {WORKS.map((w, i) => {
        const expand = w.id === 'part-magnificat';
        const tonightHL = ['tormis-raua','kreek-onnis','esenvalds-stars'].includes(w.id);
        const returnHL  = w.id === 'tallis-spem';
        return (
          <React.Fragment key={w.id}>
            {/* WORK ROW */}
            <LedgerWorkRow work={w} expanded={expand} tonight={tonightHL} returnHL={returnHL} />
            {/* Editions revealed if expanded */}
            {expand && w.editions.map(e => (
              <LedgerEditionRow key={e.id} edition={e} work={w} />
            ))}
            {expand && (
              <div style={{
                gridColumn:'1 / -1',
                padding:'14px 18px 14px 84px',
                background:'rgba(181,74,58,0.06)',
                borderBottom:'1.5px solid var(--ink5)',
              }}>
                <OverdueLoansList loans={w.editions[0].loans} />
              </div>
            )}
          </React.Fragment>
        );
      })}

      <div style={{ padding:'14px 18px', textAlign:'center', fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
        End of register · {WORKS.length} entries
      </div>
    </div>
  );
}

function LedgerWorkRow({ work, expanded, tonight, returnHL }) {
  const s = workStats(work);
  const e = work.editions[0];
  const lastActivity = work.id === 'tallis-spem' ? 'today, 09:14' :
                        work.id === 'part-magnificat' ? '12 Mar 2026' :
                        work.id === 'whitacre-sleep' ? '6 May 2026' :
                        ['tormis-raua','kreek-onnis','esenvalds-stars'].includes(work.id) ? 'today, 11:02' :
                        '14 Feb 2026';
  const bg = returnHL ? 'rgba(95,122,59,0.07)' :
              tonight ? 'rgba(79,70,229,0.05)' :
              expanded ? 'rgba(181,74,58,0.06)' : 'transparent';
  const tone = returnHL ? 'green' : tonight ? 'indigo' : (s.overdue > 0 ? 'red' : null);
  return (
    <div style={{
      display:'grid', gridTemplateColumns:'30px 36px 1.6fr 1.6fr 110px 100px 90px 100px 90px 110px',
      gap:8, padding:'12px 18px',
      borderBottom: expanded ? '1px solid var(--ink5)' : '1px dashed var(--ink5)',
      background: bg,
      alignItems:'center',
    }}>
      <span style={{ fontFamily:'JetBrains Mono', fontSize:10, color:'var(--ink4)', transform: expanded?'rotate(90deg)':'none', display:'inline-block' }}>▸</span>
      <span>
        {returnHL && <span title="Returns queue" style={{ fontFamily:'Caveat, cursive', fontWeight:700, color:'var(--green)', fontSize:18 }}>R</span>}
        {tonight  && <span title="Tonight"        style={{ fontFamily:'Caveat, cursive', fontWeight:700, color:'var(--indigo)', fontSize:18 }}>★</span>}
        {s.overdue > 0 && !returnHL && !tonight && <span title="Overdue" style={{ fontFamily:'Caveat, cursive', fontWeight:700, color:'var(--red)', fontSize:18 }}>!</span>}
      </span>
      <div style={{ minWidth:0 }}>
        <div style={{ fontFamily:'Inter', fontSize:13.5, color:'var(--ink)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
          <span style={{ fontWeight:600 }}>{work.composer}</span>
          <span style={{ color:'var(--ink3)', margin:'0 5px' }}>—</span>
          <span style={{ fontStyle:'italic' }}>{work.title}</span>
        </div>
        <div style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink3)' }}>
          {work.lang} · {work.period} · {work.tags.slice(0,2).join(' · ')}
          {work.editions.length > 1 && <span style={{ color:'var(--ink4)', marginLeft:6 }}>+{work.editions.length - 1} editions</span>}
        </div>
      </div>
      <div style={{ minWidth:0 }}>
        <div style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
          {e.label}
        </div>
        <div style={{ fontFamily:'JetBrains Mono', fontSize:10, color:'var(--ink3)' }}>
          {e.publisher}{e.isbn ? ` · ${e.isbn}` : ''}
        </div>
      </div>
      <div style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--ink2)' }}>{e.voicing}</div>
      <div style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--ink3)', textAlign:'right' }}>{work.year}</div>
      <div style={{ fontFamily:'JetBrains Mono', fontSize:12, color:'var(--ink)', textAlign:'right', fontWeight:600 }}>
        {s.has_limitless && s.total === 0 ? <span style={{ fontStyle:'italic', color:'var(--ink3)', fontWeight:400 }}>∞</span> : s.total}
      </div>
      <div style={{ textAlign:'right' }}>
        {s.total === 0 ? <span style={{ color:'var(--ink4)', fontFamily:'JetBrains Mono', fontSize:11 }}>—</span> : (
          <StatusPill tone={s.available > 0 ? 'green' : 'red'} style={{ fontSize:10.5 }}>
            <span className="mono" style={{ fontWeight:600 }}>{s.available}</span>
            <span style={{ color: s.available > 0 ? '#3c5320' : '#7a2418', opacity:0.7 }}>/{s.total}</span>
          </StatusPill>
        )}
      </div>
      <div style={{ textAlign:'right' }}>
        {s.loaned > 0 ? (
          <span style={{ fontFamily:'JetBrains Mono', fontSize:11, color: s.overdue > 0 ? 'var(--red)' : 'var(--amber)' }}>
            {s.loaned}{s.overdue > 0 && <span style={{ fontSize:10 }}> ({s.overdue}!)</span>}
          </span>
        ) : (
          <span style={{ color:'var(--ink4)', fontFamily:'JetBrains Mono', fontSize:11 }}>0</span>
        )}
      </div>
      <div style={{ fontFamily:'JetBrains Mono', fontSize:10.5, color:'var(--ink3)', textAlign:'right' }}>{lastActivity}</div>
    </div>
  );
}

function LedgerEditionRow({ edition, work }) {
  const avail = edition.limitless ? null : (edition.total - edition.on_loan);
  return (
    <div style={{
      display:'grid', gridTemplateColumns:'30px 36px 1.6fr 1.6fr 110px 100px 90px 100px 90px 110px',
      gap:8, padding:'8px 18px 8px 60px',
      background:'rgba(181,74,58,0.03)',
      borderBottom:'1px dashed var(--ink5)',
      alignItems:'center',
      fontFamily:'Inter', fontSize:11.5,
    }}>
      <span></span>
      <span style={{ fontFamily:'JetBrains Mono', fontSize:9, color:'var(--ink4)' }}>└</span>
      <div style={{ color:'var(--ink2)' }}>
        <span style={{ fontStyle:'italic' }}>{edition.label}</span>
        {edition.limitless && <span style={{ fontFamily:'Inter', fontSize:9.5, color:'var(--accent)', marginLeft:6, fontStyle:'italic' }}>∞ limitless</span>}
      </div>
      <div style={{ fontFamily:'JetBrains Mono', fontSize:10.5, color:'var(--ink3)' }}>{edition.publisher}{edition.isbn ? ` · ${edition.isbn}` : ''}</div>
      <div style={{ fontFamily:'JetBrains Mono', fontSize:10.5, color:'var(--ink2)' }}>{edition.voicing}</div>
      <div style={{ fontFamily:'JetBrains Mono', fontSize:10.5, color:'var(--ink4)', textAlign:'right' }}>{edition.year}</div>
      <div style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--ink2)', textAlign:'right' }}>{edition.limitless ? '∞' : edition.total}</div>
      <div style={{ textAlign:'right' }}>
        {avail != null && (
          <span style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--ink2)' }}>
            <span style={{ fontWeight:600 }}>{avail}</span>
            <span style={{ color:'var(--ink4)' }}>/{edition.total}</span>
          </span>
        )}
      </div>
      <div style={{ textAlign:'right', fontFamily:'JetBrains Mono', fontSize:11, color: edition.overdue > 0 ? 'var(--red)' : 'var(--ink3)' }}>
        {edition.on_loan || 0}{edition.overdue > 0 && <span> ({edition.overdue}!)</span>}
      </div>
      <div style={{ textAlign:'right', fontFamily:'Inter', fontSize:10.5, color:'var(--ink3)' }}>
        <span className="lb-uline">Open</span>
      </div>
    </div>
  );
}

function OverdueLoansList({ loans }) {
  return (
    <div>
      <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--red)', fontWeight:600, marginBottom:6 }}>
        4 copies on loan · all overdue
      </div>
      <div style={{
        background:'var(--paper)', border:'1px solid var(--ink5)', borderRadius:3,
      }}>
        <div style={{
          display:'grid', gridTemplateColumns:'70px 1.4fr 80px 110px 110px 1fr',
          gap:10, padding:'5px 12px', background:'var(--paper2)',
          fontFamily:'Inter', fontSize:9, letterSpacing:'0.10em', textTransform:'uppercase', color:'var(--ink3)', fontWeight:600,
          borderBottom:'1px solid var(--ink5)',
        }}>
          <span>Copy</span><span>Borrower</span><span>Voice</span><span>Since</span><span>Overdue</span><span>Action</span>
        </div>
        {loans.map((l, i) => {
          const m = byId(l.member);
          return (
            <div key={i} style={{
              display:'grid', gridTemplateColumns:'70px 1.4fr 80px 110px 110px 1fr',
              gap:10, padding:'7px 12px',
              borderBottom: i === loans.length - 1 ? 'none' : '1px dashed var(--ink5)',
              fontFamily:'Inter', fontSize:11.5, alignItems:'center',
            }}>
              <span className="mono" style={{ color:'var(--ink)', fontWeight:600 }}>{l.copy}</span>
              <span style={{ color:'var(--ink2)' }}>{m.name}</span>
              <span><Voice v={m.voice} /></span>
              <span className="mono" style={{ color:'var(--ink3)', fontSize:10.5 }}>{l.since}</span>
              <span style={{ color:'var(--red)', fontFamily:'JetBrains Mono', fontSize:10.5 }}>{l.days_overdue} d</span>
              <span style={{ display:'flex', gap:6 }}>
                <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 7px' }}>Nudge</button>
                <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 7px' }}>Mark returned</button>
                <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 7px', color:'var(--ink4)' }}>Write off</button>
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Inspector({ work, edition }) {
  const s = workStats(work);
  return (
    <div style={{ padding:'18px 20px' }}>
      <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em', textTransform:'uppercase', color:'var(--ink3)', fontWeight:600 }}>
        Inspector · selected work
      </div>
      <div style={{
        fontFamily:'Caveat, cursive', fontSize:26, fontWeight:700,
        color:'var(--ink)', marginTop:2, lineHeight:1.05, letterSpacing:'-0.01em',
      }}>
        {work.composer}
      </div>
      <div style={{ fontFamily:'Inter', fontSize:18, fontStyle:'italic', color:'var(--ink)' }}>
        {work.title}
      </div>
      <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginTop:4 }}>
        {work.year} · {work.lang} · {work.period}
      </div>

      <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginTop:8 }}>
        {work.tags.map(t => (
          <span key={t} className="sk-chip" style={{ fontSize:10, padding:'1px 8px' }}>{t}</span>
        ))}
      </div>

      <hr style={{ border:0, borderTop:'1.5px solid var(--ink5)', margin:'14px 0' }} />

      <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em', textTransform:'uppercase', color:'var(--ink3)', fontWeight:600, marginBottom:6 }}>
        Editions ({work.editions.length})
      </div>
      {work.editions.map((e, i) => (
        <div key={e.id} style={{
          padding:'8px 10px', marginBottom:6,
          background: i === 0 ? 'var(--paper)' : 'transparent',
          border: i === 0 ? '1.5px solid var(--ink2)' : '1px dashed var(--ink5)',
          borderRadius:3,
        }}>
          <div style={{ fontFamily:'Inter', fontSize:12, fontWeight:600, color:'var(--ink)' }}>{e.label}</div>
          <div style={{ fontFamily:'JetBrains Mono', fontSize:10, color:'var(--ink3)' }}>
            {e.publisher} · {e.voicing}{e.isbn ? ` · ${e.isbn}` : ''}
          </div>
          {!e.limitless ? (
            <div style={{ marginTop:5, display:'flex', alignItems:'center', gap:6 }}>
              <StatusPill tone={(e.total - e.on_loan) > 0 ? 'green' : 'red'} style={{ fontSize:10 }}>
                <span className="mono" style={{ fontWeight:600 }}>{e.total - e.on_loan}</span> available · {e.total} owned
              </StatusPill>
              {e.overdue > 0 && <StatusPill tone="red" style={{ fontSize:10 }}>{e.overdue} overdue</StatusPill>}
            </div>
          ) : (
            <div style={{ marginTop:4, fontFamily:'Inter', fontSize:10, color:'var(--accent)', fontStyle:'italic' }}>∞ limitless · digital only</div>
          )}
        </div>
      ))}

      <hr style={{ border:0, borderTop:'1.5px solid var(--ink5)', margin:'14px 0' }} />

      <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em', textTransform:'uppercase', color:'var(--ink3)', fontWeight:600, marginBottom:6 }}>
        Licensing note
      </div>
      <div style={{
        padding:'8px 10px', background:'var(--paper)', border:'1px dashed var(--ink4)',
        borderRadius:3, fontFamily:'JetBrains Mono', fontSize:10.5,
        color:'var(--ink2)', lineHeight:1.5, whiteSpace:'pre-wrap',
      }}>{work.notes}</div>

      <hr style={{ border:0, borderTop:'1.5px solid var(--ink5)', margin:'14px 0' }} />

      <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em', textTransform:'uppercase', color:'var(--ink3)', fontWeight:600, marginBottom:6 }}>
        Actions
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
        <button className="sk-btn" style={{ fontSize:12, justifyContent:'flex-start' }}>↩ Mark all overdue returned</button>
        <button className="sk-btn" style={{ fontSize:12, justifyContent:'flex-start' }}>✉ Nudge borrowers (2)</button>
        <button className="sk-btn" style={{ fontSize:12, justifyContent:'flex-start' }}>+ Lend a copy</button>
        <button className="sk-btn ghost" style={{ fontSize:12, justifyContent:'flex-start' }}>↗ Open on /works/part-magnificat</button>
        <button className="sk-btn ghost" style={{ fontSize:12, justifyContent:'flex-start', color:'var(--red)', borderColor:'var(--red)' }}>Archive…</button>
      </div>

      <Margin rotate={-1} style={{ marginTop:24, fontSize:15, lineHeight:1.3 }}>
        <span className="lb-arrow" style={{ marginRight:4 }}>↳</span>
        Henn is at the rehearsal<br />
        tonight — ask in person<br />
        before sending email.
      </Margin>
    </div>
  );
}

window.DirectionB_Ledger = DirectionB_Ledger;
