// N3 — Inbox / triage. Left rail with filters & mailboxes; center
// list of notice summaries; right preview pane. Emphasises sorting,
// pinned/unread/by-author filtering, and "deal with it" triage flow.

function N3Inbox() {
  const selectedId = 'n02'; // the poll is open, use it as active preview
  const selected = NOTICES.find(n => n.id === selectedId);

  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor/notices">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column' }}>
        <WorkspaceNav />
        <NoticesSubnav />

        {/* Header */}
        <div style={{
          padding:'12px 24px 10px', borderBottom:'1px solid var(--ink5)',
          display:'flex', justifyContent:'space-between', alignItems:'center',
        }}>
          <div>
            <Eyebrow>Notices · inbox</Eyebrow>
            <div style={{ fontFamily:'Inter', fontWeight:700, fontSize:20, letterSpacing:'-0.01em', marginTop:1 }}>
              Inbox
            </div>
          </div>
          <div style={{ display:'flex', gap:6, alignItems:'center', fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
            <span>View</span>
            <span style={{ padding:'3px 9px' }}>Flat</span>
            <span style={{ padding:'3px 9px' }}>Grouped</span>
            <span style={{ padding:'3px 9px', border:'1.25px solid var(--ink)', borderRadius:3, fontWeight:600, color:'var(--ink)' }}>Inbox</span>
          </div>
        </div>

        {/* 3-pane body */}
        <div style={{ flex:1, overflow:'hidden', display:'grid', gridTemplateColumns:'200px 340px 1fr', minHeight:0 }}>
          {/* LEFT RAIL: mailboxes + filters */}
          <aside style={{
            borderRight:'1px solid var(--ink5)', background:'var(--paper2)',
            padding:'14px 12px', overflow:'hidden', display:'flex', flexDirection:'column', gap:14,
          }}>
            <div>
              <button className="sk-btn primary" style={{ fontSize:11, width:'100%', justifyContent:'center' }}>
                + Compose notice
              </button>
            </div>

            <div>
              <Eyebrow>Mailboxes</Eyebrow>
              <div style={{ marginTop:6, display:'flex', flexDirection:'column', gap:1 }}>
                <MailboxLink icon="▪" label="All notices" count={10} />
                <MailboxLink icon="●" label="Unread" count={3} accent />
                <MailboxLink icon="📌" label="Pinned" count={2} active />
                <MailboxLink icon="★" label="Starred by you" count={2} />
                <MailboxLink icon="◉" label="Open polls" count={1} />
                <MailboxLink icon="@" label="@mentions" count={0} />
                <MailboxLink icon="⎘" label="Archived" count={47} muted />
              </div>
            </div>

            <div>
              <Eyebrow>By type</Eyebrow>
              <div style={{ marginTop:6, display:'flex', flexDirection:'column', gap:1 }}>
                <MailboxLink icon="✎" label="Announcements" count={5} />
                <MailboxLink icon="♫" label="Repertoire" count={2} />
                <MailboxLink icon="❒" label="Library" count={2} />
                <MailboxLink icon="◉" label="Polls" count={1} />
              </div>
            </div>

            <div>
              <Eyebrow>By author</Eyebrow>
              <div style={{ marginTop:6, display:'flex', flexDirection:'column', gap:1 }}>
                <AuthorPill authorKey="maarja" count={3} />
                <AuthorPill authorKey="tiit"   count={1} />
                <AuthorPill authorKey="kaarel" count={1} />
                <AuthorPill authorKey="liisa"  count={1} />
                <AuthorPill authorKey="system" count={4} />
              </div>
            </div>

            <div style={{ marginTop:'auto', padding:'8px 4px' }}>
              <Annot>Triage UX — batch-select & mark read, good for conductor-heavy weeks.</Annot>
            </div>
          </aside>

          {/* CENTER: message list */}
          <section style={{
            borderRight:'1px solid var(--ink5)', background:'var(--paper)',
            overflow:'hidden', display:'flex', flexDirection:'column',
          }}>
            {/* list header */}
            <div style={{
              padding:'8px 12px', borderBottom:'1px solid var(--ink5)', background:'var(--paper2)',
              display:'flex', alignItems:'center', gap:8,
              fontFamily:'Inter', fontSize:11, color:'var(--ink3)',
            }}>
              <span style={{
                width:13, height:13, border:'1.25px solid var(--ink4)',
                borderRadius:2, background:'var(--paper)',
              }} />
              <span>Pinned · 2</span>
              <span style={{ flex:1 }} />
              <span>Sort</span>
              <span style={{ color:'var(--ink)', fontWeight:600 }}>Newest</span>
              <span style={{ color:'var(--ink4)' }}>▾</span>
            </div>

            {/* list */}
            <div style={{ flex:1, overflow:'hidden' }}>
              {NOTICES.map(n => (
                <InboxRow key={n.id} notice={n} selected={n.id === selectedId} />
              ))}
            </div>
          </section>

          {/* RIGHT: preview */}
          <section style={{ overflow:'hidden', display:'flex', flexDirection:'column', background:'var(--paper)' }}>
            <PreviewPane notice={selected} />
          </section>
        </div>
      </div>
    </BrowserFrame>
  );
}

// ─── Left rail helpers ─────────────────────────────────────────────
function MailboxLink({ icon, label, count, active, accent, muted }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:8,
      padding:'4px 8px', borderRadius:3,
      background: active ? 'var(--paper)' : 'transparent',
      border: active ? '1px solid var(--ink4)' : '1px solid transparent',
      fontFamily:'Inter', fontSize:12,
      color: muted ? 'var(--ink4)' : (active ? 'var(--ink)' : 'var(--ink2)'),
      fontWeight: active ? 600 : 400,
    }}>
      <span style={{
        width:14, textAlign:'center', fontSize:11,
        color: accent ? 'var(--accent)' : 'var(--ink4)',
      }}>{icon}</span>
      <span style={{ flex:1 }}>{label}</span>
      <span style={{
        fontSize:10,
        color: accent && count > 0 ? 'var(--accent)' : 'var(--ink4)',
        fontWeight: accent ? 600 : 400,
      }}>{count}</span>
    </div>
  );
}

function AuthorPill({ authorKey, count }) {
  const a = NOTICE_AUTHORS[authorKey];
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:8,
      padding:'3px 8px', borderRadius:3,
      fontFamily:'Inter', fontSize:11, color:'var(--ink2)',
    }}>
      <Avatar authorKey={authorKey} size={18} />
      <span style={{ flex:1, minWidth:0, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
        {a.name}
      </span>
      <span style={{ fontSize:10, color:'var(--ink4)' }}>{count}</span>
    </div>
  );
}

// ─── Inbox row ────────────────────────────────────────────────────
function InboxRow({ notice, selected }) {
  const n = notice;
  const a = NOTICE_AUTHORS[n.author];
  const meta = TYPE_META[n.type];
  return (
    <div style={{
      display:'flex', gap:8, padding:'10px 12px 10px 10px',
      borderBottom:'1px solid var(--ink5)',
      background: selected ? 'var(--accent-soft)' : (n.unread ? 'rgba(79,70,229,0.03)' : 'var(--paper)'),
      borderLeft: selected ? '3px solid var(--accent)' : '3px solid transparent',
      position:'relative',
    }}>
      {/* checkbox */}
      <span style={{
        width:13, height:13, marginTop:2, flexShrink:0,
        border:'1.25px solid var(--ink4)', borderRadius:2, background:'var(--paper)',
      }} />

      {/* unread dot */}
      <span style={{
        width:7, height:7, borderRadius:999, marginTop:5, flexShrink:0,
        background: n.unread ? 'var(--accent)' : 'transparent',
      }} />

      <Avatar authorKey={n.author} size={26} />

      <div style={{ flex:1, minWidth:0 }}>
        <div style={{
          display:'flex', alignItems:'center', gap:6,
          fontFamily:'Inter', fontSize:11,
        }}>
          <span style={{
            fontWeight: n.unread ? 700 : 600,
            color:'var(--ink)',
            overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap',
            maxWidth:110,
          }}>{a.name}</span>
          {n.pinned && <span style={{ fontSize:10 }}>📌</span>}
          <span style={{ flex:1 }} />
          <span className="mono" style={{ fontSize:9, color:'var(--ink4)' }}>{n.when}</span>
        </div>
        <div style={{
          display:'flex', alignItems:'center', gap:6, marginTop:2,
          fontFamily:'Inter', fontSize: 12,
          fontWeight: n.unread ? 700 : 500,
          color: 'var(--ink)',
        }}>
          <span style={{
            fontSize:10, color: meta.color, flexShrink:0,
            width:14, height:14, border:`1px solid ${meta.color}`, borderRadius:2,
            display:'inline-flex', alignItems:'center', justifyContent:'center',
          }}>{meta.icon}</span>
          <span style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', minWidth:0 }}>
            {n.title}
          </span>
        </div>
        <div style={{
          fontFamily:'Inter', fontSize:11, color:'var(--ink3)',
          marginTop:2, overflow:'hidden', textOverflow:'ellipsis',
          whiteSpace:'nowrap',
        }}>
          {n.body}
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:4 }}>
          {n.topic && (
            <span style={{
              fontFamily:'Inter', fontSize:9, color:'var(--ink3)',
              padding:'0 6px', border:'1px dashed var(--ink4)', borderRadius:999,
            }}>#{n.topic}</span>
          )}
          {Object.keys(n.reactions || {}).length > 0 && (
            <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)' }}>
              {Object.entries(n.reactions).map(([e,c]) => `${e}${c}`).join('  ')}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Preview pane ──────────────────────────────────────────────────
function PreviewPane({ notice }) {
  const n = notice;
  const a = NOTICE_AUTHORS[n.author];
  return (
    <>
      {/* Preview toolbar */}
      <div style={{
        padding:'8px 14px', borderBottom:'1px solid var(--ink5)', background:'var(--paper2)',
        display:'flex', alignItems:'center', gap:6,
        fontFamily:'Inter', fontSize:11,
      }}>
        <button className="sk-btn ghost" style={{ fontSize:11, padding:'3px 9px' }}>Mark read</button>
        <button className="sk-btn ghost" style={{ fontSize:11, padding:'3px 9px' }}>★ Star</button>
        <button className="sk-btn ghost" style={{ fontSize:11, padding:'3px 9px' }}>📌 Unpin</button>
        <button className="sk-btn ghost" style={{ fontSize:11, padding:'3px 9px' }}>Archive</button>
        <span style={{ flex:1 }} />
        <span style={{ color:'var(--ink4)' }}>‹</span>
        <span className="mono" style={{ color:'var(--ink3)' }}>2 of 10</span>
        <span style={{ color:'var(--ink4)' }}>›</span>
      </div>

      {/* Preview body */}
      <div style={{ flex:1, overflow:'hidden', padding:'16px 20px', display:'flex', flexDirection:'column', gap:10 }}>
        <div>
          <div style={{
            display:'flex', alignItems:'center', gap:8, flexWrap:'wrap',
            fontFamily:'Inter', fontSize:11,
          }}>
            {n.type !== 'announcement' && <TypeChip type={n.type} />}
            {n.pinned && (
              <span style={{
                fontFamily:'Inter', fontSize:9, fontWeight:700, letterSpacing:'0.1em',
                textTransform:'uppercase', color:'var(--ink3)',
              }}>📌 Pinned</span>
            )}
            {n.topic && (
              <span style={{
                fontFamily:'Inter', fontSize:10, color:'var(--ink3)',
                padding:'1px 7px', border:'1px dashed var(--ink4)', borderRadius:999,
              }}>#{n.topic}</span>
            )}
          </div>
          <h2 style={{
            margin:'6px 0 2px', fontFamily:'Inter',
            fontSize:20, fontWeight:700, letterSpacing:'-0.01em', color:'var(--ink)',
          }}>{n.title}</h2>
          <div style={{
            display:'flex', alignItems:'center', gap:8,
            fontFamily:'Inter', fontSize:11, color:'var(--ink3)',
          }}>
            <Avatar authorKey={n.author} size={22} />
            <span style={{ fontWeight:600, color:'var(--ink2)' }}>{a.name}</span>
            <RoleBadge role={a.role} />
            <span style={{ color:'var(--ink4)' }}>·</span>
            <span className="mono" style={{ color:'var(--ink3)', fontSize:10 }}>{n.whenFull}</span>
          </div>
        </div>

        <hr className="sk-hr dashed" style={{ margin:'2px 0' }} />

        <div style={{
          fontFamily:'Inter', fontSize:13, color:'var(--ink2)',
          lineHeight:1.55,
        }}>{n.body}</div>

        {n.poll && <PollBody poll={n.poll} />}
        {n.link && <LinkedItem link={n.link} type={n.type} />}

        <div style={{
          marginTop:'auto', paddingTop:12,
          borderTop:'1px dashed var(--ink5)',
          display:'flex', alignItems:'center', gap:10,
        }}>
          <Reactions reactions={n.reactions} youReacted={n.youReacted} />
          <span style={{ flex:1 }} />
          <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', display:'flex', gap:10 }}>
            <span className="sk-underline">Copy link</span>
            <span className="sk-underline">Mute topic</span>
          </span>
        </div>
      </div>
    </>
  );
}

window.N3Inbox = N3Inbox;
