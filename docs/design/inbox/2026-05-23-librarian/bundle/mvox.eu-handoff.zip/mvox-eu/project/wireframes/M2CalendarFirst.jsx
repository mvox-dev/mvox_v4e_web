// M2 — Calendar-first.
// Month grid left; selected-event detail + upcoming strip right.

function M2CalendarFirst() {
  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column' }}>
        <WorkspaceNav />
        <WorkspaceSubnav active="agenda" />

        <div style={{ padding:'14px 24px 8px', borderBottom:'1px solid var(--ink5)', display:'flex', justifyContent:'space-between', alignItems:'flex-end' }}>
          <div>
            <Eyebrow>Agenda</Eyebrow>
            <div style={{ fontFamily:'Inter', fontWeight:700, fontSize:20, letterSpacing:'-0.01em' }}>Your season at a glance</div>
          </div>
          <div style={{ display:'flex', gap:10, alignItems:'center' }}>
            <ExternalToggle on={true} />
            <span style={{ color:'var(--ink4)' }}>·</span>
            <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>View: list · week · <span style={{ color:'var(--ink)', fontWeight:600 }}>month</span></span>
          </div>
        </div>

        <div style={{ flex:1, overflow:'hidden', padding:'14px 24px', display:'grid', gridTemplateColumns:'1.6fr 1fr', gap:20, minHeight:0 }}>
          {/* Month grid */}
          <div style={{ display:'flex', flexDirection:'column', minHeight:0 }}>
            <div style={{ flex:1, minHeight:0 }}>
              <MiniMonth selectedId={4} />
            </div>
            <div style={{ marginTop:10 }}>
              <Legend />
            </div>
          </div>

          {/* Selected + upcoming */}
          <div style={{ display:'flex', flexDirection:'column', gap:12, minHeight:0, overflow:'hidden' }}>
            <div className="sk-box accent" style={{ padding:12, background:'var(--paper)' }}>
              <Eyebrow>Selected · Sat 03 May</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:16, fontWeight:700, marginTop:4 }}>Reekviem — Duruflé</div>
              <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginTop:2 }}>
                <span className="mono">19:00</span> · Kaarli kirik, Tallinn · w/ Collegium Musicale
              </div>
              <Lines count={2} widths={['long','med']} />
              <div style={{ marginTop:10, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>Your RSVP</span>
                <RSVP state="yes" />
              </div>
              <div style={{ marginTop:8, display:'flex', gap:6 }}>
                <button className="sk-btn ghost" style={{ fontSize:10 }}>Score ↓</button>
                <button className="sk-btn ghost" style={{ fontSize:10 }}>Parts ↓</button>
                <button className="sk-btn ghost" style={{ fontSize:10 }}>Directions ↗</button>
              </div>
            </div>

            <div className="sk-box" style={{ padding:10, overflow:'hidden' }}>
              <Eyebrow style={{ marginBottom:6 }}>Upcoming</Eyebrow>
              <div style={{ overflow:'hidden' }}>
                {AGENDA.slice(0,5).map(ev => <EventRow key={ev.id} ev={ev} compact />)}
              </div>
            </div>
          </div>
        </div>

        <div style={{ borderTop:'1.5px solid var(--ink5)', padding:'14px 24px 18px', background:'var(--paper2)' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:6 }}>
            <div>
              <Eyebrow>Season repertoire</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:15, fontWeight:700 }}>6 works · 4 active</div>
            </div>
            <a className="sk-underline" style={{ fontFamily:'Inter', fontSize:11, color:'var(--accent)' }}>Browse all →</a>
          </div>
          <div style={{ maxHeight:130, overflow:'hidden' }}>
            {REPERTOIRE.slice(0,3).map((r,i)=><RepertoireRow key={i} item={r} />)}
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.M2CalendarFirst = M2CalendarFirst;
