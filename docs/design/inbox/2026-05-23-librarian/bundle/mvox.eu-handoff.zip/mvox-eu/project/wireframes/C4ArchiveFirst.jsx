// C4 — About/archive-first, spacious. Group portrait hero + history.
// Press & partners friendly. Concerts below the fold.

function C4ArchiveFirst({ withUmbrella = true }) {
  return (
    <BrowserFrame url="mvox.eu/o/kaaren-kammerkoor">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column', position:'relative' }}>
        <RegistryNav variant="signin" />

        {/* Large group portrait */}
        <div className="sk-hatch" style={{ height:210, position:'relative', borderBottom:'1.5px solid var(--ink4)', display:'flex', alignItems:'flex-end' }}>
          <div style={{ fontFamily:'Caveat', fontSize:15, color:'var(--ink3)', position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)' }}>group portrait — full-bleed</div>
          <div style={{ background:'linear-gradient(transparent, rgba(0,0,0,0.35))', padding:'60px 40px 22px', width:'100%', color:'#fff' }}>
            <div style={{ fontFamily:'Inter', fontSize:10, fontWeight:600, letterSpacing:'0.14em', textTransform:'uppercase', opacity:0.9 }}>Chamber choir · Tallinn · since 2014</div>
            <div style={{ fontFamily:'Inter', fontWeight:800, fontSize:40, lineHeight:1.05, letterSpacing:'-0.02em', marginTop:4 }}>Kaaren Kammerkoor</div>
            {withUmbrella && <div style={{ marginTop:8 }}><UmbrellaBadge name="Eesti Segakooride Liit" slug="eesti-segakooride-liit" /></div>}
          </div>
        </div>

        <div style={{ flex:1, overflow:'hidden', padding:'22px 40px', display:'grid', gridTemplateColumns:'1.4fr 1fr', gap:32, minHeight:0 }}>
          <div>
            <CH2>About</CH2>
            <p style={{ fontFamily:'Inter', fontSize:13, color:'var(--ink2)', lineHeight:1.6, margin:'0 0 10px', maxWidth:540 }}>
              Kaaren Kammerkoor is a 22-voice chamber choir formed in 2014 at EMTA. The choir works at the intersection of Baltic sacred tradition and contemporary composition.
            </p>
            <Lines count={3} widths={['long','long','med']} />

            <CH2>History & milestones</CH2>
            <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
              {[
                ['2014', 'Founded at EMTA by Mari Tõnisson with 12 singers'],
                ['2017', 'First full-length programme · Kreek retrospective'],
                ['2019', 'Debut studio recording · Alba Records'],
                ['2022', 'Premiere commission · Sisask "Piirid"'],
                ['2023', 'Nordic Choir Festival · silver category'],
                ['2024', 'Selected ensemble · XXVIII Laulupidu'],
              ].map(([y,t],i)=>(
                <div key={i} style={{ display:'flex', gap:14, padding:'5px 0', borderBottom:'1px dashed var(--ink5)' }}>
                  <span className="mono" style={{ width:44, color:'var(--accent)', fontWeight:500 }}>{y}</span>
                  <span style={{ flex:1, fontFamily:'Inter', fontSize:12, color:'var(--ink2)' }}>{t}</span>
                </div>
              ))}
            </div>

            <CH2>Artistic direction</CH2>
            <div style={{ display:'flex', gap:14 }}>
              <div className="sk-hatch" style={{ width:70, height:90, borderRadius:4, border:'1px solid var(--ink4)', flexShrink:0 }} />
              <div style={{ flex:1 }}>
                <div style={{ fontFamily:'Inter', fontSize:14, fontWeight:700 }}>Mari Tõnisson</div>
                <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>Conductor & artistic director since 2018</div>
                <Lines count={2} widths={['long','med']} />
              </div>
            </div>

            <CH2 right="browse repertoire →">Season programme</CH2>
            {[['Duruflé','Requiem Op.9','SATB'],['Pärt','Da pacem Domine','SATB'],['Kreek','Taaveti laul','SATB'],['Sisask','Piirid (premiere)','SATB div.']].map(([c,w,v],i)=>(
              <div key={i} style={{ display:'flex', justifyContent:'space-between', padding:'4px 0', borderBottom:'1px dashed var(--ink5)', fontFamily:'Inter', fontSize:12 }}>
                <span><span style={{ fontWeight:600 }}>{c}</span> — <span className="sk-underline" style={{ color:'var(--accent)' }}>{w}</span></span>
                <span className="mono" style={{ color:'var(--ink3)', fontSize:10 }}>{v}</span>
              </div>
            ))}

            <CH2>Past highlights</CH2>
            <div style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink2)', lineHeight:1.65 }}>
              <div>· Laulupidu 2024 — selected ensemble</div>
              <div>· Nordic Choir Festival 2023 — silver category</div>
              <div>· EMP premiere of Sisask, "Piirid" (2022)</div>
              <div>· Alba Records debut (2019)</div>
            </div>
          </div>

          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            <div className="sk-box" style={{ padding:12 }}>
              <Eyebrow>Next concert</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:15, fontWeight:700, marginTop:4 }}>Reekviem</div>
              <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>03 May · Kaarli kirik · w/ Collegium Musicale</div>
              <div style={{ display:'flex', gap:6, marginTop:8 }}>
                <button className="sk-btn primary" style={{ fontSize:11 }}>Tickets</button>
                <button className="sk-btn ghost" style={{ fontSize:11 }}>Programme →</button>
              </div>
            </div>

            <div className="sk-box" style={{ padding:12 }}>
              <Eyebrow right="all 8 →">Upcoming concerts</Eyebrow>
              <div style={{ marginTop:4 }}>
                {[['MAY','24','Kevadkontsert','Mustpeade Maja'],['JUN','14','Suvine õhtu','Vanemuise, Tartu'],['JUL','02','Suvefestival','Haapsalu toomkirik']].map(([m,d,t,v],i)=>(
                  <div key={i} style={{ display:'flex', gap:8, padding:'5px 0', borderBottom:'1px dashed var(--ink5)' }}>
                    <div className="sk-box" style={{ width:30, textAlign:'center', padding:'2px 0', flexShrink:0 }}>
                      <div style={{ fontFamily:'Inter', fontSize:8, fontWeight:600, color:'var(--accent)', letterSpacing:'0.1em' }}>{m}</div>
                      <div style={{ fontFamily:'Inter', fontSize:13, fontWeight:700, lineHeight:1 }}>{d}</div>
                    </div>
                    <div style={{ flex:1, minWidth:0, fontFamily:'Inter', fontSize:11 }}>
                      <div style={{ fontWeight:600 }}>{t}</div>
                      <div style={{ color:'var(--ink3)', fontSize:10 }}>{v}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="sk-box filled" style={{ padding:12 }}>
              <Eyebrow style={{ marginBottom:6 }}>Recordings</Eyebrow>
              {[['Õhtupalve','2024'],['Gloria in D','2023'],['Piirid (EP)','Alba · 2023']].map(([t,y],i)=>(
                <div key={i} style={{ display:'flex', alignItems:'center', gap:8, padding:'5px 0', borderBottom:'1px dashed var(--ink5)' }}>
                  <div className="sk-box" style={{ width:22, height:22, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:9 }}>▶</div>
                  <span style={{ flex:1, fontFamily:'Inter', fontSize:11, fontWeight:600 }}>{t}</span>
                  <span className="mono" style={{ fontSize:9, color:'var(--ink3)' }}>{y}</span>
                </div>
              ))}
            </div>

            <div className="sk-box soft" style={{ padding:12 }}>
              <Eyebrow style={{ marginBottom:6 }}>Join the choir</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink2)', marginBottom:6 }}>3 voice spots currently open</div>
              <VoiceSections data={[['S',6,1],['A',5,0],['T',5,2],['B',6,0]]} />
              <button className="sk-btn ghost" style={{ marginTop:8, width:'100%', fontSize:11, justifyContent:'center' }}>Audition info →</button>
            </div>

            <div className="sk-box dashed" style={{ padding:12 }}>
              <Eyebrow style={{ marginBottom:6 }}>Rehearsals</Eyebrow>
              <RehearsalRow day="Mon" time="19:00–21:30" venue="EMTA R-207" />
              <RehearsalRow day="Thu" time="19:00–21:30" venue="EMTA R-207" />
            </div>

            <div className="sk-box" style={{ padding:12 }}>
              <Eyebrow style={{ marginBottom:6 }}>Press & contact</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)', lineHeight:1.55 }}>
                Press kit · high-res photos · bio<br/>
                <span className="mono" style={{ color:'var(--accent)' }}>press@kaaren.ee</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.C4ArchiveFirst = C4ArchiveFirst;
