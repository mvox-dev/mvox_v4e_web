// Library primitives — librarian-only page at /members/<slug>/library.
// Reuses SketchyPrimitives + WorkspacePrimitives (WorkspaceNav, etc).
//
// Data model: each WORK has 1+ EDITIONS. Each edition has:
//   - files[] (score/parts/track/ref/notes with version history)
//   - total_copies: number
//         > 0  → tracked physical inventory; individual copies can be loaned to roster members
//         = 0  → "limitless" edition (digital only, or public-domain print-as-needed). Not loanable.

// ─── Mock data ────────────────────────────────────────────────────────
const LIBRARY = [
  {
    id:1, composer:'Maurice Duruflé', title:'Requiem Op. 9', voicing:'SATB + org.',
    lang:'Latin', year:1947, difficulty:4,
    tags:['sacred','20th c.','French'],
    notes:'Licensing: Éditions Durand. Performance license on file (rehearsal PDF in attached doc). Paid €84 in 2023-09 for 30 copies (invoice #DUR-4421).\n\nNote: Martin asked about organ reduction — yes, we own it, see Edition B.',
    editions:[
      { id:'a', label:'Peters · full score', year:1991, isbn:'EP-8421',
        files:[
          { kind:'score', name:'requiem-durufle-peters-score.pdf', v:3, size:'4.2MB', latest:true },
          { kind:'parts', name:'requiem-durufle-parts.zip', v:2, size:'11MB', latest:true },
          { kind:'track', name:'requiem-rehearsal-sop.mp3', v:1, size:'12MB', latest:true },
          { kind:'track', name:'requiem-rehearsal-alt.mp3', v:1, size:'12MB', latest:true },
          { kind:'notes', name:'conductor-notes.pdf', v:1, size:'0.3MB', latest:true },
        ],
        total_copies: 32, loaned: 4,
        copy_items:[
          { n:'#01', loc:'Cabinet A · shelf 2', borrower:null },
          { n:'#02', loc:'Cabinet A · shelf 2', borrower:null },
          { n:'#14', loc:'—', borrower:'Mari Tõnisson', since:'2025-04-28' },
          { n:'#15', loc:'—', borrower:'Jaan Pärnsalu', since:'2025-04-28' },
          { n:'#18', loc:'—', borrower:'Liisa Mets',    since:'2025-04-21' },
          { n:'#22', loc:'—', borrower:'Rein Tamm',     since:'2025-04-14' },
        ],
      },
      { id:'b', label:'Durand · organ reduction (digital)', year:1948, isbn:'DUR-992',
        files:[ { kind:'score', name:'requiem-durufle-organ.pdf', v:1, size:'3.1MB', latest:true } ],
        total_copies: 0, // limitless
      },
    ],
    referenced:true,
  },
  {
    id:2, composer:'Arvo Pärt', title:'Da pacem Domine', voicing:'SATB',
    lang:'Latin', year:2004, difficulty:2, tags:['sacred','Estonian','contemporary'],
    notes:'Universal Edition. Standard license fee per performance.',
    editions:[
      { id:'a', label:'Universal Edition', year:2004, isbn:'UE-34521',
        files:[
          { kind:'score', name:'dapacem-score.pdf', v:2, size:'0.9MB', latest:true },
          { kind:'track', name:'dapacem-reference-tallinn.mp3', v:1, size:'4MB', latest:true },
        ],
        total_copies: 28, loaned: 0, copy_items:[],
      },
    ],
    referenced:true,
  },
  { id:3, composer:'Cyrillus Kreek', title:'Taaveti laul 141', voicing:'SATB', lang:'Estonian', year:1923, difficulty:3, tags:['sacred','Estonian','folk'], notes:'Public domain in EU. SP Muusikaprojekt edition preferred.', editions:[{id:'a',label:'SP Muusikaprojekt',year:1998,isbn:'—',files:[],total_copies:26,loaned:2,copy_items:[]}], referenced:false },
  { id:4, composer:'Urmas Sisask', title:'Piirid', voicing:'SATB div.', lang:'Estonian', year:2022, difficulty:4, tags:['contemporary','Estonian','commissioned'], notes:'Commissioned premiere. Composer retains rights.', editions:[{id:'a',label:'Manuscript (composer)',year:2022,isbn:'—',files:[],total_copies:30,loaned:0,copy_items:[]}], referenced:true },
  { id:5, composer:'Ester Mägi', title:'Laulud (cycle)', voicing:'SSAA', lang:'Estonian', year:1979, difficulty:3, tags:['Estonian','20th c.','women'], notes:'', editions:[{id:'a',label:'Eesti Raamat',year:1982,isbn:'—',files:[],total_copies:18,loaned:0,copy_items:[]}], referenced:false },
  { id:6, composer:'Veljo Tormis', title:'Raua needmine', voicing:'SATB · shaman', lang:'Estonian', year:1972, difficulty:5, tags:['Estonian','runo','20th c.'], notes:'', editions:[{id:'a',label:'Fennica Gehrman',year:1991,isbn:'—',files:[],total_copies:24,loaned:1,copy_items:[]}], referenced:true },
  { id:7, composer:'Henry Purcell', title:'Hear my prayer, O Lord', voicing:'SSAATTBB', lang:'English', year:1682, difficulty:4, tags:['sacred','English','baroque'], notes:'', editions:[{id:'a',label:'CPDL (digital)',year:2009,isbn:'—',files:[],total_copies:0}], referenced:false },
  { id:8, composer:'Rudolf Tobias', title:'Eks teie tea', voicing:'SATB', lang:'Estonian', year:1908, difficulty:2, tags:['sacred','Estonian'], notes:'', editions:[{id:'a',label:'SP Muusikaprojekt',year:2001,isbn:'—',files:[],total_copies:20,loaned:0,copy_items:[]}], referenced:false },
];

// Helpers that sum copy state across a work's tracked editions only.
function workCopyStats(work) {
  const tracked = work.editions.filter(e => e.total_copies > 0);
  const total   = tracked.reduce((s,e) => s + (e.total_copies || 0), 0);
  const loaned  = tracked.reduce((s,e) => s + (e.loaned || 0), 0);
  const hasLimitless = work.editions.some(e => e.total_copies === 0);
  return { total, loaned, avail: total - loaned, hasLimitless, trackedCount: tracked.length };
}

const FILE_KINDS = {
  score: { label:'Score',     icon:'♪', color:'var(--accent)' },
  parts: { label:'Parts',     icon:'≡', color:'#2f7a4f' },
  track: { label:'Track',     icon:'♫', color:'#6a5a8a' },
  ref:   { label:'Reference', icon:'★', color:'#8a6a2e' },
  notes: { label:'Notes',     icon:'✎', color:'var(--ink3)' },
};

const ROSTER = [
  'Mari Tõnisson','Jaan Pärnsalu','Liisa Mets','Rein Tamm','Eva Kask','Toomas Järv',
  'Kadri Saar','Peeter Ojaste','Helena Kuusk','Martin Raudla',
];

// ─── Filter bar ─────────────────────────────────────────────────────
function LibraryFilterBar() {
  const facets = [
    { label:'Composer', value:'All' },
    { label:'Voicing', value:'SATB+' },
    { label:'Language', value:'All' },
    { label:'Tag', value:'sacred' },
    { label:'Has copies', value:'available' },
  ];
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:10, padding:'10px 24px',
      borderBottom:'1.5px solid var(--ink5)', background:'var(--paper2)', flexWrap:'wrap',
    }}>
      <Eyebrow>Filter</Eyebrow>
      {facets.map((f,i)=>(
        <button key={i} className="sk-btn ghost" style={{
          fontSize:11, padding:'3px 10px', background:'var(--paper)',
          boxShadow:'1px 1px 0 0 var(--ink4)',
        }}>
          <span style={{ color:'var(--ink3)' }}>{f.label}:</span>
          <span style={{ fontWeight:600, color:'var(--ink)' }}>{f.value}</span>
          <span style={{ color:'var(--ink4)' }}>▾</span>
        </button>
      ))}
      <span style={{ color:'var(--ink4)' }}>·</span>
      <Chip variant="accent" style={{ fontSize:10 }}>8 of 64 works</Chip>
      <div style={{ flex:1 }} />
      <button className="sk-btn primary" style={{ fontSize:12 }}>＋ Add work</button>
    </div>
  );
}

// ─── Difficulty dots ────────────────────────────────────────────────
function Difficulty({ level }) {
  return (
    <span style={{ display:'inline-flex', gap:2, verticalAlign:'middle' }} title={`Difficulty ${level}/5`}>
      {[1,2,3,4,5].map(i => (
        <span key={i} style={{
          width:6, height:6, borderRadius:99,
          background: i<=level ? 'var(--ink2)' : 'transparent',
          border:'1px solid var(--ink3)',
        }} />
      ))}
    </span>
  );
}

// ─── Work row ────────────────────────────────────────────────────────
function WorkRow({ work, expanded = false, selected = false, compact = false }) {
  const s = workCopyStats(work);
  return (
    <div style={{
      padding: compact ? '8px 12px' : '10px 14px',
      borderBottom:'1px dashed var(--ink5)',
      background: selected ? 'var(--accent-soft)' : (expanded ? 'var(--paper2)' : 'var(--paper)'),
      borderLeft: selected ? '3px solid var(--accent)' : '3px solid transparent',
      display:'flex', alignItems:'center', gap:12, cursor:'pointer',
    }}>
      <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)', width:14, transform: expanded?'rotate(90deg)':'rotate(0)' }}>▸</span>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontFamily:'Inter', fontSize: compact?12:13, color:'var(--ink)' }}>
          <span style={{ fontWeight:600 }}>{work.composer}</span>
          <span style={{ color:'var(--ink3)' }}> — </span>
          <span style={{ fontStyle:'italic' }}>{work.title}</span>
        </div>
        <div style={{ display:'flex', gap:8, alignItems:'center', marginTop:2, flexWrap:'wrap' }}>
          <span className="mono" style={{ fontSize:10, color:'var(--ink3)' }}>{work.voicing}</span>
          <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>· {work.lang}</span>
          <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>· {work.year}</span>
          <Difficulty level={work.difficulty} />
          {work.tags.slice(0,2).map((t,i)=><Chip key={i} style={{ fontSize:9, padding:'1px 6px' }}>{t}</Chip>)}
        </div>
      </div>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexShrink:0 }}>
        <FileKindDots editions={work.editions} />
        <CopiesBadge stats={s} />
      </div>
    </div>
  );
}

// Badge that collapses the work-level copy state; explicit about limitless editions.
function CopiesBadge({ stats }) {
  if (stats.total === 0 && stats.hasLimitless) {
    return (
      <span style={{
        fontFamily:'Inter', fontSize:10, color:'var(--ink3)',
        padding:'2px 8px', border:'1px dashed var(--ink4)', borderRadius:3, background:'var(--paper)',
        whiteSpace:'nowrap', fontStyle:'italic',
      }}>∞ limitless</span>
    );
  }
  return (
    <span style={{
      fontFamily:'Inter', fontSize:10, color: stats.avail > 0 ? 'var(--ink2)' : 'var(--red)',
      padding:'2px 8px', border:'1px solid var(--ink4)', borderRadius:3, background:'var(--paper)',
      whiteSpace:'nowrap',
    }}>
      <span className="mono" style={{ fontWeight:600 }}>{stats.avail}</span>
      <span style={{ color:'var(--ink4)' }}>/{stats.total}</span>
      <span style={{ color:'var(--ink4)', marginLeft:4, fontSize:9 }}>copies</span>
      {stats.hasLimitless && <span title="plus limitless editions" style={{ color:'var(--accent)', marginLeft:4 }}>+∞</span>}
    </span>
  );
}

// ─── File-kind summary dots ─────────────────────────────────────────
function FileKindDots({ editions }) {
  const kinds = new Set();
  editions.forEach(e => (e.files || []).forEach(f => kinds.add(f.kind)));
  const order = ['score','parts','track','ref','notes'];
  return (
    <div style={{ display:'flex', gap:3 }}>
      {order.map(k => {
        const present = kinds.has(k);
        const kd = FILE_KINDS[k];
        return (
          <span key={k} title={kd.label} style={{
            width:18, height:18, borderRadius:3, display:'inline-flex', alignItems:'center', justifyContent:'center',
            fontSize:10, fontFamily:'Inter',
            color: present ? kd.color : 'var(--ink5)',
            border:`1px ${present?'solid':'dashed'} ${present?kd.color:'var(--ink5)'}`,
            background: present ? 'var(--paper)' : 'transparent',
          }}>{kd.icon}</span>
        );
      })}
    </div>
  );
}

// ─── File row ───────────────────────────────────────────────────────
function FileRow({ file }) {
  const kd = FILE_KINDS[file.kind];
  return (
    <div style={{ display:'flex', alignItems:'center', gap:10, padding:'5px 0', borderBottom:'1px dashed var(--ink5)', fontFamily:'Inter' }}>
      <span style={{ width:22, height:22, borderRadius:3, display:'inline-flex', alignItems:'center', justifyContent:'center', background:'var(--paper2)', border:`1px solid ${kd.color}`, color:kd.color, fontSize:11 }}>{kd.icon}</span>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontSize:11, fontWeight:600, color:'var(--ink)' }}>{file.name}</div>
        <div style={{ fontSize:9, color:'var(--ink3)' }}>
          {kd.label} · v{file.v} {file.latest && <span style={{ color:'var(--accent)', fontWeight:600 }}>· latest</span>} · <span className="mono">{file.size}</span>
        </div>
      </div>
      <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 8px' }}>↓</button>
      <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 8px' }}>Replace</button>
      <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 6px', color:'var(--ink3)' }}>⋯</button>
    </div>
  );
}

// ─── Edition block ──────────────────────────────────────────────────
// Now OWNS its own copy-tracking state. Shows one of:
//   (a) tracked copy table + loan controls  (total_copies > 0)
//   (b) limitless banner (no loans possible) (total_copies === 0)
function EditionBlock({ edition, showLoanPicker = false, defaultOpen = true }) {
  const tracked = edition.total_copies > 0;
  const avail = tracked ? (edition.total_copies - (edition.loaned || 0)) : null;

  return (
    <div className="sk-box" style={{ padding:10, background:'var(--paper)', marginBottom:8 }}>
      {/* Edition header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:6, gap:10 }}>
        <div style={{ minWidth:0 }}>
          <div style={{ fontFamily:'Inter', fontSize:12, fontWeight:700, color:'var(--ink)' }}>
            {edition.label}
            {!tracked && (
              <Chip variant="accent" style={{
                fontSize:9, padding:'1px 6px', marginLeft:8, borderStyle:'dashed',
                background:'transparent', color:'var(--accent)', fontStyle:'italic',
              }}>∞ limitless</Chip>
            )}
          </div>
          <span className="mono" style={{ fontSize:10, color:'var(--ink3)' }}>{edition.year} · {edition.isbn}</span>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:6, flexShrink:0 }}>
          {tracked ? (
            <span style={{
              fontFamily:'Inter', fontSize:10, color: avail > 0 ? 'var(--ink2)' : 'var(--red)',
              padding:'2px 8px', border:'1px solid var(--ink4)', borderRadius:3, background:'var(--paper2)', whiteSpace:'nowrap',
            }}>
              <span className="mono" style={{ fontWeight:600 }}>{avail}</span>
              <span style={{ color:'var(--ink4)' }}>/{edition.total_copies}</span>
              <span style={{ color:'var(--ink4)', marginLeft:4, fontSize:9 }}>copies</span>
            </span>
          ) : null}
          <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 8px' }}>＋ File</button>
          <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 8px' }}>Edit</button>
        </div>
      </div>

      {/* Files */}
      {(edition.files || []).length > 0 ? (
        (edition.files || []).map((f,i) => <FileRow key={i} file={f} />)
      ) : (
        <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)', fontStyle:'italic', padding:'3px 0', borderBottom:'1px dashed var(--ink5)' }}>
          No files attached to this edition.
        </div>
      )}
      {(edition.files || []).length > 0 && (
        <div style={{ marginTop:6, fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>
          <span className="sk-underline" style={{ color:'var(--accent)', cursor:'pointer' }}>Show older versions ▾</span>
        </div>
      )}

      {/* Copy section — only rendered for tracked editions */}
      {tracked ? (
        <div style={{ marginTop:10, paddingTop:10, borderTop:'1.5px dashed var(--ink5)' }}>
          <EditionCopies edition={edition} showLoanPicker={showLoanPicker && defaultOpen} />
        </div>
      ) : (
        <div style={{
          marginTop:8, padding:'6px 10px',
          background:'var(--paper2)', border:'1px dashed var(--ink5)', borderRadius:3,
          fontFamily:'Inter', fontSize:10, color:'var(--ink3)', lineHeight:1.45,
        }}>
          <span style={{ color:'var(--accent)', fontWeight:600 }}>Limitless edition</span> — digital / public-domain.
          No physical inventory tracked; nothing to check out to roster members.
          <span className="sk-underline" style={{ color:'var(--accent)', cursor:'pointer', marginLeft:6 }}>Convert to tracked…</span>
        </div>
      )}
    </div>
  );
}

// ─── Per-edition copies (table + loan controls) ─────────────────────
function EditionCopies({ edition, showLoanPicker }) {
  const avail = edition.total_copies - (edition.loaned || 0);
  const items = edition.copy_items || [];
  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:6 }}>
        <div>
          <span style={{ fontFamily:'Inter', fontSize:11, fontWeight:700 }}>Physical copies of this edition</span>
          <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)', marginLeft:8 }}>
            <span className="mono" style={{ fontWeight:600, color:'var(--ink)' }}>{avail}</span> of {edition.total_copies} available · {edition.loaned || 0} on loan
          </span>
        </div>
        <div style={{ display:'flex', gap:4 }}>
          <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 8px' }}>＋ Add copies</button>
          <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 8px' }}>Check out →</button>
        </div>
      </div>

      {items.length > 0 ? (
        <div style={{ border:'1px solid var(--ink5)', borderRadius:3, overflow:'hidden', background:'var(--paper)' }}>
          <div style={{
            display:'grid', gridTemplateColumns:'60px 1fr 180px 110px 80px',
            gap:8, padding:'4px 8px', background:'var(--paper2)',
            fontFamily:'Inter', fontSize:9, fontWeight:600, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--ink4)',
          }}>
            <span>Copy</span><span>Location</span><span>Borrower (roster)</span><span>Since</span><span></span>
          </div>
          {items.map((c,i)=>(
            <div key={i} style={{
              display:'grid', gridTemplateColumns:'60px 1fr 180px 110px 80px', gap:8,
              padding:'4px 8px', borderTop:'1px dashed var(--ink5)', fontFamily:'Inter', fontSize:11,
              background: c.borrower ? 'rgba(200,75,58,0.05)' : 'transparent',
            }}>
              <span className="mono" style={{ color:'var(--ink)', fontWeight:600 }}>{c.n}</span>
              <span style={{ color: c.loc === '—' ? 'var(--ink4)' : 'var(--ink2)' }}>{c.loc}</span>
              <span style={{ color: c.borrower ? 'var(--red)' : 'var(--ink4)' }}>
                {c.borrower || <em style={{ color:'var(--ink4)' }}>available</em>}
              </span>
              <span className="mono" style={{ color:'var(--ink3)', fontSize:10 }}>{c.since || '—'}</span>
              <span style={{ textAlign:'right' }}>
                {c.borrower ? (
                  <span className="sk-underline" style={{ color:'var(--accent)', fontSize:10, cursor:'pointer' }}>Return</span>
                ) : (
                  <span className="sk-underline" style={{ color:'var(--ink3)', fontSize:10, cursor:'pointer' }}>Lend</span>
                )}
              </span>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', fontStyle:'italic', padding:'4px 0' }}>
          {edition.total_copies} copies owned, but individual scores aren't numbered yet · click "Add copies" to track them
        </div>
      )}

      {showLoanPicker && <LoanPicker edition={edition} />}
    </div>
  );
}

function LoanPicker({ edition }) {
  return (
    <div className="sk-box accent" style={{ padding:10, marginTop:8, background:'var(--paper)' }}>
      <Eyebrow>Lend a copy of <em style={{ fontStyle:'italic', color:'var(--ink)' }}>{edition.label}</em></Eyebrow>
      <div style={{ display:'grid', gridTemplateColumns:'90px 1fr 1fr auto', gap:8, marginTop:6, alignItems:'center' }}>
        <div>
          <div style={{ fontSize:9, fontFamily:'Inter', color:'var(--ink3)' }}>Copy</div>
          <div className="sk-box" style={{ padding:'3px 8px', fontFamily:'Inter', fontSize:11, fontWeight:600 }}>#27 ▾</div>
        </div>
        <div>
          <div style={{ fontSize:9, fontFamily:'Inter', color:'var(--ink3)' }}>Borrower (roster member)</div>
          <div className="sk-box" style={{ padding:'3px 8px', fontFamily:'Inter', fontSize:11, display:'flex', justifyContent:'space-between' }}>
            <span style={{ color:'var(--ink3)' }}>Pick from roster…</span>
            <span>▾</span>
          </div>
        </div>
        <div>
          <div style={{ fontSize:9, fontFamily:'Inter', color:'var(--ink3)' }}>Date</div>
          <div className="sk-box mono" style={{ padding:'3px 8px', fontFamily:'JetBrains Mono,monospace', fontSize:11 }}>2025-04-28</div>
        </div>
        <button className="sk-btn primary" style={{ fontSize:11 }}>Check out</button>
      </div>
    </div>
  );
}

// ─── Delete-referenced modal ────────────────────────────────────────
function DeleteReferencedModal() {
  return (
    <div style={{ position:'absolute', inset:0, background:'rgba(42,38,32,0.3)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:10 }}>
      <div className="sk-box" style={{ padding:20, maxWidth:380, background:'var(--paper)', boxShadow:'4px 4px 0 0 var(--ink3)' }}>
        <div style={{ fontFamily:'Inter', fontSize:14, fontWeight:700, marginBottom:6 }}>Can't delete — work is referenced</div>
        <div style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink2)', lineHeight:1.5 }}>
          <em>Requiem Op. 9 (Duruflé)</em> is linked to <span style={{ fontWeight:600, color:'var(--ink)' }}>2 past events</span>.
        </div>
        <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginTop:8, padding:8, background:'var(--paper2)', borderRadius:3, border:'1px dashed var(--ink4)' }}>
          → Ask a <span style={{ fontWeight:600 }}>conductor</span> to unlink events first, or archive instead.
        </div>
        <div style={{ display:'flex', gap:6, marginTop:12, justifyContent:'flex-end' }}>
          <button className="sk-btn ghost" style={{ fontSize:11 }}>Close</button>
          <button className="sk-btn" style={{ fontSize:11 }}>Notify conductor</button>
          <button className="sk-btn primary" style={{ fontSize:11 }}>Archive instead</button>
        </div>
      </div>
    </div>
  );
}

// ─── Expanded work detail ───────────────────────────────────────────
function WorkDetail({ work, showLoanPicker = false, density = 'full' }) {
  return (
    <div>
      {/* Header meta */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16, padding:'12px 14px', background:'var(--paper)', borderBottom:'1px dashed var(--ink5)' }}>
        <div>
          <Eyebrow>Metadata</Eyebrow>
          <div style={{ display:'grid', gridTemplateColumns:'80px 1fr', rowGap:3, fontFamily:'Inter', fontSize:11, marginTop:4 }}>
            <span style={{ color:'var(--ink3)' }}>Composer</span><span style={{ fontWeight:600 }}>{work.composer}</span>
            <span style={{ color:'var(--ink3)' }}>Title</span><span style={{ fontStyle:'italic' }}>{work.title}</span>
            <span style={{ color:'var(--ink3)' }}>Voicing</span><span className="mono">{work.voicing}</span>
            <span style={{ color:'var(--ink3)' }}>Language</span><span>{work.lang}</span>
            <span style={{ color:'var(--ink3)' }}>Year</span><span className="mono">{work.year}</span>
            <span style={{ color:'var(--ink3)' }}>Difficulty</span><span><Difficulty level={work.difficulty} /></span>
            <span style={{ color:'var(--ink3)' }}>Tags</span>
            <span style={{ display:'flex', gap:3, flexWrap:'wrap' }}>
              {work.tags.map((t,i)=><Chip key={i} style={{ fontSize:9, padding:'1px 6px' }}>{t}</Chip>)}
              <Chip variant="accent" style={{ fontSize:9, padding:'1px 6px', borderStyle:'dashed' }}>＋</Chip>
            </span>
          </div>
        </div>
        <div>
          <Eyebrow right={<span style={{ fontFamily:'Inter', fontSize:9, color:'var(--accent)' }}>edit</span>}>Notes · licensing doc</Eyebrow>
          <div className="sk-box" style={{
            marginTop:4, padding:8, background:'var(--paper2)',
            fontFamily:'JetBrains Mono, monospace', fontSize:10, color:'var(--ink2)',
            whiteSpace:'pre-wrap', maxHeight: density==='compact' ? 80 : 120, overflow:'hidden', lineHeight:1.45,
          }}>
            {work.notes || <em style={{ color:'var(--ink4)' }}>No notes yet. Click edit to add licensing / edition / rights information.</em>}
          </div>
        </div>
      </div>

      {/* Editions (each manages its own copies) */}
      <div style={{ padding:'12px 14px', background:'var(--paper)', borderBottom:'1px dashed var(--ink5)' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:6 }}>
          <div>
            <Eyebrow>Editions</Eyebrow>
            <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginLeft:6 }}>
              ({work.editions.length}) · copies are tracked per edition
            </span>
          </div>
          <button className="sk-btn ghost" style={{ fontSize:10 }}>＋ Add edition</button>
        </div>
        {work.editions.length > 0 ? (
          work.editions.map((e, i) => (
            <EditionBlock
              key={e.id}
              edition={e}
              defaultOpen={i === 0}
              showLoanPicker={showLoanPicker && i === 0 && e.total_copies > 0}
            />
          ))
        ) : (
          <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', fontStyle:'italic', padding:'6px 0' }}>
            No editions yet. Add one to upload the score, parts, and recordings.
          </div>
        )}
      </div>

      {/* Danger zone */}
      <div style={{ padding:'10px 14px', background:'var(--paper2)', display:'flex', justifyContent:'space-between', alignItems:'center', gap:10 }}>
        <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>
          {work.referenced
            ? <>⚠ Referenced by <span style={{ fontWeight:600, color:'var(--ink)' }}>2 past events</span> · delete requires conductor approval</>
            : <>No references · safe to delete</>}
        </div>
        <div style={{ display:'flex', gap:6 }}>
          <button className="sk-btn ghost" style={{ fontSize:10 }}>Archive</button>
          <button className="sk-btn ghost" style={{ fontSize:10, color:'var(--red)', borderColor:'var(--red)' }}>Delete</button>
        </div>
      </div>
    </div>
  );
}

// ─── Subnav ─────────────────────────────────────────────────────────
function LibrarySubnav() {
  const tabs = ['agenda', 'library', 'roster', 'notices'];
  return (
    <div style={{
      display:'flex', alignItems:'center', justifyContent:'space-between',
      padding:'8px 20px', borderBottom:'1.5px solid var(--ink5)',
      background:'var(--paper)', fontFamily:'Inter', fontSize:12,
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:14 }}>
        {tabs.map(t => {
          const active = t === 'library';
          return (
            <span key={t} style={{
              color: active ? 'var(--ink)' : 'var(--ink3)',
              fontWeight: active ? 600 : 400,
              borderBottom: active ? '2px solid var(--accent)' : '2px solid transparent',
              padding:'3px 0', textTransform:'capitalize',
              display:'flex', alignItems:'center', gap:4,
            }}>
              {t}
              {active && <span style={{
                fontSize:8, fontWeight:600, padding:'1px 4px', borderRadius:2,
                background:'var(--accent-soft)', color:'var(--accent)',
                border:'1px solid var(--accent)', letterSpacing:'0.05em',
              }}>LIBRARIAN</span>}
            </span>
          );
        })}
      </div>
      <a style={{ fontSize:11, color:'var(--ink3)' }}>
        <span className="sk-underline">View public page</span>
        <span className="mono" style={{ marginLeft:4, color:'var(--ink4)', fontSize:10 }}>/o/{OWN_CHOIR.slug} ↗</span>
      </a>
    </div>
  );
}

Object.assign(window, {
  LIBRARY, FILE_KINDS, ROSTER, workCopyStats,
  LibraryFilterBar, Difficulty, WorkRow, CopiesBadge, FileKindDots, FileRow,
  EditionBlock, EditionCopies, LoanPicker, DeleteReferencedModal,
  WorkDetail, LibrarySubnav,
});
