// Workspace primitives — signed-in member area at /members/<slug>.
// Reuses everything from SketchyPrimitives + CollectivePrimitives.
// Adds: WorkspaceNav (with choir switcher + profile), RSVP buttons,
// EventRow (own vs external treatment), RepertoireRow, MiniCalendar.

// Shared mock data so all three wireframes show the same thing --------
const OWN_CHOIR = { slug: 'kaaren-kammerkoor', name: 'Kaaren Kammerkoor', initials: 'KK' };
const OTHER_CHOIRS = [
  { slug: 'collegium-musicale', name: 'Collegium Musicale', initials: 'CM' },
  { slug: 'rae-kammerkoor', name: 'Rae Kammerkoor', initials: 'RK' },
];

// type: rehearsal | concert | sectional | tour | retreat
// rsvp: null | 'yes' | 'no' | 'maybe'
// own: true = this collective, false = external (faded, switches choir)
const AGENDA = [
  { id:1, d:28, m:'APR', dow:'Mon', time:'19:00–21:30', title:'Rehearsal · full choir',         where:'EMTA R-207',           type:'rehearsal', own:true,  rsvp:'yes',   via:null },
  { id:2, d:1,  m:'MAY', dow:'Thu', time:'19:00–21:30', title:'Rehearsal · Duruflé focus',      where:'EMTA R-207',           type:'rehearsal', own:true,  rsvp:'yes',   via:null },
  { id:3, d:2,  m:'MAY', dow:'Fri', time:'18:00–20:00', title:'Dress rehearsal',                where:'Kaarli kirik',         type:'rehearsal', own:true,  rsvp:'yes',   via:null },
  { id:4, d:3,  m:'MAY', dow:'Sat', time:'19:00',       title:'Reekviem — Duruflé',             where:'Kaarli kirik, Tallinn',type:'concert',   own:true,  rsvp:'yes',   via:null, headline:true },
  { id:5, d:8,  m:'MAY', dow:'Thu', time:'19:00–21:00', title:'Sectionals · Tenor/Bass',        where:'EMTA R-214',           type:'sectional', own:true,  rsvp:'maybe', via:null },
  { id:6, d:10, m:'MAY', dow:'Sat', time:'17:00',       title:'Spring Gala · Collegium',        where:'Estonia kontserdisaal',type:'concert',   own:false, rsvp:null,    via:'collegium-musicale', viaLabel:'Collegium Musicale' },
  { id:7, d:12, m:'MAY', dow:'Mon', time:'19:00–21:30', title:'Rehearsal · Pärt + Kreek',       where:'EMTA R-207',           type:'rehearsal', own:true,  rsvp:null,    via:null },
  { id:8, d:17, m:'MAY', dow:'Sat', time:'14:00–18:00', title:'Weekend retreat · Rae',          where:'Vihula mõis',          type:'retreat',   own:false, rsvp:'no',    via:'rae-kammerkoor', viaLabel:'Rae Kammerkoor' },
  { id:9, d:24, m:'MAY', dow:'Sat', time:'19:00',       title:'Kevadkontsert',                  where:'Mustpeade Maja',       type:'concert',   own:true,  rsvp:null,    via:null },
  { id:10,d:7,  m:'JUN', dow:'Sat', time:'19:00',       title:'Suvine õhtu',                    where:'Vanemuise, Tartu',     type:'concert',   own:true,  rsvp:null,    via:null },
];

const REPERTOIRE = [
  { composer:'Maurice Duruflé',   work:'Requiem Op. 9',             voicing:'SATB + org.',    tag:'active',    files:['score.pdf','parts.zip','rehearsal.mp3'] },
  { composer:'Arvo Pärt',         work:'Da pacem Domine',           voicing:'SATB',           tag:'active',    files:['score.pdf','rehearsal.mp3'] },
  { composer:'Cyrillus Kreek',    work:'Taaveti laul 141',          voicing:'SATB',           tag:'active',    files:['score.pdf','notes.pdf'] },
  { composer:'Urmas Sisask',      work:'Piirid',                    voicing:'SATB div.',      tag:'learning',  files:['score.pdf','rehearsal.mp3','composer-notes.pdf'] },
  { composer:'Veljo Tormis',      work:'Raua needmine',             voicing:'SATB · shamans', tag:'retired',   files:['score.pdf'] },
  { composer:'Ester Mägi',        work:'Laulud',                    voicing:'SSAA',           tag:'learning',  files:['score.pdf'] },
];

// ─── Nav ────────────────────────────────────────────────────────────
// Workspace nav: Multivox + choir switcher on the left, profile + sign out on the right.
// `openSwitcher` shows the dropdown expanded.
function WorkspaceNav({ openSwitcher = false }) {
  return (
    <div style={{
      display:'flex', alignItems:'center', justifyContent:'space-between',
      padding:'10px 20px', borderBottom:'1.5px solid var(--ink4)',
      background:'var(--paper)', position:'relative', zIndex:3,
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:14 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <span className="sk-icon" style={{ background:'var(--accent)', color:'#fff', borderColor:'var(--accent)' }}>♪</span>
          <span style={{ fontFamily:'Inter', fontWeight:600, fontSize:14 }}>Multivox</span>
        </div>
        <span style={{ color:'var(--ink4)', fontSize:14 }}>/</span>
        <ChoirSwitcher open={openSwitcher} />
      </div>
      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        <button className="sk-btn ghost" style={{ fontSize:12, position:'relative' }}>
          <span>Inbox</span>
          <span style={{ background:'var(--red)', color:'#fff', borderRadius:999, fontSize:9, padding:'0 5px', fontFamily:'Inter', fontWeight:600 }}>3</span>
        </button>
        <div style={{ display:'flex', alignItems:'center', gap:6, fontFamily:'Inter', fontSize:12, color:'var(--ink2)' }}>
          <div className="sk-icon" style={{ width:26, height:26, borderRadius:999, background:'var(--paper2)' }}>M</div>
          <span>Mari L.</span>
        </div>
        <button className="sk-btn ghost" style={{ fontSize:11 }}>Sign out</button>
      </div>
    </div>
  );
}

function ChoirSwitcher({ open }) {
  return (
    <div style={{ position:'relative' }}>
      <button className="sk-btn" style={{ fontSize:12, boxShadow:'none', padding:'4px 10px', display:'flex', alignItems:'center', gap:8 }}>
        <span className="sk-icon" style={{ width:20, height:20, fontSize:10, background:'var(--accent-soft)', borderColor:'var(--accent)', color:'var(--accent)' }}>
          {OWN_CHOIR.initials}
        </span>
        <span style={{ fontFamily:'Inter', fontWeight:600 }}>{OWN_CHOIR.name}</span>
        <span style={{ color:'var(--ink4)' }}>▾</span>
      </button>
      {open && (
        <div className="sk-box" style={{
          position:'absolute', top:'calc(100% + 6px)', left:0, minWidth:240, padding:6,
          background:'var(--paper)', boxShadow:'3px 3px 0 0 var(--ink3)', zIndex:4,
        }}>
          <div style={{ fontFamily:'Inter', fontSize:9, fontWeight:600, letterSpacing:'0.12em', color:'var(--ink4)', padding:'4px 8px' }}>YOUR CHOIRS</div>
          {[OWN_CHOIR, ...OTHER_CHOIRS].map((c, i) => (
            <div key={c.slug} style={{
              display:'flex', alignItems:'center', gap:8, padding:'6px 8px',
              background: i===0 ? 'var(--accent-soft)' : 'transparent',
              borderRadius:3, fontFamily:'Inter', fontSize:12,
            }}>
              <span className="sk-icon" style={{ width:22, height:22, fontSize:10 }}>{c.initials}</span>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontWeight: i===0?600:500, color:'var(--ink)' }}>{c.name}</div>
                <div style={{ fontSize:9, color:'var(--ink4)' }} className="mono">/members/{c.slug}</div>
              </div>
              {i===0 && <span className="mono" style={{ fontSize:9, color:'var(--accent)' }}>active</span>}
            </div>
          ))}
          <div style={{ borderTop:'1px dashed var(--ink5)', margin:'4px 0' }} />
          <div style={{ padding:'6px 8px', fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
            <span className="sk-underline">Find a choir →</span>
          </div>
        </div>
      )}
    </div>
  );
}

// Sub-nav: breadcrumb + link to public page + section tabs -----------
function WorkspaceSubnav({ active = 'agenda' }) {
  const tabs = ['agenda', 'library', 'roster', 'notices'];
  return (
    <div style={{
      display:'flex', alignItems:'center', justifyContent:'space-between',
      padding:'8px 20px', borderBottom:'1.5px solid var(--ink5)',
      background:'var(--paper)', fontFamily:'Inter', fontSize:12,
    }}>
      <div style={{ display:'flex', alignItems:'center', gap:14 }}>
        {tabs.map(t => (
          <span key={t} style={{
            color: active===t ? 'var(--ink)' : 'var(--ink3)',
            fontWeight: active===t ? 600 : 400,
            borderBottom: active===t ? '2px solid var(--accent)' : '2px solid transparent',
            padding:'3px 0', textTransform:'capitalize',
          }}>{t}</span>
        ))}
      </div>
      <a style={{ fontSize:11, color:'var(--ink3)' }}>
        <span className="sk-underline">View public page</span>
        <span className="mono" style={{ marginLeft:4, color:'var(--ink4)', fontSize:10 }}>/o/{OWN_CHOIR.slug} ↗</span>
      </a>
    </div>
  );
}

// ─── RSVP ────────────────────────────────────────────────────────────
function RSVP({ state, compact = false, external = false }) {
  const opts = [
    { key:'yes',   label:'Yes',   color:'#2f7a4f' },
    { key:'maybe', label:'Maybe', color:'#b8861a' },
    { key:'no',    label:'No',    color:'#c84b3a' },
  ];
  const sz = compact ? { pad:'2px 7px', fs:10 } : { pad:'3px 10px', fs:11 };
  return (
    <div style={{ display:'flex', gap:4, opacity: external ? 0.8 : 1 }}>
      {opts.map(o => {
        const on = state === o.key;
        return (
          <span key={o.key} style={{
            padding: sz.pad, fontSize: sz.fs, fontFamily:'Inter',
            border: external ? '1px dashed' : '1.25px solid',
            borderColor: on ? o.color : 'var(--ink4)',
            color: on ? '#fff' : 'var(--ink3)',
            background: on ? o.color : 'var(--paper)',
            borderRadius:3, fontWeight: on ? 600 : 400,
          }}>{o.label}</span>
        );
      })}
    </div>
  );
}

// ─── Event row ───────────────────────────────────────────────────────
function EventRow({ ev, compact = false }) {
  const isOwn = ev.own;
  const typeColors = {
    rehearsal: 'var(--ink3)',
    concert:   'var(--accent)',
    sectional: '#8a6a2e',
    retreat:   '#6a5a8a',
    tour:      '#2f7a4f',
  };
  return (
    <div style={{
      display:'flex', gap:12, padding: compact ? '8px 0' : '10px 0',
      borderBottom:'1px dashed var(--ink5)',
      opacity: isOwn ? 1 : 0.72,
      position:'relative',
    }}>
      {/* Date chip */}
      <div className="sk-box" style={{
        width: compact ? 40 : 46, textAlign:'center', padding:'3px 0', flexShrink:0,
        borderStyle: isOwn ? 'solid' : 'dashed',
        borderColor: isOwn ? 'var(--ink3)' : 'var(--ink4)',
        background: isOwn ? 'var(--paper)' : 'transparent',
      }}>
        <div style={{ fontFamily:'Inter', fontSize:9, fontWeight:600, color: isOwn ? 'var(--accent)' : 'var(--ink4)', letterSpacing:'0.1em' }}>{ev.m}</div>
        <div style={{ fontFamily:'Inter', fontSize: compact?16:18, fontWeight:700, lineHeight:1, color:'var(--ink)' }}>{String(ev.d).padStart(2,'0')}</div>
        <div style={{ fontFamily:'Inter', fontSize:8, color:'var(--ink4)', marginTop:2 }}>{ev.dow}</div>
      </div>

      {/* Details */}
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ display:'flex', gap:6, alignItems:'center', flexWrap:'wrap' }}>
          <span style={{
            fontFamily:'Inter', fontSize: compact?12:13, fontWeight:600,
            color: isOwn ? 'var(--ink)' : 'var(--ink2)',
          }}>{ev.title}</span>
          <span style={{
            fontFamily:'Inter', fontSize:9, fontWeight:600, letterSpacing:'0.08em',
            color: typeColors[ev.type], textTransform:'uppercase',
            padding:'1px 6px', border:`1px solid ${typeColors[ev.type]}`, borderRadius:3,
          }}>{ev.type}</span>
          {!isOwn && (
            <span style={{
              fontFamily:'Inter', fontSize:10, color:'var(--ink3)',
              background:'var(--paper2)', padding:'1px 7px', borderRadius:999,
              border:'1px dashed var(--ink4)',
            }}>
              via <span className="sk-underline" style={{ color:'var(--accent)' }}>{ev.viaLabel}</span> ↗
            </span>
          )}
        </div>
        <div style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink3)', marginTop:2 }}>
          <span className="mono" style={{ color:'var(--ink2)' }}>{ev.time}</span>
          <span style={{ margin:'0 5px' }}>·</span>
          <span>{ev.where}</span>
        </div>
      </div>

      {/* RSVP */}
      <div style={{ flexShrink:0, alignSelf:'center' }}>
        <RSVP state={ev.rsvp} compact={compact} external={!isOwn} />
      </div>
    </div>
  );
}

// ─── Repertoire row ──────────────────────────────────────────────────
function RepertoireRow({ item }) {
  const tagColors = {
    active:   { bg:'var(--accent-soft)', fg:'var(--accent)',  border:'var(--accent)' },
    learning: { bg:'#fff2d9',            fg:'#8a6a2e',        border:'#b8861a' },
    retired:  { bg:'var(--paper2)',      fg:'var(--ink4)',    border:'var(--ink4)' },
  };
  const tc = tagColors[item.tag];
  return (
    <div style={{ display:'flex', gap:10, padding:'9px 0', borderBottom:'1px dashed var(--ink5)', alignItems:'flex-start' }}>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink)' }}>
          <span style={{ fontWeight:600 }}>{item.composer}</span>
          <span style={{ color:'var(--ink3)' }}> — </span>
          <span style={{ fontStyle:'italic' }} className="sk-underline">{item.work}</span>
        </div>
        <div style={{ display:'flex', gap:8, alignItems:'center', marginTop:3 }}>
          <span className="mono" style={{ fontSize:10, color:'var(--ink3)' }}>{item.voicing}</span>
          <span style={{
            fontFamily:'Inter', fontSize:9, fontWeight:600, letterSpacing:'0.08em', textTransform:'uppercase',
            padding:'1px 6px', borderRadius:3,
            background: tc.bg, color: tc.fg, border:`1px solid ${tc.border}`,
          }}>{item.tag}</span>
        </div>
      </div>
      <div style={{ display:'flex', gap:4, flexShrink:0 }}>
        {item.files.map((f, i) => {
          const ext = f.split('.').pop();
          return (
            <span key={i} className="sk-chip filled" style={{ fontSize:10, padding:'2px 7px', color:'var(--ink2)' }}>
              <span style={{ color:'var(--accent)' }}>↓</span>
              <span className="mono" style={{ fontSize:9 }}>{ext}</span>
            </span>
          );
        })}
      </div>
    </div>
  );
}

// ─── External filter toggle ──────────────────────────────────────────
function ExternalToggle({ on = false }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:6, fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
      <span style={{
        width:28, height:16, borderRadius:999, border:'1px solid var(--ink4)',
        background: on ? 'var(--accent)' : 'var(--paper2)', position:'relative', display:'inline-block',
      }}>
        <span style={{
          position:'absolute', top:1, left: on ? 13 : 1,
          width:12, height:12, background:'#fff', borderRadius:999, border:'1px solid var(--ink4)',
        }} />
      </span>
      <span>Include rehearsals from other choirs</span>
    </div>
  );
}

// ─── Mini month calendar ─────────────────────────────────────────────
// May 2025 — Thursday 1st. Pills show events; own vs external styled differently.
function MiniMonth({ selectedId }) {
  // 5 weeks × 7 days. Grey out days that aren't in May.
  // We'll mark each day with a dot per event on that date.
  const days = [];
  for (let i=0;i<35;i++){
    const dayNum = i - 3; // May 1 starts on Thursday (i=3)
    const inMonth = dayNum >= 1 && dayNum <= 31;
    days.push({ i, num: inMonth ? dayNum : null });
  }
  const evByDay = {};
  AGENDA.filter(e=>e.m==='MAY').forEach(e => {
    (evByDay[e.d] ??= []).push(e);
  });
  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
        <div style={{ fontFamily:'Inter', fontSize:14, fontWeight:700 }}>May 2025</div>
        <div style={{ display:'flex', gap:4 }}>
          <span className="sk-icon" style={{ width:22, height:22, fontSize:11 }}>‹</span>
          <span className="sk-icon" style={{ width:22, height:22, fontSize:11 }}>›</span>
        </div>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:2, fontFamily:'Inter', fontSize:9, color:'var(--ink4)', marginBottom:3 }}>
        {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(d => <div key={d} style={{ textAlign:'center' }}>{d}</div>)}
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:3 }}>
        {days.map(({ i, num }) => {
          const evs = num ? (evByDay[num] || []) : [];
          const hasOwn = evs.some(e=>e.own);
          const hasExt = evs.some(e=>!e.own);
          const isSel = evs.some(e=>e.id===selectedId);
          return (
            <div key={i} style={{
              aspectRatio:'1', border:'1px solid var(--ink5)', borderRadius:3,
              padding:'3px 4px', background: num ? (isSel ? 'var(--accent-soft)' : 'var(--paper)') : 'transparent',
              opacity: num ? 1 : 0.3, position:'relative', minHeight:44,
              borderColor: isSel ? 'var(--accent)' : 'var(--ink5)',
            }}>
              <div style={{ fontSize:10, fontFamily:'Inter', color:'var(--ink2)', fontWeight: isSel?700:400 }}>{num}</div>
              <div style={{ display:'flex', gap:2, flexWrap:'wrap', marginTop:2 }}>
                {evs.slice(0,3).map(e => (
                  <span key={e.id} style={{
                    display:'block', width:'100%', height:4, borderRadius:2,
                    background: e.own ? (e.type==='concert'?'var(--accent)':'var(--ink3)') : 'transparent',
                    border: e.own ? 'none' : '1px dashed var(--ink4)',
                  }} />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Week legend ─────────────────────────────────────────────────────
function Legend() {
  return (
    <div style={{ display:'flex', gap:12, fontFamily:'Inter', fontSize:10, color:'var(--ink3)', flexWrap:'wrap' }}>
      <span style={{ display:'flex', alignItems:'center', gap:5 }}>
        <span style={{ width:10, height:10, background:'var(--accent)', borderRadius:2 }} />
        Concert
      </span>
      <span style={{ display:'flex', alignItems:'center', gap:5 }}>
        <span style={{ width:10, height:10, background:'var(--ink3)', borderRadius:2 }} />
        Rehearsal
      </span>
      <span style={{ display:'flex', alignItems:'center', gap:5 }}>
        <span style={{ width:10, height:10, border:'1px dashed var(--ink4)', borderRadius:2 }} />
        From another choir
      </span>
    </div>
  );
}

Object.assign(window, {
  OWN_CHOIR, OTHER_CHOIRS, AGENDA, REPERTOIRE,
  WorkspaceNav, WorkspaceSubnav, ChoirSwitcher,
  RSVP, EventRow, RepertoireRow, ExternalToggle, MiniMonth, Legend,
});
