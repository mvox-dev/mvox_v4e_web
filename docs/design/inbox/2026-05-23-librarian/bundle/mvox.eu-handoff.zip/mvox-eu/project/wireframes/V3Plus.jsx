// V3+ — Season-led, evolved.
// Keeps V3's poster hero, timeline, and season repertoire.
// Adds from V2: compact identity strip with name + global search bar.
// New: "Next up" feature block calling out the most imminent own project.

function V3Plus() {
  return (
    <BrowserFrame url="mvox.eu/o/eesti-segakooride-liit">
      <div className="sk" style={{ height: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <RegistryNav />

        {/* Identity + search strip (lent from V2) */}
        <div style={{ padding: '12px 32px', borderBottom: '1.5px solid var(--ink5)', display: 'flex', alignItems: 'center', gap: 14, background: 'var(--paper)' }}>
          <div className="sk-hatch" style={{ width: 36, height: 36, border: '1.5px solid var(--ink3)', borderRadius: 6, flexShrink: 0 }} />
          <div style={{ minWidth: 0 }}>
            <div style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 17, color: 'var(--ink)', lineHeight: 1.1, letterSpacing: '-0.01em' }}>Eesti Segakooride Liit</div>
            <div style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)' }}>
              Umbrella · 24 member choirs · since 1962
            </div>
          </div>
          <div className="sk-box" style={{ flex: 1, padding: '6px 12px', background: 'var(--paper2)', fontFamily: 'Inter', fontSize: 12, color: 'var(--ink4)', margin: '0 8px' }}>
            🔍  Search this umbrella — concerts, repertoire, member choirs…
          </div>
          <button className="sk-btn ghost" style={{ fontSize: 12 }}>About</button>
          <button className="sk-btn primary" style={{ fontSize: 13 }}>Contact</button>
        </div>

        {/* Poster-style season hero + "Next up" feature */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', borderBottom: '1.5px solid var(--ink4)' }}>
          <div style={{ padding: '22px 32px', background: 'var(--paper)', position: 'relative' }}>
            <Eyebrow>Current season · 2025/26</Eyebrow>
            <div style={{
              fontFamily: 'Inter', fontWeight: 800, fontSize: 36, lineHeight: 1.05,
              color: 'var(--ink)', margin: '6px 0 4px', letterSpacing: '-0.02em',
            }}>
              Valgus <span style={{ color: 'var(--accent)' }}>&amp;</span> vari
            </div>
            <div style={{ fontFamily: 'Inter', fontSize: 12, color: 'var(--ink3)', fontStyle: 'italic', marginBottom: 8 }}>
              Light and shadow — a season on Estonian sacred choral tradition
            </div>
            <Lines count={2} widths={['long', 'med']} />

            {/* NEXT UP card — the most imminent own project */}
            <div className="sk-box accent" style={{ marginTop: 14, padding: 12, background: 'var(--paper)' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                <Eyebrow style={{ color: 'var(--accent)' }}>Next up · our own project</Eyebrow>
                <span style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)' }}>in 11 days</span>
              </div>
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                <div style={{ textAlign: 'center', flexShrink: 0 }}>
                  <div style={{ fontFamily: 'Inter', fontSize: 10, fontWeight: 600, color: 'var(--accent)', letterSpacing: '0.1em' }}>JUN</div>
                  <div style={{ fontFamily: 'Inter', fontSize: 34, fontWeight: 800, color: 'var(--ink)', lineHeight: 1, letterSpacing: '-0.03em' }}>02</div>
                  <div style={{ fontFamily: 'Inter', fontSize: 9, color: 'var(--ink3)' }}>Tue · 19:00</div>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: 'Inter', fontSize: 16, fontWeight: 700, color: 'var(--ink)', marginBottom: 2 }}>
                    Ühislaul — all members together
                  </div>
                  <div style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)' }}>
                    Tartu Jaani kirik · 12 member choirs joining
                  </div>
                  <div style={{ display: 'flex', gap: 5, marginTop: 6 }}>
                    <Chip variant="accent" style={{ fontSize: 10, padding: '1px 7px' }}>festival</Chip>
                    <Chip style={{ fontSize: 10, padding: '1px 7px' }}>free entry</Chip>
                    <Chip style={{ fontSize: 10, padding: '1px 7px' }}>↗ tickets</Chip>
                  </div>
                </div>
              </div>
            </div>
            <Annot style={{ position: 'absolute', bottom: -4, right: 20 }}>→ imminent own project</Annot>
          </div>
          <div className="sk-hatch" style={{ position: 'relative', minHeight: 200, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ fontFamily: 'Caveat', fontSize: 15, color: 'var(--ink3)', textAlign: 'center' }}>
              season artwork<br/><span style={{ fontSize: 11, color: 'var(--ink4)' }}>(poster / key image)</span>
            </div>
          </div>
        </div>

        {/* Main grid */}
        <div style={{ flex: 1, overflow: 'hidden', padding: '18px 32px', display: 'grid', gridTemplateColumns: '1fr 1fr 240px', gap: 22, minHeight: 0 }}>

          {/* Upcoming concerts (excluding the next up already featured) */}
          <div style={{ overflow: 'hidden' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
              <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 14, margin: 0 }}>More upcoming</h2>
              <span style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--accent)' }} className="sk-underline">Full calendar →</span>
            </div>
            {[
              ['MAY', '03', 'Reekviem', 'Collegium Musicale + TKK', 'concert'],
              ['MAY', '18', 'Kevadkontsert', 'Eesti Filh. Kammerkoor', 'concert'],
              ['JUN', '21', 'Suvepäevad', 'All members — retreat', 'retreat'],
              ['AUG', '09', 'Noortepäev', '6 youth choirs', 'festival'],
            ].map(([mo, d, title, who, kind], i) => (
              <div key={i} style={{ display: 'flex', gap: 10, padding: '7px 0', borderBottom: '1px dashed var(--ink5)' }}>
                <div className="sk-box" style={{ width: 38, textAlign: 'center', padding: '3px 0', flexShrink: 0 }}>
                  <div style={{ fontFamily: 'Inter', fontSize: 8, fontWeight: 600, color: 'var(--accent)', letterSpacing: '0.1em' }}>{mo}</div>
                  <div style={{ fontFamily: 'Inter', fontSize: 16, fontWeight: 700, color: 'var(--ink)', lineHeight: 1 }}>{d}</div>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                    <span style={{ fontFamily: 'Inter', fontSize: 12, fontWeight: 600, color: 'var(--ink)' }}>{title}</span>
                    <Chip style={{ fontSize: 9, padding: '0 5px' }}>{kind}</Chip>
                  </div>
                  <div style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)' }}>{who}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Umbrella-published repertoire */}
          <div style={{ overflow: 'hidden' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
              <h2 style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 14, margin: 0 }}>
                Season repertoire
                <span style={{ fontWeight: 400, color: 'var(--ink3)', fontSize: 11 }}> · published by umbrella</span>
              </h2>
              <span style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--accent)' }} className="sk-underline">Full list (42) →</span>
            </div>
            {[
              ['Pärt', 'Da pacem Domine', 'SATB', 12],
              ['Tormis', 'Raua needmine', 'SATB + solo', 4],
              ['Kreek', 'Taaveti laul 141', 'SATB', 18],
              ['Tüür', 'Meditatio', 'SSAATTBB', 3],
              ['Sisask', 'Gloria Patri', 'SATB', 9],
              ['Eespere', 'Ärkamine', 'SATB', 7],
            ].map(([composer, work, voicing, choirs], i) => (
              <div key={i} style={{ padding: '6px 0', borderBottom: '1px dashed var(--ink5)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 6 }}>
                  <div style={{ minWidth: 0 }}>
                    <span style={{ fontFamily: 'Inter', fontSize: 12, fontWeight: 600, color: 'var(--ink)' }}>{composer}</span>
                    <span style={{ fontFamily: 'Inter', fontSize: 12, color: 'var(--ink2)' }}> — </span>
                    <span className="sk-underline" style={{ fontFamily: 'Inter', fontSize: 12, color: 'var(--accent)' }}>{work}</span>
                  </div>
                  <span className="mono" style={{ fontSize: 10, color: 'var(--ink3)', flexShrink: 0 }}>{voicing}</span>
                </div>
                <div style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)', marginTop: 2, display: 'flex', gap: 8 }}>
                  <span>performed by {choirs} choirs</span>
                  <span style={{ color: 'var(--ink4)' }}>·</span>
                  <span className="sk-underline" style={{ color: 'var(--accent)' }}>PDF</span>
                  <span className="sk-underline" style={{ color: 'var(--accent)' }}>recording</span>
                </div>
              </div>
            ))}
            <Annot style={{ marginTop: 8, display: 'block' }}>umbrella curates; member choirs can adopt</Annot>
          </div>

          {/* Right rail */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="sk-box soft" style={{ padding: 10 }}>
              <Eyebrow style={{ marginBottom: 6 }}>24 member choirs</Eyebrow>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
                {Array.from({ length: 11 }).map((_, i) => (
                  <div key={i} className="sk-hatch" style={{ width: 22, height: 22, borderRadius: '50%', border: '1px solid var(--ink4)' }} />
                ))}
                <div className="sk-box" style={{ width: 22, height: 22, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Inter', fontSize: 9, color: 'var(--ink3)' }}>+13</div>
              </div>
              <div className="sk-underline" style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--accent)', marginTop: 6, display: 'inline-block' }}>Browse all →</div>
            </div>
            <div className="sk-box" style={{ padding: 10, background: 'var(--paper)' }}>
              <Eyebrow style={{ marginBottom: 6 }}>About</Eyebrow>
              <Lines count={2} widths={['long', 'med']} />
              <div style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)', marginTop: 6 }}>
                est. 1962 · Tallinn · <span style={{ color: 'var(--accent)' }} className="sk-underline">esl.ee</span>
              </div>
            </div>
            <div className="sk-box dashed" style={{ padding: 10 }}>
              <Eyebrow style={{ marginBottom: 6 }}>Press kit</Eyebrow>
              <div style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)', lineHeight: 1.5 }}>
                Logos · bios · photos<br/>
                <span className="mono" style={{ color: 'var(--accent)' }}>press@esl.ee</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.V3Plus = V3Plus;
