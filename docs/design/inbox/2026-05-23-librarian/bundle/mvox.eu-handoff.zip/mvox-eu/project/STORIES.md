# Multivox — User Stories

> **Audience:** humans driving design and engineering.
> **Companion files:** `SPEC.md` (rules & domain), `schema.ts` (shapes).
> **Format:** "As a *<role>*, I want *<capability>* so that *<outcome>*." Acceptance notes follow each story as a short bulleted list.
> **Status legend:** 🟢 designed · 🟡 in design · ⚪ parked · 🔴 needs decision

---

## Roles

- **Singer** — rank-and-file member of one or more choirs.
- **Section lead** — singer with light coordination duties for their voice section.
- **Conductor** — artistic lead of a choir; usually owns programmes & repertoire.
- **Manager / admin** — handles logistics, calendar, cross-choir relationships.
- **Guest** — singer attending another choir's event via "Open to attend".

---

## Epic A — Members workspace (the singer's home)

### A1 🟢 See my season at a glance
**As a** singer, **I want** a single page showing my upcoming events and current repertoire, **so that** I don't have to chase WhatsApp threads or shared sheets.

- Agenda + repertoire side by side
- Grouped by week
- Today's / next event is visually prominent

### A2 🟢 Respond to RSVPs in one click
**As a** singer, **I want** to set my RSVP without leaving the agenda, **so that** answering is friction-free.

- Open-RSVP rows show inline Yes / Maybe / No buttons
- Amber accent draws the eye to rows still needing a response
- Already-answered rows show a subtle dot, not a CTA

### A3 🟡 Change my mind about an RSVP
**As a** singer, **I want** to update my RSVP up until shortly before an event, **so that** life can change without penalty.

- Click an answered dot to re-open the choice
- TODO: lockout window (24h before? configurable?)

### A4 ⚪ See my attendance history
**As a** singer, **I want** to see my own attendance pattern over the season, **so that** I can self-assess.

---

## Epic B — Cross-choir attendance ("Open to attend")

### B1 🟢 Discover events I can join from other choirs
**As a** singer, **I want** events from partner choirs to appear in my agenda, **so that** I learn about guest opportunities without a separate inbox.

- Cross-choir rows appear inline, visually demoted (gray, dashed dot)
- "Open to attend" pill on rows where I can opt in
- "N from <my choir> going" social proof

### B2 🟡 Opt in to attend another choir's event
**As a** singer, **I want** to register as a guest for a cross-choir event, **so that** I can show up and sing.

- Details panel with venue, programme, prep notes, attendees
- Attend button → Confirmed (auto) or Pending (manual approval)
- Guest does NOT become a member of host choir

### B3 🔴 Be warned about conflicts
**As a** singer, **I want** to be warned when a guest event conflicts with an own-choir Yes RSVP, **so that** I don't double-book.

- Conflict warning visible on the cross-choir row + in the Attend confirmation
- TODO: how strict — block, warn, or both?

### B4 🟡 Share my event with partner choirs
**As a** conductor, **I want** to share an event with a chosen audience, **so that** I can fill seats / find ringers / build community.

- Audience scope: private · partner list · regional · public link
- Capacity (optional)
- Guest access level: observe · sing along · sing + scores
- Approval: auto or manual

### B5 ⚪ See reciprocity with partner choirs
**As a** conductor, **I want** to see how many singers I've sent vs received with each partner choir, **so that** I keep relationships balanced.

---

## Epic C — Repertoire & programmes

### C1 🟢 See what we're currently working on
**As a** singer, **I want** the active programme(s) and their works visible alongside the agenda, **so that** I know what to practice.

- Programmes grouped by performance date
- Each work tagged: learning · active · retired
- Programme readiness indicator

### C2 🟡 Access scores and recordings for active works
**As a** singer, **I want** to open the score / reference recording from the work row, **so that** I can prepare without hunting.

- TODO: hosting model (uploaded PDFs vs external links vs both)

### C3 🟡 Curate the programme
**As a** conductor, **I want** to add/remove works from a programme and change their status, **so that** I shape what we're rehearsing.

### C4 ⚪ Programme history
**As a** conductor, **I want** to see what we performed each season, **so that** I avoid recent repeats and build narrative arcs.

---

## Epic D — Identity & multi-choir membership

### D1 🔴 One account, many choirs
**As a** singer in multiple choirs, **I want** a single Multivox account that gives me access to each choir's workspace, **so that** I'm not juggling logins.

- TODO: workspace switcher UX
- TODO: do notifications collapse across choirs or stay separate?

### D2 🔴 Roles per choir
**As a** user, **I want** my role (singer/conductor/admin) to be specific to each choir I belong to, **so that** I can be a singer in choir A and conductor in choir B without confusion.

---

## Epic E — Notifications (parked)

### E1 ⚪ Digest of upcoming events + RSVP nudges
### E2 ⚪ Direct mention from conductor / section lead
### E3 ⚪ Guest-attendance approval/rejection notice

---

*Update protocol: when we lock a story's design, flip its status to 🟢 and link the screen / artboard label that shipped it. When a new story emerges in conversation, add it here before mocking it.*
