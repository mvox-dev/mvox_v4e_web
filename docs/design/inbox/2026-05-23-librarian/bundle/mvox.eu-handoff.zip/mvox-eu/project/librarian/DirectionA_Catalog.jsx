// Direction A — "The Catalog Page"
// Editorial. Looks like a printed librarian's day-page from a bibliographic catalog.
// Generous margins, marginalia in red, three tasks rendered as numbered entries,
// holdings list ruled out below. Single column ~720px, right gutter for annotations.

function DirectionA_Catalog() {
  const stats = libStats();
  const overdueTask = TASKS.find(t => t.id === 'overdue');
  const returnsTask = TASKS.find(t => t.id === 'returns');
  const pullTask    = TASKS.find(t => t.id === 'pull');

  const tallisWork = workById('tallis-spem');
  const partWork   = workById('part-magnificat');

  // Twelve copies of Tallis · #01–#12 — 8 already ticked, 4 to confirm.
  // We render them as a 12-cell grid of pencil checkboxes.
  const tallisCopies = Array.from({ length: 12 }, (_, i) => ({
    n: String(i + 1).padStart(2, '0'),
    checked: i < 8,
  }));

  return (
    <div className="sk lb-paper" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column' }}>
      <MvoxNav active="library" />

      {/* Page heading band */}
      <div style={{ padding:'18px 64px 8px', borderBottom:'1.5px solid var(--ink5)' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', gap:24 }}>
          <div>
            <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.16em', textTransform:'uppercase', color:'var(--ink3)', fontWeight:600 }}>
              Library  ·  Librarian's working page
            </div>
            <h1 style={{
              margin:'4px 0 0', fontFamily:'Caveat, cursive', fontWeight:700,
              fontSize:64, lineHeight:0.9, color:'var(--ink)', letterSpacing:'-0.01em',
            }}>
              Tuesday afternoon
            </h1>
          </div>
          <div style={{ textAlign:'right', fontFamily:'Inter', fontSize:11, color:'var(--ink3)', lineHeight:1.5 }}>
            <div><span style={{ color:'var(--ink2)' }}>{TODAY.date}</span> · {TODAY.time}</div>
            <div className="lb-margin" style={{ fontSize:18, marginTop:2 }}>
              Rehearsal in <span style={{ fontWeight:700, color:'var(--red)' }}>90 min</span> &middot; 48 singers
            </div>
          </div>
        </div>
      </div>

      {/* Body grid: index spine | main page | right margin */}
      <div style={{ flex:1, overflow:'hidden', display:'grid', gridTemplateColumns:'160px 1fr 240px' }}>

        {/* Left index spine — A–Z + filters */}
        <aside style={{
          padding:'24px 16px', borderRight:'1.5px solid var(--ink5)',
          background:'var(--paper)', overflowY:'auto',
        }}>
          <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.16em', textTransform:'uppercase', color:'var(--ink3)', marginBottom:10, fontWeight:600 }}>
            Index
          </div>
          <PencilSearch placeholder="Search…" hint="⌘K" style={{ padding:'5px 8px', marginBottom:14 }} />
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:2, marginBottom:18 }}>
            {'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(l => (
              <span key={l} style={{
                fontFamily:'Caveat, cursive', fontSize:16, textAlign:'center',
                padding:'2px 0',
                color: ['B','E','H','K','L','N','P','T','V','W'].includes(l) ? 'var(--ink)' : 'var(--ink5)',
                fontWeight: ['T','P','K','E'].includes(l) ? 700 : 400,
                cursor:'pointer',
              }}>{l}</span>
            ))}
          </div>
          <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em', textTransform:'uppercase', color:'var(--ink3)', marginBottom:6, fontWeight:600 }}>
            Period
          </div>
          {['Medieval','Renaissance','Baroque','Classical','Romantic','20th century','Contemporary'].map(p => (
            <div key={p} style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink2)', padding:'2px 0', display:'flex', justifyContent:'space-between' }}>
              <span>{p}</span>
              <span className="mono" style={{ color:'var(--ink4)' }}>{Math.floor(Math.random()*12)+1}</span>
            </div>
          ))}
          <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em', textTransform:'uppercase', color:'var(--ink3)', margin:'14px 0 6px', fontWeight:600 }}>
            Language
          </div>
          {['Estonian','Latin','English','Latvian','Ukrainian','German','French'].map(p => (
            <div key={p} style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink2)', padding:'2px 0', display:'flex', justifyContent:'space-between' }}>
              <span>{p}</span>
              <span className="mono" style={{ color:'var(--ink4)' }}>{Math.floor(Math.random()*8)+1}</span>
            </div>
          ))}

          <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em', textTransform:'uppercase', color:'var(--ink3)', margin:'14px 0 6px', fontWeight:600 }}>
            Status
          </div>
          {[
            { label:'On loan',  v: stats.on_loan, tone:'amber' },
            { label:'Overdue',  v: stats.overdue, tone:'red'   },
            { label:'Returned today', v: 12,      tone:'green' },
          ].map(s => (
            <div key={s.label} style={{ display:'flex', justifyContent:'space-between', fontFamily:'Inter', fontSize:12, color:'var(--ink2)', padding:'2px 0' }}>
              <span><StatusDot tone={s.tone} />{s.label}</span>
              <span className="mono" style={{ color:'var(--ink4)' }}>{s.v}</span>
            </div>
          ))}
        </aside>

        {/* Main column — three task entries + holdings */}
        <main style={{ overflowY:'auto', padding:'24px 56px 60px', position:'relative' }}>

          {/* Task 1 — Returns */}
          <section style={{ marginBottom:36 }}>
            <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:14 }}>
              <Rank n="1" />
              <div style={{ flex:1 }}>
                <h2 style={{
                  margin:0, fontFamily:'Caveat, cursive', fontSize:36, fontWeight:700,
                  letterSpacing:'-0.01em', color:'var(--ink)',
                }}>
                  Mark twelve Tallis returned
                </h2>
                <div style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink3)', marginTop:2 }}>
                  <em style={{ fontStyle:'italic', color:'var(--ink2)' }}>Spem in alium</em> · 40-part original (Chester Novello, 1928) · came back from December concert
                </div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div className="lb-tally" style={{ fontSize:46 }}>8<span style={{ color:'var(--ink4)', fontSize:24 }}>/12</span></div>
                <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--ink3)' }}>copies ticked</div>
              </div>
            </div>

            <div style={{
              padding:'18px 22px',
              border:'1.5px solid var(--ink2)',
              background:'var(--paper)',
              borderRadius:4,
              position:'relative',
            }}>
              <div style={{
                position:'absolute', top:-10, left:18,
                background:'var(--paper)', padding:'0 8px',
                fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em',
                textTransform:'uppercase', color:'var(--ink3)', fontWeight:600,
              }}>
                Copy ledger · #01 – #12
              </div>

              <div style={{ display:'grid', gridTemplateColumns:'repeat(12, 1fr)', gap:8, marginBottom:14 }}>
                {tallisCopies.map(c => (
                  <div key={c.n} style={{
                    border:'1px dashed var(--ink5)', borderRadius:3,
                    padding:'10px 4px', textAlign:'center', background:'var(--paper)',
                  }}>
                    <PencilCheckbox checked={c.checked} />
                    <div style={{ fontFamily:'JetBrains Mono', fontSize:10, color:c.checked ? 'var(--ink3)' : 'var(--ink)', marginTop:4 }}>
                      <span className={c.checked ? 'lb-strike' : ''}>#{c.n}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:12, fontFamily:'Inter', fontSize:12, color:'var(--ink3)' }}>
                <div>
                  <span>Returned today: </span>
                  <span style={{ color:'var(--ink), fontWeight:600' }}>Maris Tamm, Liina Saar, Margus Roos, Henn Kuusik · </span>
                  <em style={{ color:'var(--ink4)' }}>(handed off as one folder)</em>
                </div>
                <div style={{ display:'flex', gap:8 }}>
                  <button className="sk-btn ghost" style={{ fontSize:11 }}>Open detail</button>
                  <button className="sk-btn primary" style={{ fontSize:11 }}>Confirm last 4 ✓</button>
                </div>
              </div>
            </div>
          </section>

          {/* Task 2 — Overdue */}
          <section style={{ marginBottom:36 }}>
            <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:14 }}>
              <Rank n="2" tone="warn" />
              <div style={{ flex:1 }}>
                <h2 style={{
                  margin:0, fontFamily:'Caveat, cursive', fontSize:36, fontWeight:700,
                  letterSpacing:'-0.01em', color:'var(--ink)',
                }}>
                  Chase the Pärt copies
                </h2>
                <div style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink3)', marginTop:2 }}>
                  <em style={{ fontStyle:'italic', color:'var(--ink2)' }}>Magnificat</em> · Universal Edition 1989 · still out with two basses since November
                </div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div className="lb-tally lb-tally-red" style={{ fontSize:46 }}>4</div>
                <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--red)' }}>copies overdue</div>
              </div>
            </div>

            <div style={{
              padding:'14px 22px',
              border:'1.5px solid var(--red)',
              borderRadius:4,
              background:'var(--paper)',
              position:'relative',
            }}>
              <div style={{
                position:'absolute', top:-10, left:18,
                background:'var(--paper)', padding:'0 8px',
                fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em',
                textTransform:'uppercase', color:'var(--red)', fontWeight:600,
              }}>
                Loan record · 195 days open
              </div>

              {/* Borrower lines */}
              {overdueTask.borrowers.map(bid => {
                const m = byId(bid);
                const copies = partWork.editions[0].loans.filter(l => l.member === bid);
                return (
                  <div key={bid} style={{
                    padding:'10px 0', borderBottom:'1px dashed var(--ink5)',
                    display:'flex', alignItems:'center', gap:14,
                  }}>
                    <div style={{
                      width:36, height:36, borderRadius:'50%', background:'#cdd9ee',
                      border:'1px solid var(--ink3)', display:'inline-flex',
                      alignItems:'center', justifyContent:'center',
                      fontFamily:'Caveat, cursive', fontSize:18, fontWeight:700,
                    }}>{m.name.split(' ').map(n=>n[0]).join('')}</div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontFamily:'Inter', fontSize:14, color:'var(--ink)', fontWeight:600 }}>
                        {m.name} <Voice v={m.voice} />
                      </div>
                      <div style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--ink3)', marginTop:2 }}>
                        Copies {copies.map(c => c.copy).join(' · ')} &nbsp;·&nbsp; checked out <span style={{ color:'var(--ink)' }}>{copies[0].since}</span> &nbsp;·&nbsp;
                        <span style={{ color:'var(--red)' }}>{copies[0].days_overdue} days overdue</span>
                      </div>
                    </div>
                    <div style={{ display:'flex', gap:6 }}>
                      <button className="sk-btn ghost" style={{ fontSize:11, borderStyle:'dashed' }}>Last contacted Mar 12</button>
                      <button className="sk-btn" style={{ fontSize:11 }}>Nudge ✉</button>
                      <button className="sk-btn ghost" style={{ fontSize:11, color:'var(--ink3)' }}>Write off…</button>
                    </div>
                  </div>
                );
              })}

              <div style={{
                marginTop:10, padding:'8px 12px', background:'var(--paper2)',
                border:'1px dashed var(--ink4)', borderRadius:3,
                fontFamily:'Inter', fontSize:11.5, color:'var(--ink2)', lineHeight:1.5,
              }}>
                <span style={{ color:'var(--red)', fontFamily:'Caveat, cursive', fontSize:16, marginRight:4 }}>!</span>
                Choir owes the rental library for these four copies if not returned. Last nudge to both: <span className="mono">12 Mar</span>.
              </div>
            </div>
          </section>

          {/* Task 3 — Pull list */}
          <section style={{ marginBottom:36 }}>
            <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:14 }}>
              <Rank n="3" />
              <div style={{ flex:1 }}>
                <h2 style={{
                  margin:0, fontFamily:'Caveat, cursive', fontSize:36, fontWeight:700,
                  letterSpacing:'-0.01em', color:'var(--ink)',
                }}>
                  Pull three pieces for tonight
                </h2>
                <div style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink3)', marginTop:2 }}>
                  Conductor's request · 48 singers expected · stack on the desk before warm-up
                </div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div className="lb-tally" style={{ fontSize:46 }}>1<span style={{ color:'var(--ink4)', fontSize:24 }}>/3</span></div>
                <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--ink3)' }}>pulled</div>
              </div>
            </div>

            <div style={{ display:'grid', gridTemplateColumns:'1fr', gap:8 }}>
              {pullTask.work_ids.map(wid => {
                const w = workById(wid);
                const e = w.editions[0];
                const pulled = pullTask.pulled[wid];
                const needed = CHOIR.rehearsal_size;
                const enough = e.total - e.on_loan >= needed;
                const done = pulled >= needed;
                return (
                  <div key={wid} style={{
                    display:'grid',
                    gridTemplateColumns:'24px 1.4fr 1fr auto auto',
                    gap:14, alignItems:'center',
                    padding:'14px 18px',
                    border: done ? '1.5px solid var(--green)' : '1.5px solid var(--ink2)',
                    background: done ? '#edf3df' : 'var(--paper)',
                    borderRadius:4,
                  }}>
                    <PencilCheckbox checked={done} />
                    <div>
                      <div style={{ fontFamily:'Inter', fontSize:14, color:'var(--ink)' }}>
                        <span style={{ fontWeight:600 }}>{w.composer}</span>
                        <span style={{ color:'var(--ink3)', margin:'0 6px' }}>—</span>
                        <span style={{ fontStyle:'italic' }}>{w.title}</span>
                        {w.title_alt && <span style={{ color:'var(--ink4)', fontFamily:'Inter', fontSize:11, marginLeft:6 }}>/ {w.title_alt}</span>}
                      </div>
                      <div style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--ink3)', marginTop:2 }}>
                        {e.publisher} {e.year} · {e.voicing} · {e.location || '—'}
                      </div>
                    </div>
                    <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink2)' }}>
                      <div>Owned <span className="mono" style={{ fontWeight:600 }}>{e.total}</span> copies of this edition</div>
                      <div style={{ color: enough ? 'var(--green)' : 'var(--red)', marginTop:2 }}>
                        <StatusDot tone={enough ? 'green' : 'red'} />
                        {enough ? <span>Enough for 48 ({e.total - e.on_loan} avail.)</span>
                                : <span>Short — only {e.total - e.on_loan}</span>}
                      </div>
                    </div>
                    <StatusPill tone={done ? 'green' : 'indigo'} style={{ fontSize:11 }}>
                      {done ? `Pulled · ${pulled}/${needed}` : `Pull ${needed}`}
                    </StatusPill>
                    <div style={{ display:'flex', gap:6 }}>
                      <button className="sk-btn ghost" style={{ fontSize:11 }}>Detail</button>
                      <button className="sk-btn primary" style={{ fontSize:11 }} disabled={done}>{done ? '✓' : 'Pull'}</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Holdings index */}
          <section>
            <SectionHeading title="Holdings — all works" meta={`${stats.works} works · ${stats.editions} editions · ${stats.copies} copies`} />

            <div style={{
              border:'1.5px solid var(--ink2)', borderRadius:4,
              background:'var(--paper)', overflow:'hidden',
            }}>
              {/* Header */}
              <div style={{
                display:'grid', gridTemplateColumns:'1.8fr 1.4fr 90px 130px 60px',
                gap:12, padding:'8px 14px', background:'var(--paper2)',
                borderBottom:'1.5px solid var(--ink2)',
                fontFamily:'Inter', fontSize:10, letterSpacing:'0.12em',
                textTransform:'uppercase', color:'var(--ink3)', fontWeight:600,
              }}>
                <span>Composer · Work</span>
                <span>Edition</span>
                <span style={{ textAlign:'right' }}>Year</span>
                <span style={{ textAlign:'right' }}>Copies</span>
                <span></span>
              </div>
              {WORKS.slice(0, 9).map(w => {
                const e = w.editions[0];
                const s = workStats(w);
                const hl = ['tallis-spem','part-magnificat','tormis-raua','kreek-onnis','esenvalds-stars'].includes(w.id);
                return (
                  <div key={w.id} style={{
                    display:'grid', gridTemplateColumns:'1.8fr 1.4fr 90px 130px 60px',
                    gap:12, padding:'10px 14px',
                    borderBottom:'1px dashed var(--ink5)',
                    background: hl ? 'rgba(255,243,200,0.5)' : 'transparent',
                    alignItems:'center',
                  }}>
                    <div>
                      <div style={{ fontFamily:'Inter', fontSize:13, color:'var(--ink)' }}>
                        <span style={{ fontWeight:600 }}>{w.composer}</span>
                        <span style={{ color:'var(--ink3)', margin:'0 5px' }}>—</span>
                        <span style={{ fontStyle:'italic' }}>{w.title}</span>
                      </div>
                      <div style={{ fontFamily:'JetBrains Mono', fontSize:10, color:'var(--ink3)' }}>
                        {e.voicing} · {w.lang}
                      </div>
                    </div>
                    <div style={{ fontFamily:'Inter', fontSize:11.5, color:'var(--ink2)' }}>
                      {e.label}
                      {w.editions.length > 1 && (
                        <span style={{ color:'var(--ink4)', marginLeft:6 }}>+{w.editions.length - 1} more</span>
                      )}
                    </div>
                    <div style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--ink3)', textAlign:'right' }}>{w.year}</div>
                    <div style={{ textAlign:'right' }}>
                      {s.has_limitless && s.total === 0 ? (
                        <span style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink3)', fontStyle:'italic' }}>∞ limitless</span>
                      ) : (
                        <span style={{ fontFamily:'JetBrains Mono', fontSize:11.5, color: s.overdue > 0 ? 'var(--red)' : 'var(--ink)' }}>
                          <span style={{ fontWeight:600 }}>{s.available}</span>
                          <span style={{ color:'var(--ink4)' }}>/{s.total}</span>
                          {s.overdue > 0 && (
                            <span style={{ color:'var(--red)', marginLeft:6 }}>· {s.overdue} overdue</span>
                          )}
                          {s.returned_today > 0 && (
                            <span style={{ color:'var(--green)', marginLeft:6 }}>· {s.returned_today} back</span>
                          )}
                        </span>
                      )}
                    </div>
                    <div style={{ textAlign:'right' }}>
                      <span className="lb-key">↵</span>
                    </div>
                  </div>
                );
              })}
              <div style={{ padding:'8px 14px', background:'var(--paper2)', fontFamily:'Inter', fontSize:11, color:'var(--ink3)', textAlign:'center' }}>
                <span className="lb-uline" style={{ cursor:'pointer' }}>Show all 13 works</span>
              </div>
            </div>
          </section>
        </main>

        {/* Right gutter — marginalia */}
        <aside style={{
          padding:'40px 22px', borderLeft:'1.5px dashed var(--ink5)',
          background:'var(--paper)', overflowY:'auto',
          display:'flex', flexDirection:'column', gap:32,
        }}>
          <div>
            <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.16em', textTransform:'uppercase', color:'var(--ink3)', fontWeight:600, marginBottom:10 }}>
              Today's tally
            </div>
            <Tally n={12} label="Returned today" />
            <Tally n={4}  label="Still overdue" tone="red" style={{ marginTop:14 }} />
            <Tally n={1}  label="Of 3 pulled"  style={{ marginTop:14 }} />
          </div>

          <Margin rotate={-1.5}>
            <div style={{ borderBottom:'1px solid currentColor', paddingBottom:2, marginBottom:4 }}>note</div>
            Counted the Tallis folder<br />this morning. Twelve, all<br />
            in good shape, no foxing on<br />the title leaves. Two have<br />
            <span className="lb-strike" style={{ color:'var(--red)' }}>pencil notes</span> to erase.
          </Margin>

          <Margin rotate={1} style={{ position:'relative' }}>
            <div style={{ borderBottom:'1px solid currentColor', paddingBottom:2, marginBottom:4 }}>ask Anu</div>
            Did the rental library ever<br />
            invoice us for the four Pärt?<br />
            → check Drive folder 2025-Q4.<br />
            <span style={{ color:'var(--ink3)' }}>(Maire, 12 May)</span>
          </Margin>

          <Margin rotate={-0.5}>
            <div style={{ borderBottom:'1px solid currentColor', paddingBottom:2, marginBottom:4 }}>tonight</div>
            Tormis needs the shaman drum.<br />
            Stage manager will bring.<br />
            Ešenvalds: 6 water-glasses<br />
            tuned to D, F, A, B♭.
          </Margin>

          <Margin rotate={1.5}>
            <div style={{ borderBottom:'1px solid currentColor', paddingBottom:2, marginBottom:4 }}>this week</div>
            Inventory sweep Friday.<br />
            Cabinet B shelf 4 looks<br />light — pull list and<br />
            cross-check vs. ledger.
          </Margin>

          <div style={{ borderTop:'1.5px dashed var(--ink4)', paddingTop:10, fontFamily:'Inter', fontSize:10, color:'var(--ink4)' }}>
            <div className="lb-margin" style={{ fontSize:14, color:'var(--ink3)' }}>~ Maire</div>
            <div style={{ marginTop:2 }}>Librarian since 2014</div>
          </div>
        </aside>
      </div>

      {/* Bottom status bar */}
      <div style={{
        flexShrink:0, padding:'6px 24px',
        borderTop:'1.5px solid var(--ink2)',
        background:'var(--paper2)',
        display:'flex', justifyContent:'space-between', alignItems:'center',
        fontFamily:'Inter', fontSize:11, color:'var(--ink3)',
      }}>
        <div style={{ display:'flex', gap:16 }}>
          <span><StatusDot tone="green" />Connected</span>
          <span><StatusDot tone="indigo" />Last sync 14:30</span>
          <span style={{ color:'var(--ink4)' }}>·</span>
          <KeyHint k="⌘K" label="Search" />
          <KeyHint k="N" label="New work" />
          <KeyHint k="R" label="Mark returned" />
        </div>
        <div style={{ fontFamily:'JetBrains Mono', fontSize:11, color:'var(--ink4)' }}>
          v0.4.2 · mvox.eu / epcc / library
        </div>
      </div>
    </div>
  );
}

window.DirectionA_Catalog = DirectionA_Catalog;
