// V2 — Directory-first
// The member choirs ARE the page. Umbrella identity is a thin header;
// a prominent map + grid of sub-choirs dominates. Best for "another
// choir looking to collaborate" and prospective singers browsing by city.

function V2DirectoryFirst() {
  const choirs = [
    ['Kammerkoor Crede', 'Tallinn', 28, 'crede'],
    ['Tallinna Kammerkoor', 'Tallinn', 32, 'tkk'],
    ['Tartu Akadeemiline', 'Tartu', 44, 'tartu-ak'],
    ['Collegium Musicale', 'Tallinn', 24, 'collmus'],
    ['Voces Musicales', 'Tallinn', 18, 'voces'],
    ['RAM', 'Tallinn', 36, 'ram'],
    ['Chorus Gaudium', 'Pärnu', 22, 'gaudium'],
    ['Noorte Segakoor', 'Tallinn', 48, 'noorte'],
    ['Cantate', 'Viljandi', 26, 'cantate'],
  ];
  return (
    <BrowserFrame url="mvox.eu/o/eesti-segakooride-liit">
      <div className="sk" style={{ height: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <RegistryNav />

        {/* Compressed identity strip */}
        <div style={{ padding: '14px 32px', borderBottom: '1.5px solid var(--ink5)', display: 'flex', alignItems: 'center', gap: 16, background: 'var(--paper)' }}>
          <div className="sk-hatch" style={{ width: 44, height: 44, border: '1.5px solid var(--ink3)', borderRadius: 6, flexShrink: 0 }} />
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 20, color: 'var(--ink)' }}>Eesti Segakooride Liit</div>
            <div style={{ fontFamily: 'Inter', fontSize: 12, color: 'var(--ink3)' }}>
              Umbrella organisation · est. 1962 · 24 member choirs · 460 singers
            </div>
          </div>
          <button className="sk-btn ghost" style={{ fontSize: 13 }}>About</button>
          <button className="sk-btn primary">Contact</button>
        </div>

        {/* Search + filter toolbar */}
        <div style={{ padding: '14px 32px 10px', background: 'var(--paper2)', borderBottom: '1.5px solid var(--ink5)' }}>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <div className="sk-box" style={{ flex: 1, padding: '6px 12px', background: 'var(--paper)', fontFamily: 'Inter', fontSize: 13, color: 'var(--ink4)' }}>
              🔍  Search 24 member choirs…
            </div>
            <Chip variant="accent">City ▾</Chip>
            <Chip>Size ▾</Chip>
            <Chip>Voices ▾</Chip>
            <Chip>Repertoire ▾</Chip>
          </div>
          <div style={{ marginTop: 10, display: 'flex', gap: 6, alignItems: 'center', fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)' }}>
            <span>Sort:</span>
            <Chip variant="filled" style={{ fontSize: 11 }}>A–Z</Chip>
            <Chip style={{ fontSize: 11 }}>Newest</Chip>
            <Chip style={{ fontSize: 11 }}>Largest</Chip>
            <div style={{ flex: 1 }} />
            <span>⊞ Grid</span><span style={{ color: 'var(--ink4)' }}>/</span><span>▤ List</span><span style={{ color: 'var(--ink4)' }}>/</span><span className="sk-underline">⊚ Map</span>
          </div>
        </div>

        {/* Main: map + grid */}
        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '340px 1fr', overflow: 'hidden', minHeight: 0 }}>
          {/* Map */}
          <div style={{ borderRight: '1.5px solid var(--ink5)', padding: 16, background: 'var(--paper)', position: 'relative' }}>
            <Eyebrow style={{ marginBottom: 8 }}>Where our choirs sing</Eyebrow>
            <div className="sk-box" style={{ height: 'calc(100% - 28px)', background: 'var(--paper2)', position: 'relative', overflow: 'hidden' }}>
              {/* fake map: hatched background + pins */}
              <div className="sk-hatch-light" style={{ position: 'absolute', inset: 0 }} />
              {/* "Estonia" scribble */}
              <svg viewBox="0 0 300 400" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
                <path d="M40,120 Q80,80 150,90 Q220,85 260,130 Q270,200 230,260 Q180,320 120,310 Q60,290 40,220 Z"
                  fill="none" stroke="var(--ink4)" strokeWidth="1.5" strokeDasharray="3 3" />
                {/* pins */}
                {[[160, 150, 12], [140, 200, 6], [180, 280, 3], [110, 230, 2], [220, 180, 1]].map(([x, y, n], i) => (
                  <g key={i}>
                    <circle cx={x} cy={y} r={6 + n} fill="var(--accent)" opacity="0.25" />
                    <circle cx={x} cy={y} r="4" fill="var(--accent)" stroke="#fff" strokeWidth="1.5" />
                    <text x={x + 10} y={y + 4} fontFamily="Inter" fontSize="10" fill="var(--ink2)">{n}</text>
                  </g>
                ))}
              </svg>
              <Annot style={{ position: 'absolute', bottom: 10, right: 8 }}>pin cluster = multiple choirs</Annot>
            </div>
          </div>

          {/* Choir grid */}
          <div style={{ padding: '16px 24px', overflow: 'hidden' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
              <div style={{ fontFamily: 'Inter', fontSize: 14, fontWeight: 600, color: 'var(--ink)' }}>24 member choirs</div>
              <div style={{ fontFamily: 'Inter', fontSize: 11, color: 'var(--ink3)' }}>showing 9 of 24</div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
              {choirs.map(([name, city, size, slug]) => (
                <div key={slug} className="sk-box" style={{ padding: 10, background: 'var(--paper)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                    <div className="sk-hatch" style={{ width: 28, height: 28, borderRadius: 4, border: '1px solid var(--ink4)' }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontFamily: 'Inter', fontSize: 12, fontWeight: 600, color: 'var(--ink)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{name}</div>
                      <div style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)' }}>{city} · {size} singers</div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 3, flexWrap: 'wrap', marginBottom: 6 }}>
                    <Chip style={{ fontSize: 10, padding: '1px 6px' }}>S·A·T·B</Chip>
                  </div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--accent)' }}>mvox.eu/o/{slug} ↗</div>
                </div>
              ))}
            </div>
            <div style={{ textAlign: 'center', marginTop: 12 }}>
              <button className="sk-btn ghost">Show all 24 →</button>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.V2DirectoryFirst = V2DirectoryFirst;
