// Direction C — "The Working Desk"
// Distinctive / utility. Maire's three tasks rendered as three physical paper stacks
// on a desk surface. Below the stacks: a quiet command-bar holdings list.
// Most kinetic, most visually committed. Expert keyboard ergonomics.

function DirectionC_Desk() {
  return (
    <div className="sk" style={{
      height:'100%', overflow:'hidden', display:'flex', flexDirection:'column',
      background: `
        radial-gradient(ellipse at 20% 0%, rgba(255,235,180,0.4), transparent 60%),
        radial-gradient(ellipse at 100% 100%, rgba(0,0,0,0.06), transparent 50%),
        repeating-linear-gradient(110deg, #d6c39a 0 2px, #d8c79e 2px 6px, #d4be94 6px 10px),
        #d3bf95
      `,
    }}>
      <MvoxNav active="library" />

      {/* Top strip — date + librarian eyebrow */}
      <div style={{
        padding:'14px 32px',
        background:'rgba(247,241,225,0.7)',
        borderBottom:'1.5px solid var(--ink2)',
        display:'flex', justifyContent:'space-between', alignItems:'center',
      }}>
        <div>
          <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.16em', textTransform:'uppercase', color:'var(--ink3)', fontWeight:600 }}>
            Library &middot; librarian's desk
          </div>
          <div style={{
            fontFamily:'Caveat, cursive', fontSize:34, fontWeight:700,
            color:'var(--ink)', lineHeight:1.0, letterSpacing:'-0.01em', marginTop:2,
          }}>
            On the desk today
          </div>
        </div>

        <div style={{ display:'flex', alignItems:'center', gap:18 }}>
          <div style={{ textAlign:'right', fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
            <div>{TODAY.date} · <span style={{ color:'var(--ink2)' }}>{TODAY.time}</span></div>
            <div className="lb-margin" style={{ fontSize:16, marginTop:2, color:'var(--red)' }}>
              Rehearsal 16:00 &middot; in <strong>1h 28m</strong>
            </div>
          </div>
          <PencilSearch placeholder="⌘K  ·  jump to work, copy #, borrower…" style={{ width:340, padding:'5px 12px' }} />
        </div>
      </div>

      {/* Desk surface with three stacks */}
      <div style={{
        flex:1, overflow:'hidden', position:'relative',
        padding:'30px 32px 0',
      }}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1.15fr', gap:26, height:'100%' }}>
          <ReturnsStack />
          <OverdueStack />
          <PullStack />
        </div>

        {/* Pen / pencil lying across the desk (decorative) */}
        <svg style={{ position:'absolute', right:30, top:8, opacity:0.5 }} width="120" height="22" viewBox="0 0 120 22">
          <rect x="10" y="6" width="80" height="8" rx="2" fill="#8b6234" stroke="#4b3415" strokeWidth="0.8" />
          <polygon points="90,6 100,10 90,14" fill="#d4b079" stroke="#4b3415" strokeWidth="0.8" />
          <polygon points="100,10 104,9 104,11" fill="#2a2620" />
          <rect x="2" y="6" width="9" height="8" rx="1.5" fill="#c84b3a" stroke="#4b3415" strokeWidth="0.8" />
        </svg>
      </div>

      {/* Command bar drawer at bottom */}
      <DeskCommandBar />

    </div>
  );
}

// ─── Stack 1 — Returns ──────────────────────────────────────────────
function ReturnsStack() {
  const work = workById('tallis-spem');
  const ed = work.editions[0];
  const copies = Array.from({ length: 12 }, (_, i) => ({
    n: String(i + 1).padStart(2, '0'),
    checked: i < 8,
  }));

  return (
    <PaperStack style={{ padding:'18px 22px', display:'flex', flexDirection:'column', minHeight:0, transform:'rotate(-0.8deg)' }}>
      <StackHeader rank="1" title="Returns" subtitle="back from December" tone="green" stamp="ARRIVED" />

      <div style={{ marginTop:4 }}>
        <WorkTitle work={work} size="l" />
        <div style={{ fontFamily:'JetBrains Mono', fontSize:10.5, color:'var(--ink3)', marginTop:3 }}>
          {ed.publisher} {ed.year} &middot; {ed.voicing}
        </div>
      </div>

      <div style={{
        marginTop:14, padding:'12px 14px',
        background:'var(--paper2)', border:'1px dashed var(--ink4)', borderRadius:3,
      }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
          <span style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em', textTransform:'uppercase', color:'var(--ink3)', fontWeight:600 }}>
            Folder · Bass section
          </span>
          <span style={{ fontFamily:'Caveat, cursive', fontSize:14, color:'var(--ink3)' }}>
            12 copies counted this morning
          </span>
        </div>

        <div style={{ display:'grid', gridTemplateColumns:'repeat(6, 1fr)', gap:6 }}>
          {copies.map(c => (
            <div key={c.n} style={{
              display:'flex', alignItems:'center', gap:5,
              padding:'6px 7px',
              background: c.checked ? 'rgba(95,122,59,0.12)' : 'var(--paper)',
              border:'1px solid var(--ink5)', borderRadius:3,
            }}>
              <PencilCheckbox checked={c.checked} />
              <span style={{
                fontFamily:'JetBrains Mono', fontSize:10.5,
                color: c.checked ? 'var(--ink3)' : 'var(--ink)',
                fontWeight:600,
              }}>
                <span className={c.checked ? 'lb-strike' : ''}>#{c.n}</span>
              </span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ flex:1, minHeight:8 }} />

      <div style={{
        display:'flex', justifyContent:'space-between', alignItems:'center',
        paddingTop:14, borderTop:'1.5px dashed var(--ink5)', marginTop:14,
      }}>
        <div>
          <span className="lb-tally" style={{ fontSize:44 }}>8</span>
          <span style={{ fontFamily:'Caveat', fontSize:20, color:'var(--ink3)' }}>/12</span>
          <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--ink3)' }}>ticked</div>
        </div>
        <div style={{ display:'flex', gap:6, alignItems:'center' }}>
          <KeyHint k="R" label="" />
          <button className="sk-btn primary" style={{ fontSize:12 }}>
            Confirm last 4 ✓
          </button>
        </div>
      </div>
    </PaperStack>
  );
}

// ─── Stack 2 — Overdue ──────────────────────────────────────────────
function OverdueStack() {
  const work = workById('part-magnificat');
  const ed = work.editions[0];

  return (
    <PaperStack style={{
      padding:'18px 22px', display:'flex', flexDirection:'column', minHeight:0,
      transform:'rotate(0.6deg)',
      background:'var(--paper)',
      borderColor:'var(--red)',
    }}>
      <StackHeader rank="2" title="Overdue" subtitle="basses still hold these" tone="red" stamp="OVERDUE" />

      <div style={{ marginTop:4 }}>
        <WorkTitle work={work} size="l" />
        <div style={{ fontFamily:'JetBrains Mono', fontSize:10.5, color:'var(--ink3)', marginTop:3 }}>
          {ed.publisher} {ed.year} &middot; {ed.voicing}
          {ed.isbn && <span style={{ marginLeft:6 }}>{ed.isbn}</span>}
        </div>
      </div>

      {/* Borrower cards */}
      <div style={{ marginTop:14, display:'flex', flexDirection:'column', gap:8 }}>
        {['hk','mr'].map(bid => {
          const m = byId(bid);
          const loans = ed.loans.filter(l => l.member === bid);
          return (
            <div key={bid} style={{
              padding:'10px 12px',
              background:'rgba(181,74,58,0.08)',
              border:'1px solid var(--red)', borderRadius:3,
              display:'flex', alignItems:'center', gap:12,
            }}>
              <div style={{
                width:36, height:36, borderRadius:'50%', background:'#cdd9ee',
                border:'1.25px solid var(--ink3)',
                display:'inline-flex', alignItems:'center', justifyContent:'center',
                fontFamily:'Caveat, cursive', fontSize:17, fontWeight:700, flexShrink:0,
              }}>{m.name.split(' ').map(n=>n[0]).join('')}</div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontFamily:'Inter', fontSize:13, fontWeight:600, color:'var(--ink)' }}>
                  {m.name} <Voice v={m.voice} />
                </div>
                <div style={{ fontFamily:'JetBrains Mono', fontSize:10, color:'var(--ink3)' }}>
                  copies {loans.map(l => l.copy).join(' · ')} &middot; out {loans[0].since}
                </div>
                <div style={{ fontFamily:'Caveat, cursive', fontSize:14, color:'var(--red)', marginTop:1 }}>
                  {loans[0].days_overdue} days overdue
                </div>
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
                <button className="sk-btn" style={{ fontSize:10, padding:'2px 8px' }}>Nudge</button>
                <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 8px' }}>Return</button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Red stamp annotation */}
      <div style={{
        position:'absolute', top:36, right:18,
        fontFamily:'Caveat, cursive', fontSize:13,
        color:'var(--red)', transform:'rotate(8deg)',
        opacity:0.85, lineHeight:1.1, textAlign:'left',
      }}>
        owe rental library<br />
        if not back by 31 May
      </div>

      <div style={{ flex:1, minHeight:8 }} />

      <div style={{
        display:'flex', justifyContent:'space-between', alignItems:'center',
        paddingTop:14, borderTop:'1.5px dashed var(--ink5)', marginTop:14,
      }}>
        <div>
          <span className="lb-tally lb-tally-red" style={{ fontSize:44 }}>4</span>
          <div style={{ fontFamily:'Inter', fontSize:10, letterSpacing:'0.12em', textTransform:'uppercase', color:'var(--red)' }}>copies out</div>
        </div>
        <div style={{ display:'flex', gap:6 }}>
          <button className="sk-btn ghost" style={{ fontSize:11, color:'var(--ink3)' }}>Write off…</button>
          <button className="sk-btn" style={{ fontSize:11, borderColor:'var(--red)', color:'var(--red)' }}>Nudge both ✉</button>
        </div>
      </div>
    </PaperStack>
  );
}

// ─── Stack 3 — Pull list for tonight ────────────────────────────────
function PullStack() {
  const pull = TASKS.find(t => t.id === 'pull');

  return (
    <PaperStack style={{
      padding:'18px 22px', display:'flex', flexDirection:'column', minHeight:0,
      transform:'rotate(-0.3deg)',
      background:'var(--paper)',
    }}>
      <StackHeader rank="3" title="Pull for tonight" subtitle="48 singers · stack on the desk" tone="indigo" stamp="TONIGHT" />

      <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginTop:4 }}>
        Conductor's request · Tue {TODAY.date.slice(0,6)} · 16:00
      </div>

      <div style={{ marginTop:12, display:'flex', flexDirection:'column', gap:8, flex:1, minHeight:0 }}>
        {pull.work_ids.map(wid => {
          const w = workById(wid);
          const e = w.editions[0];
          const need = CHOIR.rehearsal_size;
          const avail = e.total - e.on_loan;
          const pulled = pull.pulled[wid];
          const done = pulled >= need;
          return (
            <div key={wid} style={{
              padding:'10px 12px',
              background: done ? 'rgba(95,122,59,0.10)' : 'var(--paper2)',
              border: done ? '1.5px solid var(--green)' : '1.5px solid var(--ink2)',
              borderRadius:3,
            }}>
              <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:8 }}>
                <div style={{ flex:1, minWidth:0 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                    <PencilCheckbox checked={done} />
                    <div style={{ flex:1 }}>
                      <div style={{ fontFamily:'Inter', fontSize:13, fontWeight:600, color:'var(--ink)' }}>
                        {w.composer}
                      </div>
                      <div style={{ fontFamily:'Inter', fontSize:13, fontStyle:'italic', color:'var(--ink)', lineHeight:1.2 }}>
                        {w.title}
                      </div>
                      {w.title_alt && (
                        <div style={{ fontFamily:'Inter', fontSize:10.5, color:'var(--ink4)' }}>
                          / {w.title_alt}
                        </div>
                      )}
                    </div>
                  </div>
                  <div style={{ display:'grid', gridTemplateColumns:'auto 1fr', gap:'2px 10px', marginTop:6, fontFamily:'JetBrains Mono', fontSize:10, color:'var(--ink3)' }}>
                    <span>edition</span>
                    <span style={{ color:'var(--ink2)' }}>{e.label}</span>
                    <span>where</span>
                    <span style={{ color:'var(--ink2)' }}>{e.location || '—'}</span>
                    <span>have</span>
                    <span style={{ color:'var(--ink)' }}>
                      <span style={{ fontWeight:600 }}>{avail}</span>
                      <span style={{ color:'var(--ink4)' }}>/{e.total}</span>
                      <span style={{ color:'var(--green)', marginLeft:6 }}>· enough for 48</span>
                    </span>
                  </div>
                </div>
                <div style={{ textAlign:'right', flexShrink:0 }}>
                  <div className="lb-tally" style={{ fontSize:32, color: done ? 'var(--green)' : 'var(--ink)' }}>
                    {done ? pulled : need}
                  </div>
                  <div style={{ fontFamily:'Inter', fontSize:9, letterSpacing:'0.12em', textTransform:'uppercase', color: done ? 'var(--green)' : 'var(--ink3)' }}>
                    {done ? 'pulled' : 'to pull'}
                  </div>
                </div>
              </div>
              <div style={{ display:'flex', gap:6, marginTop:8, justifyContent:'flex-end' }}>
                {done ? (
                  <>
                    <span style={{ fontFamily:'Caveat, cursive', fontSize:14, color:'var(--green)', alignSelf:'center', marginRight:'auto' }}>
                      ✓ on the desk
                    </span>
                    <button className="sk-btn ghost" style={{ fontSize:10 }}>Undo</button>
                  </>
                ) : (
                  <>
                    <button className="sk-btn ghost" style={{ fontSize:10 }}>Locate</button>
                    <button className="sk-btn ghost" style={{ fontSize:10 }}>Skip</button>
                    <button className="sk-btn primary" style={{ fontSize:10 }}>Pull 48 →</button>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div style={{
        marginTop:12, padding:'8px 10px',
        background:'var(--paper2)', borderRadius:3, border:'1px dashed var(--ink5)',
        display:'flex', justifyContent:'space-between', alignItems:'center',
        fontFamily:'Inter', fontSize:11, color:'var(--ink3)',
      }}>
        <span>Singers expected tonight</span>
        <VoiceTally counts={{ S1:8, S2:8, A:12, T1:5, T2:5, B1:5, B2:5 }} />
      </div>
    </PaperStack>
  );
}

function StackHeader({ rank, title, subtitle, tone, stamp }) {
  const colorMap = {
    green: { bg:'#dde9cb', border:'var(--green)', fg:'#3c5320' },
    red:   { bg:'#f4d7d0', border:'var(--red)',   fg:'#7a2418' },
    indigo:{ bg:'#dde0fb', border:'var(--indigo)',fg:'var(--indigo)' },
  };
  const c = colorMap[tone] || colorMap.green;
  return (
    <div style={{ position:'relative' }}>
      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        <span style={{
          width:28, height:28, borderRadius:'50%',
          background:c.bg, border:`2px solid ${c.border}`, color:c.fg,
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          fontFamily:'Caveat, cursive', fontSize:18, fontWeight:700,
        }}>{rank}</span>
        <div>
          <div style={{
            fontFamily:'Caveat, cursive', fontSize:28, fontWeight:700,
            color:'var(--ink)', lineHeight:1.0, letterSpacing:'-0.01em',
          }}>{title}</div>
          <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>{subtitle}</div>
        </div>
      </div>
      {/* Stamp */}
      <div style={{
        position:'absolute', top:0, right:0,
        fontFamily:'Inter', fontSize:11, fontWeight:700, letterSpacing:'0.14em',
        color: c.fg, padding:'4px 10px',
        border:`1.5px solid ${c.border}`, borderRadius:3,
        background:c.bg, transform:'rotate(-3deg)',
      }}>{stamp}</div>
    </div>
  );
}

// ─── Bottom drawer — quick command palette / holdings stack ─────────
function DeskCommandBar() {
  return (
    <div style={{
      borderTop:'1.5px solid var(--ink2)',
      background:'var(--paper2)',
      padding:'12px 32px 14px',
      flexShrink:0,
    }}>
      <div style={{
        display:'flex', alignItems:'center', gap:14, marginBottom:10,
      }}>
        <span style={{
          fontFamily:'Inter', fontSize:10, letterSpacing:'0.14em',
          textTransform:'uppercase', color:'var(--ink3)', fontWeight:600,
        }}>
          Catalog &middot; {WORKS.length} works
        </span>
        <span style={{ color:'var(--ink4)' }}>·</span>
        <span style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)' }}>
          <span style={{ color:'var(--ink)' }}>{libStats().copies}</span> copies owned
          &middot; <span style={{ color:'var(--green)' }}>{libStats().available}</span> available
          &middot; <span style={{ color:'var(--red)' }}>{libStats().overdue}</span> overdue
        </span>
        <div style={{ flex:1 }} />
        <KeyHint k="⌘K" label="Search" />
        <KeyHint k="N" label="New work" />
        <KeyHint k="L" label="Lend" />
        <KeyHint k="?" label="All shortcuts" />
        <button className="sk-btn ghost" style={{ fontSize:11 }}>Open full catalog ↗</button>
      </div>

      {/* Mini holdings strip — last 6 works as paper cards */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(6, 1fr)', gap:8 }}>
        {WORKS.slice(0, 6).map((w, i) => {
          const s = workStats(w);
          const hl = ['tallis-spem','part-magnificat'].includes(w.id);
          return (
            <div key={w.id} style={{
              padding:'8px 10px',
              background:'var(--paper)',
              border:'1px solid var(--ink4)',
              borderRadius:3,
              boxShadow:'1px 1px 0 0 var(--ink5)',
              borderTop: hl ? '3px solid var(--red)' : '1px solid var(--ink4)',
            }}>
              <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink)', fontWeight:600, lineHeight:1.2, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
                {w.composer}
              </div>
              <div style={{ fontFamily:'Inter', fontSize:11, fontStyle:'italic', color:'var(--ink2)', lineHeight:1.2, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
                {w.title}
              </div>
              <div style={{
                marginTop:5, display:'flex', justifyContent:'space-between', alignItems:'center',
                fontFamily:'JetBrains Mono', fontSize:10, color:'var(--ink3)',
              }}>
                <span>{w.editions[0].voicing}</span>
                {s.has_limitless && s.total === 0 ? (
                  <span style={{ color:'var(--accent)', fontStyle:'italic' }}>∞</span>
                ) : (
                  <span style={{ color: s.overdue > 0 ? 'var(--red)' : (s.available > 0 ? 'var(--green)' : 'var(--ink3)') }}>
                    {s.available}/{s.total}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

window.DirectionC_Desk = DirectionC_Desk;
