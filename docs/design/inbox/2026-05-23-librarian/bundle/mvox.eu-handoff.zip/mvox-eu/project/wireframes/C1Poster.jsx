// C1 — Poster-hero, compact. Season-led feel for a single choir.
// Hero carries next concert + season title + audition chip.
// Dense single-column-ish body.

function C1Poster({ withUmbrella = true }) {
  return (
    <BrowserFrame url="mvox.eu/o/kaaren-kammerkoor">
      <div className="sk" style={{ height: '100%', overflow: 'hidden', display: 'flex', flexDirection: 'column', position: 'relative' }}>
        <ContextToggle mode={withUmbrella ? 'umbrella member' : 'independent'} />
        <RegistryNav />

        {/* Identity strip */}
        <div style={{ padding: '10px 28px', borderBottom: '1.5px solid var(--ink5)', display: 'flex', alignItems: 'center', gap: 12, background: 'var(--paper)' }}>
          <div className="sk-hatch" style={{ width: 34, height: 34, border: '1.5px solid var(--ink3)', borderRadius: 6, flexShrink: 0 }} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 16, color: 'var(--ink)', lineHeight: 1.1, letterSpacing: '-0.01em' }}>Kaaren Kammerkoor</div>
            <div style={{ fontFamily: 'Inter', fontSize: 10, color: 'var(--ink3)', marginTop: 2, display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
              <span>Chamber choir · Tallinn · est. 2014 · 22 singers</span>
              {withUmbrella && <UmbrellaBadge name="Eesti Segakooride Liit" slug="eesti-segakooride-liit" />}
            </div>
          </div>
          <button className="sk-btn ghost" style={{ fontSize: 12 }}>Press</button>
          <button className="sk-btn primary" style={{ fontSize: 12 }}>Contact</button>
        </div>

        {/* Poster hero */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', borderBottom: '1.5px solid var(--ink4)' }}>
          <div style={{ padding: '20px 28px', position: 'relative' }}>
            <Eyebrow>Season 2025/26 · Piirid</Eyebrow>
            <div style={{ fontFamily: 'Inter', fontWeight: 800, fontSize: 34, lineHeight: 1.05, color: 'var(--ink)', margin: '6px 0 4px', letterSpacing: '-0.02em' }}>
              Next — <span style={{ color: 'var(--accent)' }}>Reekviem</span>
            </div>
            <div style={{ fontFamily: 'Inter', fontSize: 12, color: 'var(--ink3)', fontStyle: 'italic', marginBottom: 8 }}>
              Sat 03 May · 19:00 · Kaarli kirik, Tallinn · w/ Collegium Musicale
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
              <button className="sk-btn primary">Tickets →</button>
              <button className="sk-btn ghost">Full programme</button>
              <Chip variant="accent" style={{ alignSelf: 'center' }}>3 voice spots open · audition →</Chip>
            </div>
          </div>
          <div className="sk-hatch" style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ fontFamily: 'Caveat', fontSize: 14, color: 'var(--ink3)', textAlign: 'center' }}>
              concert poster / group portrait
            </div>
          </div>
        </div>

        {/* Body grid */}
        <div style={{ flex: 1, overflow: 'hidden', padding: '16px 28px', display: 'grid', gridTemplateColumns: '1fr 1fr 240px', gap: 20, minHeight: 0 }}>
          <div>
            <CH2>About</CH2>
            <Lines count={4} widths={['long','long','med','short']} />

            <CH2 right="see all (12) →">Upcoming concerts</CH2>
            {[['MAY','03','Reekviem','Kaarli kirik'],['JUN','14','Suvine õhtu','Vanemuise saal'],['JUL','02','Suvefestival','Haapsalu toomkirik']].map(([m,d,t,v],i)=>(
              <div key={i} style={{ display:'flex', gap:10, padding:'5px 0', borderBottom:'1px dashed var(--ink5)' }}>
                <div className="sk-box" style={{ width:32, textAlign:'center', padding:'2px 0', flexShrink:0 }}>
                  <div style={{ fontFamily:'Inter', fontSize:8, fontWeight:600, color:'var(--accent)', letterSpacing:'0.1em' }}>{m}</div>
                  <div style={{ fontFamily:'Inter', fontSize:14, fontWeight:700, lineHeight:1 }}>{d}</div>
                </div>
                <div style={{ flex:1, fontFamily:'Inter', fontSize:11 }}>
                  <div style={{ fontWeight:600, color:'var(--ink)' }}>{t}</div>
                  <div style={{ color:'var(--ink3)', fontSize:10 }}>{v}</div>
                </div>
              </div>
            ))}

            <CH2 right="browse repertoire →">Season programme</CH2>
            {[['Duruflé','Requiem Op.9','SATB'],['Pärt','Da pacem Domine','SATB'],['Kreek','Taaveti laul','SATB']].map(([c,w,v],i)=>(
              <div key={i} style={{ display:'flex', justifyContent:'space-between', padding:'4px 0', borderBottom:'1px dashed var(--ink5)', fontFamily:'Inter', fontSize:11 }}>
                <span><span style={{ fontWeight:600 }}>{c}</span> — <span className="sk-underline" style={{ color:'var(--accent)' }}>{w}</span></span>
                <span className="mono" style={{ color:'var(--ink3)', fontSize:10 }}>{v}</span>
              </div>
            ))}
          </div>

          <div>
            <CH2>Artistic director</CH2>
            <div style={{ display:'flex', gap:10 }}>
              <div className="sk-hatch" style={{ width:70, height:90, borderRadius:4, border:'1px solid var(--ink4)', flexShrink:0 }} />
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontFamily:'Inter', fontSize:13, fontWeight:700 }}>Mari Tõnisson</div>
                <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)' }}>Conductor since 2018</div>
                <Lines count={2} widths={['long','med']} />
              </div>
            </div>

            <CH2 right="listen all →">Recordings</CH2>
            {[['Õhtupalve','2024 · EMTA Saal','4:12'],['Gloria in D','2023 · live','7:38'],['Piirid','2023 · studio','3:04']].map(([t,src,len],i)=>(
              <div key={i} style={{ display:'flex', alignItems:'center', gap:8, padding:'5px 0', borderBottom:'1px dashed var(--ink5)' }}>
                <div className="sk-box" style={{ width:24, height:24, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:10 }}>▶</div>
                <div style={{ flex:1, fontFamily:'Inter', fontSize:11, minWidth:0 }}>
                  <div style={{ fontWeight:600 }}>{t}</div>
                  <div style={{ color:'var(--ink3)', fontSize:9 }}>{src}</div>
                </div>
                <span className="mono" style={{ fontSize:9, color:'var(--ink3)' }}>{len}</span>
              </div>
            ))}

            <CH2>Past highlights</CH2>
            <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink2)', lineHeight:1.55 }}>
              <div>· Laulupidu 2024 — selected ensemble</div>
              <div>· Nordic Choir Festival 2023 — silver category</div>
              <div>· EMP premiere of Sisask, "Piirid" (2022)</div>
            </div>
          </div>

          {/* Right rail */}
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div className="sk-box" style={{ padding:10 }}>
              <Eyebrow style={{ marginBottom:6 }}>Sections · openings</Eyebrow>
              <VoiceSections data={[['S',6,1],['A',5,0],['T',5,2],['B',6,0]]} />
              <button className="sk-btn ghost" style={{ marginTop:8, width:'100%', fontSize:11, justifyContent:'center' }}>Audition info →</button>
            </div>
            <div className="sk-box soft" style={{ padding:10 }}>
              <Eyebrow style={{ marginBottom:6 }}>Rehearsals</Eyebrow>
              <RehearsalRow day="Mon" time="19:00–21:30" venue="EMTA, R-207" />
              <RehearsalRow day="Thu" time="19:00–21:30" venue="EMTA, R-207" note="Sept–Jun" />
            </div>
            <div className="sk-box dashed" style={{ padding:10 }}>
              <Eyebrow style={{ marginBottom:6 }}>Contact</Eyebrow>
              <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink3)', lineHeight:1.55 }}>
                <span className="mono" style={{ color:'var(--accent)' }}>info@kaaren.ee</span><br/>
                <Chip style={{ fontSize:9, marginTop:4 }}>IG</Chip> <Chip style={{ fontSize:9 }}>FB</Chip> <Chip style={{ fontSize:9 }}>YT</Chip>
              </div>
            </div>
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.C1Poster = C1Poster;
