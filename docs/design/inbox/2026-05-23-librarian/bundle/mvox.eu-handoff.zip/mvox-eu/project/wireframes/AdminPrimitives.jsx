// Admin / Settings primitives — shared bits for the 3 admin variations.
//
// Two conceptual surfaces:
//   1. Sections — conductor-owned (musical structure: SATB + Keyboard,
//      subsections, section leaders, order, colors, bulk-move)
//   2. Members & roles — admin-owned (invites, pending requests,
//      role assignments, archive, audit log)
//
// A single person can hold multiple roles (conductor + admin is common).

// ─── Role definitions ────────────────────────────────────────────────
// Fixed set (per user decision). Permissions are hard-coded to role name
// at the app level — this page only assigns labels.
// Three are collective-level (assigned on this page).
// 'leader' is a section-level role and is managed on the Sections tab.
const ROLES = [
  { id:'admin',     label:'Admin',          color:'var(--accent)', scope:'collective',
    blurb:'Manages members, roles, invites, billing.' },
  { id:'conductor', label:'Conductor',      color:'#2f7a4f',       scope:'collective',
    blurb:'Leads rehearsals. Defines sections, runs repertoire, posts notices.' },
  { id:'librarian', label:'Librarian',      color:'#8a6a2e',       scope:'collective',
    blurb:'Manages the score library and loans.' },
  { id:'leader',    label:'Section leader', color:'#6a5a8a',       scope:'section',
    blurb:'Leads a section in rehearsals and sectionals. Managed on the Sections tab.' },
];
const ROLE_BY_ID = Object.fromEntries(ROLES.map(r => [r.id, r]));

// ─── Per-member role assignments ─────────────────────────────────────
// Maps member.id -> role ids. Section-leader derived from MEMBERS.sectionLeader.
const MEMBER_ROLES = {
  2:  ['conductor', 'admin'],  // Kaarin — conductor + admin (both hats)
  6:  ['librarian'],            // Helena — librarian
  3:  ['admin'],                // Liisa (YOU) — admin only
  // section leaders derived from MEMBERS.sectionLeader
};

// Canonical list of role ids for a member (derives 'leader' from sectionLeader).
function rolesOf(member) {
  const rs = (MEMBER_ROLES[member.id] || []).slice();
  if (member.sectionLeader) rs.push('leader');
  if (rs.length === 0) rs.push('member'); // baseline
  return rs;
}

// Count members holding a given role.
function memberCountByRole(roleId) {
  if (roleId === 'leader') {
    return MEMBERS.filter(m => m.sectionLeader).length;
  }
  return MEMBERS.filter(m => (MEMBER_ROLES[m.id] || []).includes(roleId)).length;
}

// ─── Pending join requests ───────────────────────────────────────────
const PENDING = [
  { id:'p1', name:'Helen Oks',      email:'helen.oks@example.ee',      voicePref:'Alto',    when:'22 Apr',  note:'Sang in University chamber choir 2019-23.' },
  { id:'p2', name:'Marek Sild',     email:'marek.sild@example.ee',     voicePref:'Bass',    when:'21 Apr',  note:null },
  { id:'p3', name:'Triin Kivirand', email:'triin.k@example.ee',        voicePref:'Soprano', when:'18 Apr',  note:'Could start from August.' },
];

// ─── Audit log ───────────────────────────────────────────────────────
// Recent admin actions. Displayed in the Members surface.
const AUDIT = [
  { when:'2 min ago',  who:'Liisa Mets',   what:'approved join request',  target:'Anu Rebane',        kind:'approve' },
  { when:'14 min ago', who:'Kaarin Lepik', what:'moved to section',       target:'Tiina Oja → Alto / A2', kind:'move' },
  { when:'1 hour ago', who:'Liisa Mets',   what:'invited',                target:'kristiina@example.ee', kind:'invite' },
  { when:'yesterday',  who:'Kaarin Lepik', what:'assigned section leader', target:'Mari Tõnisson · Soprano', kind:'role' },
  { when:'yesterday',  who:'Liisa Mets',   what:'archived member',        target:'Madis Peekel',      kind:'archive' },
  { when:'3 days ago', who:'Kaarin Lepik', what:'renamed section',        target:'“Altid” → “Alto”', kind:'section' },
  { when:'5 days ago', who:'Liisa Mets',   what:'granted role',           target:'Helena Kuusk · librarian', kind:'role' },
  { when:'1 week ago', who:'Kaarin Lepik', what:'added subsection',       target:'Soprano · S2',  kind:'section' },
];

// ─── Settings nav shell ──────────────────────────────────────────────
// Tabs along the top of the settings surface. For V1/V2.
function SettingsNav({ active = 'sections' }) {
  const tabs = [
    { id:'general',  label:'General',         subtle:true },
    { id:'sections', label:'Sections',        hint:'conductor' },
    { id:'members',  label:'Members & roles', hint:'admin' },
    { id:'public',   label:'Public profile',  subtle:true },
    { id:'billing',  label:'Billing',         subtle:true },
  ];
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:0,
      padding:'0 24px', borderBottom:'1.5px solid var(--ink4)',
      background:'var(--paper)',
    }}>
      {tabs.map(t => {
        const on = t.id === active;
        return (
          <div key={t.id} style={{
            padding:'10px 16px',
            borderBottom: on ? '2px solid var(--accent)' : '2px solid transparent',
            marginBottom:-1.5,
            display:'flex', alignItems:'baseline', gap:6,
          }}>
            <span style={{
              fontFamily:'Inter', fontSize:12,
              fontWeight: on ? 600 : 400,
              color: on ? 'var(--ink)' : (t.subtle ? 'var(--ink4)' : 'var(--ink2)'),
            }}>{t.label}</span>
            {t.hint && (
              <span style={{
                fontFamily:'Inter', fontSize:9, fontWeight:500,
                letterSpacing:'0.08em', textTransform:'uppercase',
                color: on ? 'var(--accent)' : 'var(--ink4)',
              }}>{t.hint}</span>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Settings subnav (breadcrumb-ish) ────────────────────────────────
function SettingsSubnav() {
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:8,
      padding:'7px 24px', borderBottom:'1.5px solid var(--ink5)',
      background:'var(--paper2)',
      fontFamily:'Inter', fontSize:11, color:'var(--ink3)',
    }}>
      <span className="mono" style={{ fontSize:10, color:'var(--ink4)' }}>
        mvox.eu/members/{OWN_CHOIR.slug}/settings
      </span>
      <span style={{ color:'var(--ink4)' }}>·</span>
      <span>Settings visible to <strong style={{ color:'var(--ink2)' }}>Admins</strong> and <strong style={{ color:'var(--ink2)' }}>Conductors</strong>.</span>
      <span style={{ flex:1 }} />
    </div>
  );
}

// ─── Role chip (pill form) ───────────────────────────────────────────
function AdminRoleChip({ role, size = 'md' }) {
  const r = ROLE_BY_ID[role];
  if (!r) return (
    <span style={{
      fontFamily:'Inter', fontSize:9, fontWeight:500, letterSpacing:'0.06em',
      textTransform:'uppercase', padding:'1px 6px', borderRadius:3,
      color:'var(--ink4)', border:'1px dashed var(--ink4)',
    }}>member</span>
  );
  const sz = size === 'sm'
    ? { fs:9,   pad:'1px 5px' }
    : { fs:9.5, pad:'2px 7px' };
  return (
    <span style={{
      fontFamily:'Inter', fontSize:sz.fs, fontWeight:700, letterSpacing:'0.08em',
      textTransform:'uppercase', padding:sz.pad, borderRadius:3,
      color:'#fff', background:r.color,
    }}>{r.label}</span>
  );
}

// Compact dots for 'you hold: · · ·' indicator
function RoleDots({ forYou }) {
  const ids = forYou ? MEMBER_ROLES[3] /* Liisa */ : [];
  return (
    <span style={{ display:'inline-flex', gap:3, alignItems:'center', verticalAlign:'middle' }}>
      {ids.map(id => (
        <span key={id} title={ROLE_BY_ID[id].label} style={{
          width:9, height:9, borderRadius:2, background:ROLE_BY_ID[id].color,
        }} />
      ))}
      {ids.length > 0 && (
        <span style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink2)', marginLeft:3, fontWeight:600 }}>
          {ids.map(id => ROLE_BY_ID[id].label).join(' + ')}
        </span>
      )}
    </span>
  );
}

// ─── Panel header ────────────────────────────────────────────────────
// Big, close-to-the-data header for a panel of the admin page.
function PanelHeader({ eyebrow, title, count, desc, actions }) {
  return (
    <div style={{
      display:'flex', alignItems:'flex-end', justifyContent:'space-between',
      padding:'14px 24px 10px', gap:16,
      borderBottom:'1.5px solid var(--ink4)',
      background:'var(--paper)',
    }}>
      <div>
        {eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}
        <div style={{
          display:'flex', alignItems:'baseline', gap:8, marginTop:2,
        }}>
          <span style={{ fontFamily:'Inter', fontSize:20, fontWeight:700, letterSpacing:'-0.01em' }}>
            {title}
          </span>
          {count !== undefined && (
            <span className="mono" style={{ fontSize:12, color:'var(--ink3)' }}>
              {count}
            </span>
          )}
        </div>
        {desc && (
          <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginTop:3, maxWidth:620 }}>
            {desc}
          </div>
        )}
      </div>
      {actions && (
        <div style={{ display:'flex', gap:6, alignItems:'center' }}>
          {actions}
        </div>
      )}
    </div>
  );
}

// ─── Drag handle ─────────────────────────────────────────────────────
function DragHandle() {
  return (
    <span style={{
      display:'inline-flex', flexDirection:'column', gap:1,
      color:'var(--ink4)', cursor:'grab', userSelect:'none',
      padding:'0 2px', lineHeight:0.5,
    }}>
      <span style={{ fontSize:8 }}>⠇</span>
      <span style={{ fontSize:8 }}>⠇</span>
    </span>
  );
}

Object.assign(window, {
  ROLES, ROLE_BY_ID, MEMBER_ROLES, PENDING, AUDIT,
  rolesOf, memberCountByRole,
  SettingsNav, SettingsSubnav, AdminRoleChip, RoleDots,
  PanelHeader, DragHandle,
});
