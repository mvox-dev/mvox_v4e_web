// L1 — Compact list + inline accordion.
// Full-width rows, one open at a time, WorkDetail pushes rows below down.

function L1Accordion() {
  return (
    <BrowserFrame url="mvox.eu/members/kaaren-kammerkoor/library">
      <div className="sk" style={{ height:'100%', overflow:'hidden', display:'flex', flexDirection:'column' }}>
        <WorkspaceNav />
        <LibrarySubnav />

        <div style={{ padding:'14px 24px 8px', borderBottom:'1px solid var(--ink5)', display:'flex', justifyContent:'space-between', alignItems:'flex-end' }}>
          <div>
            <Eyebrow>Library · librarian view</Eyebrow>
            <div style={{ fontFamily:'Inter', fontWeight:700, fontSize:20, letterSpacing:'-0.01em' }}>Works archive</div>
            <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink3)', marginTop:2 }}>
              64 works · 12 with loans out · last added 2 days ago
            </div>
          </div>
          <span style={{ fontFamily:'Caveat', fontSize:13, color:'var(--red)' }}>only you (+ other librarians) see this tab</span>
        </div>

        <LibraryFilterBar />

        <div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}>
          {/* Column header */}
          <div style={{
            display:'flex', alignItems:'center', gap:12, padding:'6px 14px',
            background:'var(--paper2)', borderBottom:'1px solid var(--ink4)',
            fontFamily:'Inter', fontSize:9, fontWeight:600, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--ink4)',
          }}>
            <span style={{ width:14 }} />
            <span style={{ flex:1 }}>Work</span>
            <span style={{ width:110 }}>Files</span>
            <span style={{ width:92, textAlign:'center' }}>Copies</span>
          </div>

          <div style={{ flex:1, overflow:'hidden' }}>
            {LIBRARY.slice(0,2).map(w => <WorkRow key={w.id} work={w} compact />)}

            {/* Expanded row */}
            <div style={{ borderBottom:'1.5px solid var(--ink4)', background:'var(--paper2)' }}>
              <WorkRow work={LIBRARY[2]} expanded compact />
              <WorkDetail work={LIBRARY[0]} showLoanPicker={false} />
            </div>

            {LIBRARY.slice(3,7).map(w => <WorkRow key={w.id} work={w} compact />)}
          </div>
        </div>
      </div>
    </BrowserFrame>
  );
}

window.L1Accordion = L1Accordion;
