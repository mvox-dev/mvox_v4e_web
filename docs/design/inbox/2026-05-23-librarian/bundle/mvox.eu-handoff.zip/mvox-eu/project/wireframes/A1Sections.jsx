// A1 · Two-tab settings · SECTIONS tab active
// Conductor's workbench. Sections form a tree by parentSection.
//
// Section record (the conceptual shape, per discussion):
//   {
//     id, label, code,            // 'soprano' | 'sop-1', 'Soprano' | 'S1', 'S' | 'S1'
//     color,                      // hex from PALETTE_16; subs may pick own
//     tintFromParent,             // optional: render as tint of parent's color instead
//     parentSection,              // null for top-level sections
//     lead,                       // memberId | null  — independent per node
//     members,                    // memberId[]       — direct members only
//   }
//
// Subsections are sections too — same shape, with parentSection set. Mari
// being lead of Soprano does NOT make her lead of S1 unless explicitly set.

// ─── 16-color palette ────────────────────────────────────────────────
const PALETTE_16 = [
  '#c84b3a', '#d97742', '#c89a3a', '#a8a23a',
  '#6a9a3a', '#3a8a5a', '#3a8a8a', '#3a6a8a',
  '#5a5aa8', '#7a4ba8', '#a83a8a', '#a83a5a',
  '#8a6a4a', '#5a5a5a', '#3a3a3a', '#2a4a3a',
];

// Mix a hex color with the paper bg by `t` (0..1). t=1 returns the original.
function tintWithPaper(hex, t) {
  const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!m) return hex;
  const r = parseInt(m[1], 16), g = parseInt(m[2], 16), b = parseInt(m[3], 16);
  const PR = 0xfb, PG = 0xf6, PB = 0xe9; // var(--paper) ≈
  const mix = (c, p) => Math.round(c * t + p * (1 - t));
  const toHex = n => n.toString(16).padStart(2, '0');
  return '#' + toHex(mix(r, PR)) + toHex(mix(g, PG)) + toHex(mix(b, PB));
}

// ─── Section tree (overlay over SECTIONS / MEMBERS) ─────────────────
// Top-level sections + subsections, in a flat list with parentSection refs.
// Members and counts are derived from MEMBERS (the existing roster source).
const SECTION_NODES = [
  // Top-level
  { id:'soprano',  parentSection:null,      code:'S',  label:'Soprano',  color:'#c84b3a', lead:1  },
  { id:'alto',     parentSection:null,      code:'A',  label:'Alto',     color:'#8a6a2e', lead:5  },
  { id:'tenor',    parentSection:null,      code:'T',  label:'Tenor',    color:'#2f7a4f', lead:9  },
  { id:'bass',     parentSection:null,      code:'B',  label:'Bass',     color:'#c84b3a', lead:12 }, // accent-ish
  { id:'keyboard', parentSection:null,      code:'♪',  label:'Keyboard', color:'#6a5a8a', lead:null },
  // Subsections — each may pick its own palette color, or render as tint of parent
  { id:'sop-1',    parentSection:'soprano', code:'S1', label:'Soprano 1', color:'#c84b3a', tintFromParent:0.55, lead:1  },
  { id:'sop-2',    parentSection:'soprano', code:'S2', label:'Soprano 2', color:'#c84b3a', tintFromParent:0.30, lead:null },
  { id:'alt-1',    parentSection:'alto',    code:'A1', label:'Alto 1',    color:'#8a6a2e', tintFromParent:0.55, lead:5  },
  { id:'alt-2',    parentSection:'alto',    code:'A2', label:'Alto 2',    color:'#8a6a2e', tintFromParent:0.30, lead:8  },
  { id:'ten-1',    parentSection:'tenor',   code:'T1', label:'Tenor 1',   color:'#2f7a4f', tintFromParent:0.55, lead:9  },
  { id:'ten-2',    parentSection:'tenor',   code:'T2', label:'Tenor 2',   color:'#2f7a4f', tintFromParent:0.30, lead:11 },
];

const NODE_BY_ID = Object.fromEntries(SECTION_NODES.map(n => [n.id, n]));
const TOP_NODES  = SECTION_NODES.filter(n => !n.parentSection);
const childrenOf = pid => SECTION_NODES.filter(n => n.parentSection === pid);

// Effective render color: respect tintFromParent if present.
function nodeRenderColor(node) {
  if (node.parentSection && typeof node.tintFromParent === 'number') {
    const parent = NODE_BY_ID[node.parentSection];
    return tintWithPaper(parent.color, node.tintFromParent);
  }
  return node.color;
}

function memberById(id) { return MEMBERS.find(m => m.id === id) || null; }

// Map a SECTION_NODES id to (legacySectionId, legacySub) so we can read MEMBERS.
function nodeMembersRaw(node) {
  // Top-level: legacy section === node.id
  if (!node.parentSection) {
    return MEMBERS.filter(m => m.section === node.id && m.status !== 'alumni');
  }
  // Subsection: parent's legacy id, sub === node.code (e.g. 'S1')
  return MEMBERS.filter(m =>
    m.section === node.parentSection && m.sub === node.code && m.status !== 'alumni'
  );
}
const countOf  = node => nodeMembersRaw(node).length;
const subCount = nid => childrenOf(nid).length;

// ─── Top-level shell ─────────────────────────────────────────────────
function A1Sections() {
  return (
    <div style={{
      height:'100%', background:'var(--paper2)',
      display:'flex', flexDirection:'column', overflow:'hidden',
    }}>
      <WorkspaceNav />
      <SettingsNav active="sections" />
      <SettingsSubnav />

      <PanelHeader
        eyebrow="Sections"
        title="Voice parts & instrument sections"
        count={`${TOP_NODES.length} sections · ${SECTION_NODES.length - TOP_NODES.length} subsections · ${MEMBERS.filter(m => m.status !== 'alumni').length} members`}
        desc="The musical structure of the choir. Drag to reorder, click a section to edit it in the inspector. Section and subsection leads are independent assignments."
        actions={<button className="sk-btn" style={{ fontSize:11 }}>+ New section</button>}
      />

      <div style={{
        flex:1, display:'grid', gridTemplateColumns:'1fr 360px',
        gap:0, overflow:'hidden',
      }}>
        <div style={{ overflow:'auto' }}>
          {TOP_NODES.map(n => <SectionRow key={n.id} node={n} />)}
        </div>
        <SectionInspector node={NODE_BY_ID.soprano} />
      </div>
    </div>
  );
}

// ─── Section row & subsection row (library-row visual language) ──────
function SectionTag({ node, size = 'md' }) {
  // Colored tag with short code. Used for both top-level and subsections.
  const color = nodeRenderColor(node);
  const isLight = !!(node.parentSection && typeof node.tintFromParent === 'number');
  const fs = size === 'sm' ? 9.5 : 10.5;
  const pad = size === 'sm' ? '1px 6px' : '2px 7px';
  return (
    <span style={{
      fontFamily:'Inter', fontSize:fs, fontWeight:700, letterSpacing:'0.06em',
      color: isLight ? 'var(--ink)' : '#fff',
      background: color,
      padding: pad, borderRadius: 3,
      border: isLight ? `1px solid ${NODE_BY_ID[node.parentSection].color}` : '1px solid transparent',
      display:'inline-block', lineHeight:1.3,
      minWidth: 22, textAlign:'center',
    }}>{node.code}</span>
  );
}

function SectionRow({ node }) {
  const isSelected = node.id === 'soprano';
  const lead = memberById(node.lead);
  const subs = childrenOf(node.id);
  const cnt = countOf(node) + subs.reduce((a, s) => a + countOf(s), 0);

  return (
    <div>
      <div style={{
        padding:'10px 14px 10px 18px',
        borderBottom:'1px dashed var(--ink5)',
        background: isSelected ? 'var(--accent-soft)' : 'var(--paper)',
        borderLeft: isSelected ? '3px solid var(--accent)' : '3px solid transparent',
        display:'flex', alignItems:'center', gap:12, cursor:'pointer',
      }}>
        <DragHandle />
        <SectionTag node={node} />
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontFamily:'Inter', fontSize:13, color:'var(--ink)' }}>
            <span style={{ fontWeight:600 }}>{node.label}</span>
            <span style={{ color:'var(--ink3)' }}> · </span>
            <span style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink3)' }}>
              {cnt} {cnt === 1 ? 'member' : 'members'}
            </span>
            {subs.length > 0 && (
              <>
                <span style={{ color:'var(--ink3)' }}> · </span>
                <span style={{ fontFamily:'Inter', fontSize:12, color:'var(--ink3)' }}>
                  {subs.length} subsections
                </span>
              </>
            )}
          </div>
          <div style={{ display:'flex', gap:8, alignItems:'center', marginTop:2, fontFamily:'Inter', fontSize:10.5, color:'var(--ink4)' }}>
            {lead ? (
              <span>lead: <strong style={{ color:'var(--ink2)' }}>{lead.name}</strong></span>
            ) : (
              <span style={{ color:'var(--ink4)', fontStyle:'italic' }}>no lead assigned</span>
            )}
            <span>·</span>
            <span className="mono" style={{ fontSize:9.5 }}>#{node.id}</span>
          </div>
        </div>
      </div>

      {subs.map(sub => <SubsectionRow key={sub.id} node={sub} />)}
    </div>
  );
}

function SubsectionRow({ node }) {
  const lead = memberById(node.lead);
  const cnt = countOf(node);
  return (
    <div style={{
      padding:'7px 14px 7px 50px',
      borderBottom:'1px dotted var(--ink5)',
      background:'var(--paper)',
      display:'flex', alignItems:'center', gap:10,
      fontFamily:'Inter', fontSize:11.5, color:'var(--ink2)',
    }}>
      <DragHandle />
      <SectionTag node={node} size="sm" />
      <span style={{ color:'var(--ink2)', fontSize:11.5 }}>{node.label}</span>
      <span style={{ color:'var(--ink3)', fontSize:11 }}>· {cnt} members</span>
      {lead ? (
        <span style={{ color:'var(--ink4)', fontSize:10.5 }}>
          · lead: <strong style={{ color:'var(--ink2)' }}>{lead.name}</strong>
        </span>
      ) : (
        <span style={{ color:'var(--ink4)', fontSize:10.5, fontStyle:'italic' }}>· no lead</span>
      )}
    </div>
  );
}

// ─── Inspector (selected: Soprano) ───────────────────────────────────
function SectionInspector({ node }) {
  const directMembers = nodeMembersRaw(node);
  const subs = childrenOf(node.id);
  const lead = memberById(node.lead);
  const totalIncludingSubs = directMembers.length + subs.reduce((a, s) => a + countOf(s), 0);
  const canDelete = totalIncludingSubs === 0;

  return (
    <div style={{
      borderLeft:'1.5px solid var(--ink4)',
      background:'var(--paper)',
      overflow:'auto',
      display:'flex', flexDirection:'column',
    }}>
      <div style={{
        padding:'14px 18px 10px',
        borderBottom:'1px dashed var(--ink5)',
        display:'flex', alignItems:'center', gap:10,
      }}>
        <SectionTag node={node} />
        <div style={{ flex:1, minWidth:0 }}>
          <Eyebrow>Section</Eyebrow>
          <div style={{ fontFamily:'Inter', fontSize:15, fontWeight:700, marginTop:1 }}>{node.label}</div>
        </div>
        <button
          title={canDelete ? 'Delete this section' : `Cannot delete: ${totalIncludingSubs} members across this section and its subsections.`}
          disabled={!canDelete}
          style={{
            width:24, height:24, border:'1.5px solid var(--ink4)',
            background:'var(--paper)', cursor: canDelete ? 'pointer' : 'not-allowed',
            opacity: canDelete ? 1 : 0.35,
            color:'var(--red)', fontSize:14, lineHeight:1, fontWeight:700,
            borderRadius:3,
          }}
        >×</button>
      </div>

      <InspectorField label="Display name">
        <input className="sk-input" defaultValue={node.label} style={{ fontSize:12, width:'100%' }} />
      </InspectorField>

      <InspectorField label="Short code" hint="Used in event attendance, CSV export, the Members page tag.">
        <input className="sk-input" defaultValue={node.code} style={{ fontSize:12, width:60 }} />
      </InspectorField>

      <InspectorField label="Parent section" hint="Promote to a subsection of another section, or keep at top level.">
        <ParentSelect node={node} />
      </InspectorField>

      <InspectorField label="Color" hint={node.parentSection ? 'Pick a hex from the palette, or render as a tint of the parent.' : 'Subsections inherit and can render as a tint of this base.'}>
        <PaletteGrid value={node.color} />
      </InspectorField>

      <InspectorField label="Section lead" hint="Independent of subsection leads.">
        {lead ? (
          <LeadRow member={lead} subtle={`leads ${node.label}`} />
        ) : (
          <span className="sk-underline" style={{ fontSize:11, color:'var(--ink3)' }}>+ Assign section lead</span>
        )}
      </InspectorField>

      <InspectorField label={`Subsections (${subs.length})`} hint="Each has its own color (or tint) and lead.">
        {subs.map(sub => {
          const subLead = memberById(sub.lead);
          return (
            <div key={sub.id} style={{
              padding:'6px 0', borderBottom:'1px dotted var(--ink5)',
              display:'flex', alignItems:'center', gap:8,
              fontFamily:'Inter', fontSize:11.5,
            }}>
              <DragHandle />
              <SectionTag node={sub} size="sm" />
              <span style={{ color:'var(--ink2)' }}>{sub.label}</span>
              <span style={{ flex:1, minWidth:0, color:'var(--ink3)', fontSize:10.5 }}>
                · {countOf(sub)} members ·
                {subLead ? <> lead: <strong style={{ color:'var(--ink2)' }}>{subLead.name.split(' ')[0]}</strong></> : <span style={{ fontStyle:'italic' }}> no lead</span>}
              </span>
              <span className="sk-underline" style={{ fontSize:10, color:'var(--ink3)' }}>edit</span>
              <span className="sk-underline" style={{ fontSize:10, color:'var(--ink4)' }}>×</span>
            </div>
          );
        })}
        <div style={{ paddingTop:6, fontFamily:'Inter', fontSize:10.5 }}>
          <span className="sk-underline" style={{ color:'var(--ink2)' }}>+ Add subsection</span>
        </div>
      </InspectorField>

      <InspectorField
        label={`Direct members (${directMembers.length})`}
        hint="Only members directly in Soprano (not via S1/S2). Use the action menu to remove or move."
      >
        <div style={{ display:'flex', flexDirection:'column' }}>
          {directMembers.length === 0 && (
            <div style={{ fontFamily:'Inter', fontSize:11, color:'var(--ink4)', fontStyle:'italic', padding:'6px 0' }}>
              All Soprano members live in subsections. Open S1 or S2 above to manage them.
            </div>
          )}
          {directMembers.map((m, i) => (
            <MemberRow key={m.id} m={m} parent={node} isLast={i === directMembers.length - 1} />
          ))}
          <div style={{
            paddingTop:8, marginTop:4,
            borderTop:'1px dashed var(--ink5)',
            fontFamily:'Inter', fontSize:10.5,
          }}>
            <span className="sk-underline" style={{ color:'var(--ink2)' }}>+ Add member to section</span>
            <span style={{ color:'var(--ink4)', marginLeft:10 }}>· choose from existing or invite new</span>
          </div>
        </div>
      </InspectorField>

      <div style={{ flex:1 }} />
    </div>
  );
}

// ─── Parent-section select ──────────────────────────────────────────
// "Assign parent" lives here too: any section can be promoted to a subsection
// of another. (Counter to "+ Add subsection" which goes the other direction.)
function ParentSelect({ node }) {
  // Eligible parents: top-level sections that aren't this node and aren't its descendants.
  const eligible = TOP_NODES.filter(n => n.id !== node.id);
  return (
    <select className="sk-input" defaultValue={node.parentSection || ''} style={{
      fontSize:12, width:'100%', background:'var(--paper)', fontFamily:'Inter',
    }}>
      <option value="">— top-level section —</option>
      {eligible.map(n => (
        <option key={n.id} value={n.id}>nested under {n.label}</option>
      ))}
    </select>
  );
}

function LeadRow({ member, subtle }) {
  return (
    <div style={{
      padding:'6px 8px',
      display:'flex', alignItems:'center', gap:8,
      background:'var(--paper2)',
      border:'1px dashed var(--ink5)',
    }}>
      <div className="sk-icon" style={{ width:24, height:24, fontSize:10, borderRadius:999 }}>
        {member.name.split(' ').map(w => w[0]).slice(0,2).join('')}
      </div>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ fontFamily:'Inter', fontSize:11.5, fontWeight:600 }}>{member.name}</div>
        <div className="mono" style={{ fontSize:9, color:'var(--ink4)' }}>{subtle}</div>
      </div>
      <button className="sk-btn ghost" style={{ fontSize:10, padding:'2px 6px' }}>Change</button>
      <button title="Clear lead" style={{
        width:20, height:20, border:'1px solid var(--ink5)', background:'transparent',
        color:'var(--ink4)', fontSize:11, lineHeight:1, cursor:'pointer', borderRadius:2,
      }}>×</button>
    </div>
  );
}

// ─── Member row (with bulk-action selectbox) ─────────────────────────
function MemberRow({ m, parent, isLast }) {
  const subs = childrenOf(parent.id);
  return (
    <div style={{
      display:'flex', alignItems:'center', gap:8,
      padding:'5px 0',
      borderBottom: isLast ? 'none' : '1px dotted var(--ink5)',
      fontFamily:'Inter', fontSize:11,
    }}>
      <span style={{ flex:1, minWidth:0, color:'var(--ink2)' }}>
        {m.name}
        {m.sectionLeader && (
          <span style={{ marginLeft:6, fontSize:8.5, fontWeight:700, color:'#6a5a8a', letterSpacing:'0.06em' }}>
            ▸LEAD
          </span>
        )}
      </span>
      <select className="sk-input" style={{
        fontSize:10, padding:'2px 5px', background:'var(--paper)',
        fontFamily:'Inter', color:'var(--ink3)', borderRadius:2,
        maxWidth:140,
      }} defaultValue="">
        <option value="" disabled>actions…</option>
        {subs.length > 0 && (
          <optgroup label="Move to subsection">
            {subs.map(s => <option key={s.id} value={`sub-${s.id}`}>{s.code} · {s.label}</option>)}
          </optgroup>
        )}
        <optgroup label="Move to section">
          {TOP_NODES.filter(n => n.id !== parent.id).map(n =>
            <option key={n.id} value={`sec-${n.id}`}>{n.label}</option>
          )}
        </optgroup>
        <option value="remove">Remove from {parent.label}</option>
      </select>
    </div>
  );
}

// ─── Palette grid ────────────────────────────────────────────────────
function PaletteGrid({ value }) {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(8, 1fr)', gap:5 }}>
      {PALETTE_16.map(c => {
        const on = c.toLowerCase() === (value || '').toLowerCase();
        return (
          <div key={c} style={{
            aspectRatio:'1 / 1', background:c, borderRadius:3,
            border: on ? '2px solid var(--ink)' : '1px solid var(--ink4)',
            cursor:'pointer', position:'relative',
          }}>
            {on && (
              <span style={{
                position:'absolute', inset:0, display:'flex',
                alignItems:'center', justifyContent:'center',
                color:'#fff', fontSize:11, fontWeight:700,
                textShadow:'0 1px 1px rgba(0,0,0,0.5)',
              }}>✓</span>
            )}
          </div>
        );
      })}
    </div>
  );
}

function InspectorField({ label, hint, children }) {
  return (
    <div style={{
      padding:'10px 18px',
      borderBottom:'1px dashed var(--ink5)',
    }}>
      <div style={{
        fontFamily:'Inter', fontSize:10, fontWeight:600, letterSpacing:'0.08em',
        textTransform:'uppercase', color:'var(--ink3)', marginBottom:5,
      }}>{label}</div>
      {children}
      {hint && (
        <div style={{ fontFamily:'Inter', fontSize:10, color:'var(--ink4)', marginTop:4, lineHeight:1.35 }}>
          {hint}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { A1Sections, SECTION_NODES, NODE_BY_ID, SectionTag });
